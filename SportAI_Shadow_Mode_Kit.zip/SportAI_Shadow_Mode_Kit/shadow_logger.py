"""
SportAI Shadow Logger
---------------------
Logs AI "shadow mode" suggestions without executing changes.
Writes to CSV by default; can be switched to SQLite by flipping STORAGE_BACKEND.

Usage:
    from shadow_logger import ShadowLogger
    logger = ShadowLogger(csv_path="shadow_logs.csv")
    logger.log_suggestion(
        suggestion_id="SUG-001",
        asset_id="turf_half_A",
        asset_type="turf_half",
        time_block_start="2025-10-12 17:00",
        time_block_end="2025-10-12 18:00",
        tier="MemberPlus",
        event_type="practice",
        suggested_price=180.0,
        suggested_layout="half",
        suggested_pod="Pod 2",
        predicted_revenue=180.0,
        predicted_utilization=0.85,
        predicted_sponsor_hits=120,
        inputs={
            "lead_time_days": 9,
            "historic_util_4w": 0.78,
            "prime": True,
            "season": "fall",
            "city_policy": "standard"
        },
        reason_codes=["LT_POS","OFFPEAK_BUMP","SPONSOR_ROTATE"],
        would_do_action="price_nudge:+10%",
        guardrail_flags=[] # e.g. ["FLOOR_BLOCKED"]
    )
"""

from dataclasses import dataclass, asdict, field
from typing import List, Dict, Optional, Union
import csv, json, os, time, uuid, datetime

@dataclass
class SuggestionLog:
    # Identity & meta
    suggestion_id: str
    created_at: str
    # Asset & block
    asset_id: str
    asset_type: str
    time_block_start: str
    time_block_end: str
    # User/Tier/Event
    tier: str
    event_type: str
    # AI suggestion
    suggested_price: float
    suggested_layout: str
    suggested_pod: Optional[str] = None
    # Predictions
    predicted_revenue: float = 0.0
    predicted_utilization: float = 0.0
    predicted_sponsor_hits: int = 0
    # Inputs snapshot (JSON)
    inputs: Dict[str, Union[str, int, float, bool]] = field(default_factory=dict)
    # Governance
    reason_codes: List[str] = field(default_factory=list)
    would_do_action: str = ""
    guardrail_flags: List[str] = field(default_factory=list)
    # Outcome placeholders (to be joined later)
    actual_revenue: Optional[float] = None
    actual_utilization: Optional[float] = None
    actual_sponsor_hits: Optional[int] = None

class ShadowLogger:
    def __init__(self, csv_path: str = "shadow_logs.csv"):
        self.csv_path = csv_path
        self.headers = [
            "suggestion_id","created_at","asset_id","asset_type","time_block_start","time_block_end",
            "tier","event_type","suggested_price","suggested_layout","suggested_pod",
            "predicted_revenue","predicted_utilization","predicted_sponsor_hits",
            "inputs","reason_codes","would_do_action","guardrail_flags",
            "actual_revenue","actual_utilization","actual_sponsor_hits"
        ]
        if not os.path.exists(self.csv_path):
            with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=self.headers)
                writer.writeheader()

    def _ensure_id(self, suggestion_id: Optional[str]) -> str:
        return suggestion_id or f"SUG-{uuid.uuid4().hex[:8].upper()}"

    def log_suggestion(
        self,
        suggestion_id: Optional[str],
        asset_id: str,
        asset_type: str,
        time_block_start: str,
        time_block_end: str,
        tier: str,
        event_type: str,
        suggested_price: float,
        suggested_layout: str,
        suggested_pod: Optional[str] = None,
        predicted_revenue: float = 0.0,
        predicted_utilization: float = 0.0,
        predicted_sponsor_hits: int = 0,
        inputs: Optional[Dict] = None,
        reason_codes: Optional[List[str]] = None,
        would_do_action: str = "",
        guardrail_flags: Optional[List[str]] = None,
    ) -> str:
        sid = self._ensure_id(suggestion_id)
        now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        log = SuggestionLog(
            suggestion_id=sid,
            created_at=now,
            asset_id=asset_id,
            asset_type=asset_type,
            time_block_start=time_block_start,
            time_block_end=time_block_end,
            tier=tier,
            event_type=event_type,
            suggested_price=float(suggested_price),
            suggested_layout=suggested_layout,
            suggested_pod=suggested_pod,
            predicted_revenue=float(predicted_revenue),
            predicted_utilization=float(predicted_utilization),
            predicted_sponsor_hits=int(predicted_sponsor_hits),
            inputs=inputs or {},
            reason_codes=reason_codes or [],
            would_do_action=would_do_action,
            guardrail_flags=guardrail_flags or []
        )
        with open(self.csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.headers)
            row = asdict(log)
            row["inputs"] = json.dumps(row["inputs"], ensure_ascii=False)
            row["reason_codes"] = json.dumps(row["reason_codes"], ensure_ascii=False)
            row["guardrail_flags"] = json.dumps(row["guardrail_flags"], ensure_ascii=False)
            writer.writerow(row)
        return sid

    def attach_outcome(self, suggestion_id: str, actual_revenue: float=None,
                       actual_utilization: float=None, actual_sponsor_hits: int=None):
        import pandas as pd
        df = pd.read_csv(self.csv_path)
        mask = df["suggestion_id"] == suggestion_id
        if not mask.any():
            raise ValueError(f"suggestion_id not found: {suggestion_id}")
        if actual_revenue is not None:
            df.loc[mask, "actual_revenue"] = float(actual_revenue)
        if actual_utilization is not None:
            df.loc[mask, "actual_utilization"] = float(actual_utilization)
        if actual_sponsor_hits is not None:
            df.loc[mask, "actual_sponsor_hits"] = int(actual_sponsor_hits)
        df.to_csv(self.csv_path, index=False)
        return True
