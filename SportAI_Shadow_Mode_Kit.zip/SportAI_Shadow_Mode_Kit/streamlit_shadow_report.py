"""
Streamlit: SportAI Shadow Mode Comparison Report
------------------------------------------------
Run:
    streamlit run streamlit_shadow_report.py

Inputs:
    - shadow_logs.csv (from shadow_logger.py)
    - actuals.csv (optional if actuals appended directly)
"""
import json
import pandas as pd
import numpy as np
import streamlit as st

st.set_page_config(page_title="SportAI Shadow Mode Report", layout="wide")

st.title("SportAI Shadow Mode – AI vs Actuals")
st.caption("Compare predicted impact vs actual outcomes, validate guardrails, and decide when to auto-apply.")

uploaded_logs = st.file_uploader("Upload shadow_logs.csv", type=["csv"])
uploaded_actuals = st.file_uploader("Upload actuals.csv (optional – will join on suggestion_id or asset/time window)", type=["csv"])

guardrails = st.sidebar.expander("Guardrail Settings", expanded=False)
with guardrails:
    floor_price = st.number_input("Global price floor ($)", min_value=0.0, value=75.0, step=5.0)
    ceiling_price = st.number_input("Global price ceiling ($)", min_value=0.0, value=450.0, step=10.0)
    max_override_rate = st.slider("Max human override rate (%)", 0, 100, 15, step=1)
    mape_threshold = st.slider("MAPE promote threshold (%)", 1, 50, 10, step=1)
    min_lift = st.slider("Min net revenue lift to promote (%)", 0, 20, 3, step=1)

def mape(y_true, y_pred):
    y_true = np.array(y_true, dtype=float)
    y_pred = np.array(y_pred, dtype=float)
    mask = y_true != 0
    if mask.sum() == 0:
        return np.nan
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100.0

if uploaded_logs:
    df = pd.read_csv(uploaded_logs)
    # Expand JSON cols
    for col in ["inputs","reason_codes","guardrail_flags"]:
        if col in df.columns:
            try:
                df[col] = df[col].apply(lambda x: json.loads(x) if isinstance(x,str) else x)
            except Exception:
                pass
    st.subheader("Raw Suggestions")
    st.dataframe(df)

    # Optionally join actuals file (if provided and not already attached)
    if uploaded_actuals:
        act = pd.read_csv(uploaded_actuals)
        # Try to join on suggestion_id first; else asset/time window
        if "suggestion_id" in act.columns and "suggestion_id" in df.columns:
            df = df.merge(act, on="suggestion_id", how="left", suffixes=("","_actfile"))
            for tgt, src in [
                ("actual_revenue","actual_revenue_actfile"),
                ("actual_utilization","actual_utilization_actfile"),
                ("actual_sponsor_hits","actual_sponsor_hits_actfile"),
            ]:
                if src in df.columns and tgt in df.columns:
                    df[tgt] = df[tgt].fillna(df[src])
        elif set(["asset_id","time_block_start","time_block_end"]).issubset(act.columns):
            df = df.merge(act, on=["asset_id","time_block_start","time_block_end"], how="left", suffixes=("","_actfile"))
    else:
        st.info("No separate actuals.csv uploaded. Using any 'actual_*' columns present in shadow logs.")

    # Metrics
    st.subheader("Key Metrics")
    col1, col2, col3, col4 = st.columns(4)
    mape_rev = mape(df["actual_revenue"].fillna(0), df["predicted_revenue"].fillna(0)) if "actual_revenue" in df.columns else np.nan
    mape_util = mape(df["actual_utilization"].fillna(0), df["predicted_utilization"].fillna(0)) if "actual_utilization" in df.columns else np.nan
    avg_lift = ((df["actual_revenue"] - df["predicted_revenue"]) / df["predicted_revenue"] * 100.0).replace([np.inf,-np.inf], np.nan).mean()

    col1.metric("MAPE (Revenue)", f"{mape_rev:.2f}%" if pd.notna(mape_rev) else "—")
    col2.metric("MAPE (Utilization)", f"{mape_util:.2f}%" if pd.notna(mape_util) else "—")
    col3.metric("Avg. Net Revenue Lift", f"{avg_lift:.2f}%" if pd.notna(avg_lift) else "—")
    col4.metric("Suggestions Logged", f"{len(df):,}")

    # Promote/Review status per asset
    st.subheader("Promotion Readiness by Asset")
    status_rows = []
    for asset, g in df.groupby("asset_id"):
        mrev = mape(g["actual_revenue"].fillna(0), g["predicted_revenue"].fillna(0)) if "actual_revenue" in g.columns else np.nan
        lift = ((g["actual_revenue"] - g["predicted_revenue"]) / g["predicted_revenue"] * 100.0).replace([np.inf,-np.inf], np.nan).mean()
        overrides = g["guardrail_flags"].dropna().apply(lambda x: len(x) if isinstance(x,list) else 0).sum()
        override_rate = (overrides / max(len(g),1)) * 100.0
        if pd.notna(mrev) and mrev <= mape_threshold and (pd.notna(lift) and lift >= min_lift) and override_rate <= max_override_rate:
            status = "PROMOTE → Auto-Apply"
        else:
            status = "KEEP in Review"
        status_rows.append({"asset_id": asset, "MAPE_Revenue_%": mrev, "Avg_Lift_%": lift, "Override_Rate_%": override_rate, "Status": status})
    if status_rows:
        st.dataframe(pd.DataFrame(status_rows).sort_values(["Status","MAPE_Revenue_%"]))

    st.subheader("Guardrail Checks")
    def check_guardrails(row):
        flags = []
        if row.get("suggested_price", 0) < floor_price: flags.append("PRICE_FLOOR")
        if row.get("suggested_price", 0) > ceiling_price: flags.append("PRICE_CEILING")
        # More domain checks could be added here (league rules, city policy, blackout, etc.)
        return flags
    df["computed_guardrails"] = df.apply(check_guardrails, axis=1)
    st.dataframe(df[["suggestion_id","asset_id","time_block_start","suggested_price","computed_guardrails"]])

    st.download_button("Download Enriched Dataset (CSV)",
                       data=df.to_csv(index=False).encode("utf-8"),
                       file_name="shadow_mode_enriched.csv",
                       mime="text/csv")
else:
    st.info("Upload your shadow_logs.csv to begin.")
