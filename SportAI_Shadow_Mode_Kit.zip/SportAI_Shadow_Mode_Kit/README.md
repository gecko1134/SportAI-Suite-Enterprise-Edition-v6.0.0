# SportAI Shadow Mode Kit

**Purpose:** Run AI pricing/layout/sponsor rotation in *shadow mode* first, collect predictions vs. actuals, and decide when to auto-apply — with guardrails.

## Files
- `shadow_logger.py` — Python logger for AI suggestions (CSV backend).
- `streamlit_shadow_report.py` — Streamlit dashboard to compare AI vs actuals and compute MAPE/lift.
- `governance_policy.pdf` — Board-facing policy and promotion rules.
- `guardrails_config.yaml` — Tunable guardrails and thresholds.
- `sample_logs.csv` / `sample_actuals.csv` — Starter datasets for testing.

## Quick Start
1. **Log suggestions (shadow mode):**
   ```python
   from shadow_logger import ShadowLogger
   logger = ShadowLogger(csv_path="shadow_logs.csv")
   sid = logger.log_suggestion(
       suggestion_id=None,
       asset_id="turf_half_A",
       asset_type="turf_half",
       time_block_start="2025-10-12 17:00",
       time_block_end="2025-10-12 18:00",
       tier="MemberPlus",
       event_type="practice",
       suggested_price=180.0,
       suggested_layout="half",
       suggested_pod="Pod 2",
       predicted_revenue=180.0,
       predicted_utilization=0.85,
       predicted_sponsor_hits=120,
       inputs={"lead_time_days": 9, "historic_util_4w": 0.78, "prime": True},
       reason_codes=["LT_POS","OFFPEAK_BUMP"],
       would_do_action="price_nudge:+10%",
       guardrail_flags=[]
   )
   print("Logged:", sid)
   ```

2. **Attach outcomes later (optional if you import actuals via CSV):**
   ```python
   from shadow_logger import ShadowLogger
   ShadowLogger("shadow_logs.csv").attach_outcome(sid, actual_revenue=175, actual_utilization=0.80, actual_sponsor_hits=118)
   ```

3. **Run the dashboard:**
   ```bash
   streamlit run streamlit_shadow_report.py
   ```
   Upload `shadow_logs.csv` (or `sample_logs.csv`) and optional `sample_actuals.csv`.

## Promotion Rules (summary)
- **Promote to Auto-Apply** when: Revenue **MAPE ≤ 8–10%**, **Net Lift ≥ 3–5%**, **Override Rate ≤ 15%**, SLA OK.
- Keep manual for championships, school contracts, and naming-rights rotations.

---
*(Generated 2025-10-10 14:05:44)*
