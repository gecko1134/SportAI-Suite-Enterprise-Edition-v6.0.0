# Sponsorship Agreement

**Sponsor:** Acme Health  |  **Category:** Healthcare  |  **Tier:** Gold
**Term:** 24 months
**Dates:** 2026-01-15 to 2028-01-15

## Pricing Summary
- Gross Contract Value: $233,700
- Multi-year Discount: 5%
- Annual Escalator (if multi-year): 4%

### Line Items
- DOME_CENTER_HUNG: $72,000 per year x 2.0 years
- COURT_A_STANCHION_WRAP: $26,400 per year x 2.0 years

## Grant of Rights
Facility grants Sponsor a non-transferable, non-sublicensable right to display Sponsor’s brand across the contracted inventory listed in this Agreement, limited to the Facility premises, official digital streams, and event communications for the Term. All other rights are reserved by Facility.
## Branding & Creative SLAs
- Assets due 21 days prior to launch
- 2 revision rounds included
- Late assets may use prior-season creative or Facility templates at Facility’s option
## Make-Good & Minimums
If actual impressions for any digital asset under-deliver by more than 20% versus the estimate, Facility will extend the flight or add equivalent-value digital inventory as a make-good.
## Measurement & Reporting
- QR/UTM convention: `nxs{yyyy}{tier}{loc}{seq}`
- Reporting cadence: quarterly
- Access to Facility’s dashboard for impression logs on digital assets
## Insurance & Indemnity
Each party maintains commercial general liability insurance of at least $1,000,000 per occurrence and names the other party as additional insured for activities under this Agreement.
## Termination & Morals
Either party may terminate immediately for material breach uncured after 30 days’ notice, or for public conduct reasonably expected to cause material reputational harm to the other.
## Term
The Term commences on 2026-01-15 and ends on 2028-01-15 (24 months).
## Escalator
For multi-year terms, a 4% annual escalator applies to fees beginning in year two.
## Category Exclusivity
During the Term, Facility will not enter into sponsorships with competing brands within Sponsor’s declared category, subject to existing obligations disclosed prior to execution.
## Zone Exclusivity
Sponsor receives exclusivity for the specified signage zones and placements selected herein. Facility may sell other zones to additional sponsors provided no conflict with Sponsor’s contracted zones.
## Deliverables — Hero Digital
- Center-hung LED or equivalent premium digital board, 3 unit(s)
- Inclusion in livestream lower-third rotation where applicable
- Standard flighting across marquee events within the facility main bowl
## Deliverables — Court Static
- Court-side stanchion wraps on Court A, 3 unit(s)
- Printed to spec, installed by Facility-approved vendor
- Reasonable wear-and-tear replacement policy included