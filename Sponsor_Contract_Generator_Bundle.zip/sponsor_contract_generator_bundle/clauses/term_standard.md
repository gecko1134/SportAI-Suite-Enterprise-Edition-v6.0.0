## Term
The Term commences on {{start_date}} and ends on {{end_date}} ({{term_months}} months).