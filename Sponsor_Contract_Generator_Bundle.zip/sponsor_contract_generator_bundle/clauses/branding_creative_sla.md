## Branding & Creative SLAs
- Assets due {{creative_due_days_before_launch}} days prior to launch
- {{revision_rounds_included}} revision rounds included
- Late assets may use prior-season creative or Facility templates at Facility’s option