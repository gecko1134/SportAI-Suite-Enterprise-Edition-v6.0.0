
# FastAPI webhooks to record "fully executed" contract events from DocuSign/Adobe Sign.
# Run: uvicorn webhooks.esign_webhooks:app --reload --port 8082
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import json, os, datetime

app = FastAPI()
LOG = "data/contracts/events.json"

def _load():
    if os.path.exists(LOG):
        return json.load(open(LOG))
    return {"events":[]}

def _save(data):
    os.makedirs("data/contracts", exist_ok=True)
    json.dump(data, open(LOG,"w"), indent=2)

@app.post("/webhook/docusign")
async def docusign(req: Request):
    payload = await req.json()
    data = _load()
    data["events"].append({
        "ts": datetime.datetime.utcnow().isoformat()+"Z",
        "source": "docusign",
        "envelope_id": payload.get("envelopeId"),
        "status": payload.get("status"),
        "sponsor": payload.get("sponsor"),
        "executed": payload.get("status") in ["completed","completedEnvelope"]
    })
    _save(data)
    return JSONResponse({"ok": True})

@app.post("/webhook/adobesign")
async def adobesign(req: Request):
    payload = await req.json()
    data = _load()
    data["events"].append({
        "ts": datetime.datetime.utcnow().isoformat()+"Z",
        "source": "adobesign",
        "agreement_id": payload.get("agreementId"),
        "status": payload.get("status"),
        "sponsor": payload.get("sponsor"),
        "executed": payload.get("status") in ["SIGNED","APPROVED","COMPLETED"]
    })
    _save(data)
    return JSONResponse({"ok": True})
