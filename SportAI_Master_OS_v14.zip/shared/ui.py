
import streamlit as st

def page_header(title: str, subtitle: str = ""):
    st.title(title)
    if subtitle:
        st.caption(subtitle)

def tag(text: str):
    st.markdown(f"<span style='padding:3px 8px;border-radius:12px;border:1px solid #ddd;font-size:0.8rem'>{text}</span>", unsafe_allow_html=True)

def stat(label: str, value: str):
    st.metric(label, value)
