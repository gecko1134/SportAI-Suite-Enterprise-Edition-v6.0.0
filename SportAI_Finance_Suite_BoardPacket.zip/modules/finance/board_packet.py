
"""
Board Finance Packet Generator
- Pulls metrics from payments ledger
- Builds a board-ready PDF (if reportlab installed) or HTML fallback
Includes:
  * KPIs: Paid, Open/Unpaid, All-time
  * A/R Aging buckets
  * Recent top-10 payments
"""
import os
from datetime import datetime
import pandas as pd

LEDGER_PATH = "modules/pricing/payments_ledger.csv"
EXPORT_DIR = "modules/finance/exports"
os.makedirs(EXPORT_DIR, exist_ok=True)

def compute_kpis(df: pd.DataFrame) -> dict:
    paid = float(df[df["status"].str.lower()=="paid"]["amount"].sum()) if not df.empty else 0.0
    open_amt = float(df[df["status"].str.lower().isin(["open","unpaid","partial"])]["amount"].sum()) if not df.empty else 0.0
    total = float(df["amount"].sum()) if not df.empty else 0.0
    return {"paid": paid, "open": open_amt, "total": total}

def ar_buckets(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame([{"bucket":"current","amount":0.0},
                             {"bucket":"1-30","amount":0.0},
                             {"bucket":"31-60","amount":0.0},
                             {"bucket":"61-90","amount":0.0},
                             {"bucket":"90+","amount":0.0}])
    out = df.copy()
    out["ts"] = pd.to_datetime(out["ts"], unit="s", errors="coerce")
    out["days"] = (pd.Timestamp.utcnow() - out["ts"]).dt.days
    op = out[out["status"].str.lower().isin(["open","unpaid","partial"])]
    def bucket(d):
        if d <= 0: return "current"
        if d <= 30: return "1-30"
        if d <= 60: return "31-60"
        if d <= 90: return "61-90"
        return "90+"
    op["bucket"] = op["days"].apply(lambda d: bucket(int(d) if pd.notna(d) else 0))
    return op.groupby("bucket")["amount"].sum().reindex(["current","1-30","31-60","61-90","90+"], fill_value=0.0).reset_index()

def generate_board_packet(out_base: str = None) -> dict:
    if not os.path.exists(LEDGER_PATH):
        raise FileNotFoundError("payments ledger not found: " + LEDGER_PATH)
    df = pd.read_csv(LEDGER_PATH)
    kpis = compute_kpis(df)
    aging = ar_buckets(df)
    recent = df.sort_values("ts", ascending=False).head(10)

    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    if out_base is None:
        out_base = f"board_finance_packet_{ts}"
    pdf_path = os.path.join(EXPORT_DIR, f"{out_base}.pdf")
    html_path = os.path.join(EXPORT_DIR, f"{out_base}.html")
    generated = {}

    # Try PDF
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import inch

        c = canvas.Canvas(pdf_path, pagesize=LETTER)
        w,h = LETTER
        y = h - 1*inch
        c.setFont("Helvetica-Bold", 16); c.drawString(1*inch, y, "Board Finance Packet"); y -= 0.35*inch
        c.setFont("Helvetica", 10); c.drawString(1*inch, y, f"As of {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"); y -= 0.3*inch

        # KPIs
        c.setFont("Helvetica-Bold", 12); c.drawString(1*inch, y, "KPIs"); y -= 0.25*inch
        c.setFont("Helvetica", 10)
        c.drawString(1*inch, y, f"Paid: ${kpis['paid']:.2f}"); y -= 0.2*inch
        c.drawString(1*inch, y, f"Open/Unpaid: ${kpis['open']:.2f}"); y -= 0.2*inch
        c.drawString(1*inch, y, f"All Time: ${kpis['total']:.2f}"); y -= 0.3*inch

        # Aging
        c.setFont("Helvetica-Bold", 12); c.drawString(1*inch, y, "A/R Aging"); y -= 0.25*inch
        c.setFont("Helvetica", 10)
        for _, r in aging.iterrows():
            c.drawString(1*inch, y, f"{r['bucket']}: ${float(r['amount']):.2f}"); y -= 0.2*inch
            if y < 1*inch: c.showPage(); y = h - 1*inch

        # Recent 10
        y -= 0.1*inch
        c.setFont("Helvetica-Bold", 12); c.drawString(1*inch, y, "Recent Transactions (Top 10)"); y -= 0.25*inch
        c.setFont("Helvetica", 9)
        for _, r in recent.iterrows():
            when = pd.to_datetime(r["ts"], unit="s", errors="coerce").strftime("%Y-%m-%d")
            line = f"{when} | {r.get('invoice_no','')} | {r.get('org_name','')} | ${float(r['amount']):.2f} | {r.get('status','')}"
            c.drawString(1*inch, y, line); y -= 0.18*inch
            if y < 1*inch: c.showPage(); y = h - 1*inch

        c.showPage(); c.save()
        generated["pdf"] = pdf_path
    except Exception:
        pass

    # HTML fallback
    recent_rows = "".join([
        f"<tr><td>{pd.to_datetime(r['ts'], unit='s').strftime('%Y-%m-%d')}</td>"
        f"<td>{r.get('invoice_no','')}</td><td>{r.get('org_name','')}</td>"
        f"<td style='text-align:right'>${float(r['amount']):.2f}</td><td>{r.get('status','')}</td></tr>"
        for _, r in recent.iterrows()
    ])
    aging_rows = "".join([
        f"<tr><td>{a['bucket']}</td><td style='text-align:right'>${float(a['amount']):.2f}</td></tr>"
        for _, a in aging.iterrows()
    ])
    html = f"""<!DOCTYPE html><html><head><meta charset='utf-8'><title>Board Finance Packet</title>
    <style>body{{font-family:Arial; max-width:900px; margin:auto}} table{{width:100%; border-collapse:collapse}} td,th{{border-bottom:1px solid #ddd; padding:8px}}</style>
    </head><body>
    <h2>Board Finance Packet</h2>
    <p><em>As of {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</em></p>
    <h3>KPIs</h3>
    <ul><li>Paid: ${kpis['paid']:.2f}</li><li>Open/Unpaid: ${kpis['open']:.2f}</li><li>All Time: ${kpis['total']:.2f}</li></ul>
    <h3>A/R Aging</h3>
    <table><thead><tr><th>Bucket</th><th>Amount</th></tr></thead><tbody>{aging_rows}</tbody></table>
    <h3>Recent Transactions (Top 10)</h3>
    <table><thead><tr><th>Date</th><th>Invoice</th><th>Org</th><th>Amount</th><th>Status</th></tr></thead><tbody>{recent_rows}</tbody></table>
    </body></html>"""
    with open(html_path, "w") as f:
        f.write(html)
    generated["html"] = html_path
    return generated
