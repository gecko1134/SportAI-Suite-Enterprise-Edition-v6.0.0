
import os
import streamlit as st
import pandas as pd

from modules.finance.board_packet import generate_board_packet
from modules.pricing.qb_journal_export import export_qb_journal_csv

def run_board_packet_tab():
    st.header("Board Finance Packet")
    st.caption("Generate a board-ready packet with KPIs, A/R aging, and recent transactions.")
    if st.button("Generate Packet (PDF/HTML)"):
        try:
            files = generate_board_packet()
            if "pdf" in files and os.path.exists(files["pdf"]):
                with open(files["pdf"], "rb") as f:
                    st.download_button("Download Board Packet PDF", data=f.read(), file_name=os.path.basename(files["pdf"]), mime="application/pdf")
            if "html" in files and os.path.exists(files["html"]):
                with open(files["html"], "rb") as f:
                    st.download_button("Download Board Packet HTML", data=f.read(), file_name=os.path.basename(files["html"]), mime="text/html")
            st.success("Packet generated.")
        except FileNotFoundError as e:
            st.error(str(e))

def run_qb_import_tab():
    st.header("QuickBooks Import")
    st.caption("Create a journal CSV from the payments ledger for QuickBooks import.")
    if st.button("Build QB Journal CSV"):
        try:
            path = export_qb_journal_csv("exports/qb_journal_export.csv")
            with open(path, "rb") as f:
                st.download_button("Download QuickBooks Journal CSV", data=f.read(), file_name="qb_journal_export.csv", mime="text/csv")
            st.success("CSV ready.")
        except FileNotFoundError as e:
            st.error(str(e))
