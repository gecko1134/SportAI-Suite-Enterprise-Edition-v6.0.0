
# SportAI Finance Suite — Board Packet + QuickBooks Import

New tabs (add to Finance Tools):
- `run_board_packet_tab()` — one-click **Board Finance Packet** (PDF if `reportlab` installed, else HTML).
- `run_qb_import_tab()` — one-click **QuickBooks Journal CSV** using the payments ledger.

## Wire into `main_app.py`
```python
from modules.finance.finance_suite import run_finance_overview_tab, run_ar_aging_report_tab
from modules.finance.finance_suite_plus import run_board_packet_tab, run_qb_import_tab

if category == "Finance Tools":
    tool = st.sidebar.radio("Finance Tools", [
        "Finance Overview", "A/R Aging Report", "Board Finance Packet", "QuickBooks Import"
    ])
    if tool == "Finance Overview":
        run_finance_overview_tab()
    elif tool == "A/R Aging Report":
        run_ar_aging_report_tab()
    elif tool == "Board Finance Packet":
        run_board_packet_tab()
    else:
        run_qb_import_tab()
```
