# Implementation Guide

This guide shows how to integrate the forecasting pipeline with your SportsKey exports and operational workflows.

## Pipeline
1. **Feature Engineering** → merges bookings + calendar + weather into hourly rows per resource.
2. **Forecasting (baseline)** → trains a simple classifier to estimate probability of occupancy per hour.
3. **Recommendations** → converts utilization forecasts to price nudges, holds/merges, and staffing plans.
4. **Weekly Report** → compact KPI summary for staff/board.
5. **Dashboard** → visualize heatmaps, pricing/staffing, and export reports.

## Integrations
- **SportsKey**: start with CSV exports; later, swap loaders to API pulls.
- **Email (SendGrid)**: use `src/email_templates/weekly_summary.html` with your sender.
- **Staff Schedules**: export CSV to your scheduling tool.
- **Pricing**: push deltas to your rate tables or send promo codes for off-peak blocks.

## Tuning
- Adjust thresholds in `config/app_config.yaml`.
- Add features (e.g., school breaks, tournaments) to improve accuracy.
- Replace `forecast_baseline.py` with Prophet/XGBoost for stronger seasonality handling.
