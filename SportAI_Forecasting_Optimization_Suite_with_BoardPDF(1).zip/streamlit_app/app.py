import streamlit as st
import pandas as pd
import yaml
from pathlib import Path

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet

def generate_board_pdf(recs_df, facility_name:str, out_path:str):
    styles = getSampleStyleSheet()
    avg_util = float(recs_df['pred_utilization'].mean()) if not recs_df.empty else 0.0
    low_hours = int((recs_df['pred_utilization'] < 0.55).sum()) if not recs_df.empty else 0
    high_hours = int((recs_df['pred_utilization'] > 0.85).sum()) if not recs_df.empty else 0

    data = [
        ["Metric", "Value"],
        ["Average Forecasted Utilization", f"{avg_util*100:.1f}%"],
        ["Low-Util Hours (<55%)", low_hours],
        ["High-Util Hours (>85%)", high_hours],
    ]

    doc = SimpleDocTemplate(out_path, pagesize=letter)
    story = []
    story.append(Paragraph("<b>SportAI Weekly Board Report</b>", styles["Title"]))
    story.append(Spacer(1, 12))
    story.append(Paragraph(f"{facility_name}", styles["Heading2"]))
    story.append(Spacer(1, 12))
    story.append(Paragraph("Summary of key utilization and staffing metrics for board review.", styles["BodyText"]))
    story.append(Spacer(1, 18))

    table = Table(data, hAlign="LEFT")
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0F172A")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.whitesmoke),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
    ]))
    story.append(table)
    story.append(Spacer(1, 18))

    story.append(Paragraph("Next Steps & Recommendations", styles["Heading2"]))
    bullets = "<ul><li>Activate dynamic pricing on off-peak hours below 55% utilization.</li><li>Increase staffing coverage during projected 85%+ utilization hours.</li><li>Align cleaning/maintenance windows with forecast dips.</li><li>Enable automated weekly delivery via SendGrid.</li></ul>"
    story.append(Paragraph(bullets, styles["BodyText"]))
    doc.build(story)
    return out_path


st.set_page_config(page_title='SportAI Facility Optimizer', layout='wide')

st.title('SportAI Facility Optimizer — Forecasting & Actions')

cfg_path = Path('config/app_config.yaml')
with open(cfg_path, 'r') as f:
    cfg = yaml.safe_load(f)

st.sidebar.header('Config')
st.sidebar.write(cfg['facility_name'])
st.sidebar.code(str(cfg_path), language='yaml')

tab1, tab2, tab3 = st.tabs(['Utilization Heatmap','Pricing & Staffing','Reports'])

@st.cache_data
def load_data():
    feats = Path(cfg['paths']['features_out'])
    fcst  = Path(cfg['paths']['forecasts_out'])
    recs  = Path(cfg['paths']['recs_out'])
    df_feats = pd.read_parquet(feats) if feats.exists() else pd.DataFrame()
    df_fcst  = pd.read_parquet(fcst) if fcst.exists() else pd.DataFrame()
    df_recs  = pd.read_csv(recs) if recs.exists() else pd.DataFrame()
    return df_feats, df_fcst, df_recs

df_feats, df_fcst, df_recs = load_data()

with tab1:
    st.subheader('Forecasted Utilization by Hour (sample)')
    if df_fcst.empty:
        st.info('No forecasts found. Run the pipeline to generate outputs.')
    else:
        pivot = df_fcst.pivot_table(index=df_fcst['date_hour'].dt.date, columns=df_fcst['date_hour'].dt.hour, values='pred_utilization', aggfunc='mean')
        st.dataframe((pivot*100).round(1))

with tab2:
    st.subheader('Recommended Pricing & Staffing')
    if df_recs.empty:
        st.info('No recommendations yet.')
    else:
        st.dataframe(df_recs)


with tab3:
    st.subheader('Weekly Report')
    rp = Path(cfg['paths']['report_out'])
    if rp.exists():
        st.download_button('Download Weekly Report (Markdown)', rp.read_bytes(), file_name='weekly_report.md')
    else:
        st.info('Report not generated yet.')

    st.markdown('---')
    st.subheader('Board PDF')
    if df_recs.empty:
        st.info('Generate recommendations first to build the board PDF.')
    else:
        if st.button('Generate Board PDF'):
            pdf_path = Path('data/derived/board_report.pdf')
            pdf_path.parent.mkdir(parents=True, exist_ok=True)
            out = generate_board_pdf(df_recs, cfg['facility_name'], str(pdf_path))
            st.success('Board PDF created.')
            with open(out, 'rb') as f:
                st.download_button('Download Board PDF', f.read(), file_name='SportAI_Weekly_Board_Report.pdf')
    rp = Path(cfg['paths']['report_out'])
    if rp.exists():
        st.download_button('Download Weekly Report (Markdown)', rp.read_bytes(), file_name='weekly_report.md')
    else:
        st.info('Report not generated yet.')
