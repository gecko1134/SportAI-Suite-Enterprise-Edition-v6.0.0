
# SportAI Pricing Pro Pack — Extended

**New modules:**
- `invoice_generator.py` — PDF/HTML invoices with auto payment link builder.
- `auto_renewal_engine.py` — scan contracts CSV, flag expiring, and build HTML alert emails.
- `pricing_suite_plus.py` — new tabs:
  - `run_invoice_generator_tab()`
  - `run_auto_renewal_tab()`

**Templates & Samples**
- `templates/email/renewal_email_template.html`
- `modules/pricing/contracts_sample.csv`

**Wire into main_app.py:**
```python
from modules.pricing.pricing_suite_ext import (
    run_dynamic_pricing_tab,
    run_quote_emailer_tab,
    run_deal_summary_tab,
    run_live_requests_tab,
)
from modules.pricing.pricing_suite_plus import (
    run_invoice_generator_tab,
    run_auto_renewal_tab,
)

if category == "Pricing Tools":
    tool = st.sidebar.radio("Pricing Tools", [
        "Dynamic Pricing", "Quote Emailer", "Deal Summary", "Live Requests",
        "Invoice Generator", "Auto-Renewal Alerts"
    ])
    if tool == "Dynamic Pricing":
        run_dynamic_pricing_tab()
    elif tool == "Quote Emailer":
        run_quote_emailer_tab()
    elif tool == "Deal Summary":
        run_deal_summary_tab()
    elif tool == "Live Requests":
        run_live_requests_tab()
    elif tool == "Invoice Generator":
        run_invoice_generator_tab()
    else:
        run_auto_renewal_tab()
```
