
"""
Auto-Renewal Alerts:
- Parses a contracts CSV and flags items approaching renewal window.
- Builds email payloads using a simple HTML template.
CSV expected columns:
contract_id, org_name, contact_name, email, asset, start_date, end_date, renewal_terms, annual_value, status
"""
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Any

def load_contracts_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["start_date"] = pd.to_datetime(df["start_date"], errors="coerce")
    df["end_date"] = pd.to_datetime(df["end_date"], errors="coerce")
    return df

def flag_upcoming(df: pd.DataFrame, days_out: int = 60) -> pd.DataFrame:
    today = pd.Timestamp(datetime.now().date())
    window_end = today + pd.Timedelta(days=days_out)
    mask = (df["end_date"] >= today) & (df["end_date"] <= window_end) & (df["status"].str.lower().isin(["active","expiring"]))
    return df[mask].copy()

def build_alert_email(row: pd.Series, template_html: str) -> Dict[str, Any]:
    html = template_html
    fields = {
        "org_name": row.get("org_name",""),
        "contact_name": row.get("contact_name",""),
        "asset": row.get("asset",""),
        "end_date": row.get("end_date",""),
        "annual_value": row.get("annual_value",""),
        "renewal_terms": row.get("renewal_terms",""),
        "contract_id": row.get("contract_id",""),
    }
    for k,v in fields.items():
        html = html.replace("{{"+k+"}}", str(v))
    subject = f"Renewal Reminder — Contract {fields['contract_id']}"
    return {"to_email": row.get("email",""), "subject": subject, "html": html}

