
import os, json
import pandas as pd
import streamlit as st

from .invoice_generator import generate_invoice
from .auto_renewal_engine import load_contracts_csv, flag_upcoming, build_alert_email

def run_invoice_generator_tab():
    st.header("Invoice Generator + Payment Link")
    left, right = st.columns(2)
    with left:
        invoice_no = st.text_input("Invoice #", "INV-1001")
        bill_to = st.text_input("Bill To", "Demo Org")
        contact = st.text_input("Contact", "Partner")
        email = st.text_input("Email", "partner@example.com")
        due_date = st.text_input("Due Date", "2025-11-30")
        tax_rate = st.number_input("Tax Rate", value=0.0, step=0.01)
        discount = st.number_input("Discount", value=0.0, step=1.0)
        pay_base = st.text_input("Payment URL Base", "https://pay.nxscomplex.org/invoice")

    with right:
        st.subheader("Items")
        items = []
        for i in range(1, 4):
            col1, col2, col3 = st.columns([3,1,1])
            desc = col1.text_input(f"Item {i} Description", f"Turf (hour {i})", key=f"desc_{i}")
            qty = col2.number_input(f"Qty {i}", value=1.0, step=1.0, key=f"qty_{i}")
            unit = col3.number_input(f"Unit ${i}", value=150.0, step=5.0, key=f"unit_{i}")
            items.append({"desc": desc, "qty": qty, "unit_price": unit})

    notes = st.text_area("Notes", "Thanks for choosing us!")
    if st.button("Generate Invoice"):
        data = {
            "invoice_no": invoice_no, "bill_to": bill_to, "contact": contact, "email": email,
            "items": items, "tax_rate": tax_rate, "discount": discount,
            "due_date": due_date, "notes": notes, "payment_link_base": pay_base
        }
        files = generate_invoice(data, out_dir="modules/pricing/exports")
        if "pdf" in files:
            with open(files["pdf"], "rb") as f:
                st.download_button("Download PDF Invoice", data=f.read(), file_name=os.path.basename(files["pdf"]), mime="application/pdf")
        if "html" in files:
            with open(files["html"], "rb") as f:
                st.download_button("Download HTML Invoice", data=f.read(), file_name=os.path.basename(files["html"]), mime="text/html")
        st.success(f"Payment link: {files.get('payment_link','')} (Total: ${files.get('total','')})")
        st.code(files.get("payment_link",""), language="text")

def run_auto_renewal_tab():
    st.header("Auto-Renewal Alerts")
    st.caption("Upload a contracts CSV or use the sample, then generate alert emails for deals expiring in N days.")
    upl = st.file_uploader("Contracts CSV", type=["csv"])
    if upl:
        open_path = "modules/pricing/_uploaded_contracts.csv"
        with open(open_path, "wb") as f: f.write(upl.read())
        df = load_contracts_csv(open_path)
    else:
        df = load_contracts_csv("modules/pricing/contracts_sample.csv")

    st.dataframe(df.head(20), use_container_width=True)
    days = st.slider("Days ahead to check", 7, 180, 60, 1)
    flagged = flag_upcoming(df, days_out=days)
    st.subheader("Expiring Soon")
    st.dataframe(flagged, use_container_width=True)

    if not flagged.empty:
        with open("templates/email/renewal_email_template.html", "r") as f:
            tmpl = f.read()
        idx = st.number_input("Row index to build email for", min_value=0, max_value=len(flagged)-1, value=0, step=1)
        sel = flagged.iloc[int(idx)]
        payload = build_alert_email(sel, tmpl)
        st.subheader("Email Payload")
        st.write(f"To: {payload['to_email']}")
        st.write(f"Subject: {payload['subject']}")
        st.download_button("Download HTML Email", data=payload["html"].encode("utf-8"), file_name="renewal_email.html", mime="text/html")
