
"""
Invoice generator with payment link builder.
- PDF via reportlab if available, else HTML fallback.
- Payment link builder supports external processor (e.g., Stripe) via simple URL composition.
"""
import os, datetime, urllib.parse
from typing import Dict, Any

def build_payment_link(base_url: str, params: Dict[str, Any]) -> str:
    """
    Construct a payment URL with query params.
    Example base_url: https://pay.nxscomplex.org/invoice
    """
    return base_url.rstrip("/") + "?" + urllib.parse.urlencode(params)

def generate_invoice(data: Dict[str, Any], out_dir: str) -> Dict[str, str]:
    """
    data = {
      "invoice_no": "INV-0001",
      "bill_to": "Demo Org",
      "contact": "Partner",
      "email": "partner@example.com",
      "items": [{"desc":"Turf (2 hrs)", "qty":2, "unit_price":150.0}],
      "tax_rate": 0.0,
      "discount": 0.0,
      "due_date": "2025-11-30",
      "notes": "Thanks for choosing us!",
      "payment_link_base": "https://pay.nxscomplex.org/invoice"
    }
    """
    os.makedirs(out_dir, exist_ok=True)
    fname_base = data.get("invoice_no", "invoice").replace("#","").replace(" ","_")
    pdf_path = os.path.join(out_dir, f"{fname_base}.pdf")
    html_path = os.path.join(out_dir, f"{fname_base}.html")
    generated = {}

    # compute totals
    subtotal = sum(float(it.get("qty",1)) * float(it.get("unit_price",0)) for it in data.get("items",[]))
    discount = float(data.get("discount", 0.0))
    taxed = max(0.0, subtotal - discount)
    tax_rate = float(data.get("tax_rate", 0.0))
    tax = taxed * tax_rate
    total = taxed + tax

    # Payment link
    pay_params = {
        "invoice": data.get("invoice_no",""),
        "amount": f"{total:.2f}",
        "org": data.get("bill_to",""),
        "email": data.get("email","")
    }
    payment_link = build_payment_link(data.get("payment_link_base","https://pay.nxscomplex.org/invoice"), pay_params)

    # Try PDF
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import inch

        c = canvas.Canvas(pdf_path, pagesize=LETTER)
        width, height = LETTER
        y = height - 1*inch
        c.setFont("Helvetica-Bold", 16)
        c.drawString(1*inch, y, f"Invoice {data.get('invoice_no','')}")
        y -= 0.3*inch
        c.setFont("Helvetica", 10)
        c.drawString(1*inch, y, f"Bill To: {data.get('bill_to','')}  |  Contact: {data.get('contact','')}  |  Email: {data.get('email','')}")
        y -= 0.2*inch
        c.drawString(1*inch, y, f"Due Date: {data.get('due_date','')}  |  Generated: {datetime.datetime.now().strftime('%Y-%m-%d')}")
        y -= 0.3*inch

        c.setFont("Helvetica-Bold", 11)
        c.drawString(1*inch, y, "Items")
        y -= 0.2*inch
        c.setFont("Helvetica", 10)
        for it in data.get("items", []):
            line = f"- {it.get('desc','')} | Qty: {it.get('qty',1)} | Unit: ${float(it.get('unit_price',0)):.2f}"
            c.drawString(1*inch, y, line); y -= 0.2*inch
            if y < 1*inch: c.showPage(); y = height - 1*inch

        y -= 0.1*inch
        c.drawString(1*inch, y, f"Subtotal: ${subtotal:.2f}  |  Discount: ${discount:.2f}  |  Tax: ${tax:.2f}  |  Total: ${total:.2f}")
        y -= 0.2*inch
        c.drawString(1*inch, y, f"Payment Link: {payment_link}")
        y -= 0.2*inch
        c.drawString(1*inch, y, f"Notes: {data.get('notes','')}")
        c.showPage(); c.save()
        generated["pdf"] = pdf_path
    except Exception:
        pass

    # HTML fallback
    html = f"""<!DOCTYPE html><html><head><meta charset='utf-8'><title>Invoice {data.get('invoice_no','')}</title>
    <style>body{{font-family:Arial, sans-serif; max-width:700px;margin:auto; line-height:1.6}}</style></head><body>
    <h2>Invoice {data.get('invoice_no','')}</h2>
    <p><strong>Bill To:</strong> {data.get('bill_to','')} &nbsp; | &nbsp; <strong>Contact:</strong> {data.get('contact','')} &nbsp; | &nbsp; <strong>Email:</strong> {data.get('email','')}</p>
    <p><strong>Due Date:</strong> {data.get('due_date','')}</p>
    <h3>Items</h3>
    <ul>
    {''.join([f"<li>{it.get('desc','')} — Qty {it.get('qty',1)} × ${float(it.get('unit_price',0)):.2f}</li>" for it in data.get('items',[])])}
    </ul>
    <p><strong>Subtotal:</strong> ${subtotal:.2f} &nbsp; <strong>Discount:</strong> ${discount:.2f} &nbsp; <strong>Tax:</strong> ${tax:.2f} &nbsp; <strong>Total:</strong> ${total:.2f}</p>
    <p><a href="{payment_link}">Pay Now</a></p>
    <hr><p style="font-size:12px;color:#666;">Thank you for your business.</p></body></html>"""
    with open(html_path, "w") as f:
        f.write(html)
    generated["html"] = html_path
    generated["payment_link"] = payment_link
    generated["total"] = f"{total:.2f}"
    return generated
