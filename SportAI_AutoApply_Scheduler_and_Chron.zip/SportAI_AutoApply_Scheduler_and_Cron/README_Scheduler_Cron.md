# Auto-Apply Scheduler Hook + Cron Email

## 1) Auto-Apply based on promote flags
Run:
```bash
python scheduler_hook.py -- (no args)
```
What it does:
- Reads `promote_flags.json` and `shadow_logs.csv`.
- Filters to assets with `status: "auto"`.
- Applies suggestions that pass guardrails by calling `apply_change()` — replace this with your SportsKey/API update.
- Skips suggestions with violations or missing `would_do_action`.

## 2) Board PDF email via SendGrid (cron-friendly)
```bash
export SENDGRID_API_KEY=YOUR_KEY
python board_email_cli.py --logs /path/to/shadow_logs.csv --actuals /path/to/actuals.csv \  --from no-reply@nxscomplex.org --to board@example.com,chair@example.com \  --subject "NXS — Board Snapshot" --body "Attached is the latest board snapshot."
```

### Example crontab (runs every Friday at 2:15pm)
```
# America/Chicago
15 14 * * FRI cd /opt/sportai && /usr/bin/env -S /bin/bash -lc 'export SENDGRID_API_KEY=YOUR_KEY && python board_email_cli.py --logs /opt/sportai/shadow_logs.csv --from no-reply@nxscomplex.org --to board@example.com'
```

## Integrating with Streamlit app
- The Streamlit **Asset Promotion** tab writes `promote_flags.json`.
- `scheduler_hook.py` reads the same file so rules stay in sync.
