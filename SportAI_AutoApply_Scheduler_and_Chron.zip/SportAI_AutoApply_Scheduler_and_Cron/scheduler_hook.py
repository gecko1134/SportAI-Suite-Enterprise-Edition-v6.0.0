"""
scheduler_hook.py
-----------------
Reads promote_flags.json and a shadow_logs.csv, filters for assets with status "auto",
and calls your apply function for each suggestion that passes guardrails.

Plug points:
- replace `apply_change(suggestion)` with your real scheduler/API call (e.g., SportsKey update).
- extend `violates_guardrails` to include compliance and blackout checks.
"""

import csv, json, os
from typing import Dict, Any, List

PROMOTE_FLAGS_PATH = "promote_flags.json"
GUARDRAILS_PATH = "guardrails_config.yaml"  # optional
SHADOW_LOGS_PATH = "shadow_logs.csv"

def load_promote_flags(path=PROMOTE_FLAGS_PATH) -> Dict[str, Dict[str, str]]:
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def violates_guardrails(sug: Dict[str, Any], price_floor: float = 75.0, price_ceiling: float = 450.0) -> List[str]:
    flags = []
    try:
        price = float(sug.get("suggested_price", 0))
        if price < price_floor: flags.append("PRICE_FLOOR")
        if price > price_ceiling: flags.append("PRICE_CEILING")
    except Exception:
        pass
    # TODO: add league/city compliance checks; blackout window checks
    return flags

def apply_change(suggestion: Dict[str, Any]) -> bool:
    """
    Stub: Replace with your real scheduler call.
    Example: POST to SportsKey API / update booking price / layout / pod.
    Return True if successfully applied.
    """
    # print or log here; integrate actual API call in production
    print(f"[APPLY] {suggestion.get('suggestion_id')} → asset={suggestion.get('asset_id')} price={suggestion.get('suggested_price')} action={suggestion.get('would_do_action')}")
    return True

def iterate_auto_apply(shadow_logs_csv: str = SHADOW_LOGS_PATH, promote_flags_path: str = PROMOTE_FLAGS_PATH) -> int:
    flags = load_promote_flags(promote_flags_path)
    auto_assets = {a for a, meta in flags.items() if isinstance(meta, dict) and meta.get("status") == "auto"}
    if not auto_assets:
        print("[INFO] No assets set to AUTO. Exiting.")
        return 0
    applied = 0
    with open(shadow_logs_csv, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if row.get("asset_id") not in auto_assets:
                continue
            # guardrails
            viol = violates_guardrails(row)
            if viol:
                print(f"[SKIP] {row.get('suggestion_id')} guardrail violations: {viol}")
                continue
            # only apply if would_do_action present (you can add more logic e.g., confidence thresholds)
            if not row.get("would_do_action"):
                print(f"[SKIP] {row.get('suggestion_id')} no action specified.")
                continue
            if apply_change(row):
                applied += 1
    print(f"[DONE] Applied {applied} suggestions.")
    return applied

if __name__ == "__main__":
    iterate_auto_apply()
