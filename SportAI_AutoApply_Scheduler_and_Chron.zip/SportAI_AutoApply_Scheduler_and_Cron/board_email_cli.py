"""
board_email_cli.py
------------------
Generates a Board Snapshot PDF from shadow_logs.csv (+ optional actuals.csv)
and emails it via SendGrid.

Usage:
  python board_email_cli.py --logs shadow_logs.csv --actuals actuals.csv \
      --from no-reply@nxscomplex.org --to board1@example.com,board2@example.com \
      --subject "NXS — Board Snapshot" --body "Attached is the latest snapshot."

Environment:
  SENDGRID_API_KEY must be set.
"""

import os, io, json, argparse, base64, datetime, hashlib
import pandas as pd
import numpy as np
import requests
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas

def mape(y_true, y_pred):
    y_true = np.array(y_true, dtype=float)
    y_pred = np.array(y_pred, dtype=float)
    mask = y_true != 0
    if mask.sum() == 0:
        return np.nan
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100.0

def load_joined_dataframe(logs, actuals):
    df = pd.read_csv(logs)
    if actuals and os.path.exists(actuals):
        act = pd.read_csv(actuals)
        if "suggestion_id" in act.columns and "suggestion_id" in df.columns:
            df = df.merge(act, on="suggestion_id", how="left", suffixes=("","_actfile"))
            for tgt, src in [("actual_revenue","actual_revenue_actfile"),
                             ("actual_utilization","actual_utilization_actfile"),
                             ("actual_sponsor_hits","actual_sponsor_hits_actfile")]:
                if src in df.columns and tgt in df.columns:
                    df[tgt] = df[tgt].fillna(df[src])
        elif set(["asset_id","time_block_start","time_block_end"]).issubset(act.columns):
            df = df.merge(act, on=["asset_id","time_block_start","time_block_end"], how="left", suffixes=("","_actfile"))
    return df

def build_pdf(df, facility_name="NXS National Sports Complex"):
    price_floor, price_ceiling = 75, 450
    mape_rev = mape(df["actual_revenue"].fillna(0), df["predicted_revenue"].fillna(0)) if "actual_revenue" in df.columns else np.nan
    mape_util = mape(df["actual_utilization"].fillna(0), df["predicted_utilization"].fillna(0)) if "actual_utilization" in df.columns else np.nan
    avg_lift = ((df["actual_revenue"].fillna(0) - df["predicted_revenue"].fillna(0)) / df["predicted_revenue"].replace(0,np.nan) * 100.0).replace([np.inf,-np.inf], np.nan).mean()

    buff = io.BytesIO()
    c = canvas.Canvas(buff, pagesize=LETTER)
    w, h = LETTER; y = h - 72
    def line(txt, dy=16, font="Times-Roman", size=11):
        nonlocal y; c.setFont(font, size); c.drawString(72, y, txt); y -= dy

    today = datetime.date.today().strftime("%Y-%m-%d")
    line(f"{facility_name} — Board Snapshot", dy=20, font="Times-Bold", size=14)
    line(f"Date: {today}")
    line(f"Shadow Suggestions Logged: {len(df):,}")

    line("Key Metrics", dy=18, font="Times-Bold", size=12)
    line(f"Revenue MAPE: {mape_rev:.2f}%  |  Utilization MAPE: {mape_util:.2f}%  |  Avg Net Lift: {avg_lift:.2f}%")

    guard_viol = 0
    if "suggested_price" in df.columns:
        sp = pd.to_numeric(df["suggested_price"], errors="coerce")
        guard_viol = int(((sp < price_floor) | (sp > price_ceiling)).sum())
    line("Guardrail Alerts", dy=18, font="Times-Bold", size=12)
    line(f"Price floor/ceiling violations: {guard_viol} (floor=${price_floor}, ceiling=${price_ceiling})")

    c.showPage(); c.save()
    return buff.getvalue()

def send_sendgrid(from_email, to_emails, subject, body, pdf_bytes):
    api_key = os.environ.get("SENDGRID_API_KEY","")
    if not api_key:
        raise RuntimeError("SENDGRID_API_KEY not set")
    payload = {
        "personalizations": [{"to": [{"email": e.strip()} for e in to_emails.split(",") if e.strip()]}],
        "from": {"email": from_email},
        "subject": subject,
        "content": [{"type": "text/plain", "value": body}],
        "attachments": [{
            "content": base64.b64encode(pdf_bytes).decode("utf-8"),
            "type": "application/pdf",
            "filename": "Board_Snapshot.pdf"
        }]
    }
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    resp = requests.post("https://api.sendgrid.com/v3/mail/send", headers=headers, json=payload, timeout=20)
    if resp.status_code not in (200, 202):
        raise RuntimeError(f"SendGrid error: {resp.status_code} {resp.text}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--logs", required=True, help="Path to shadow_logs.csv")
    ap.add_argument("--actuals", default="", help="Path to actuals.csv (optional)")
    ap.add_argument("--from", dest="from_email", required=True, help="From email")
    ap.add_argument("--to", dest="to_emails", required=True, help="Comma-separated recipients")
    ap.add_argument("--subject", default="NXS — Board Snapshot", help="Email subject")
    ap.add_argument("--body", default="Attached is the latest board snapshot.", help="Email plaintext body")
    args = ap.parse_args()

    df = load_joined_dataframe(args.logs, args.actuals)
    pdf_bytes = build_pdf(df)
    send_sendgrid(args.from_email, args.to_emails, args.subject, args.body, pdf_bytes)
    print("Sent Board Snapshot via SendGrid.")
