
# SportAI Pricing Pro Pack

### New tools
- **Quote Emailer (SendGrid)** — builds HTML email payloads (no network calls here).
- **Deal Summary Generator** — creates PDF (if reportlab installed) or HTML fallback.
- **Live Requests (SportsKey)** — stub module to wire into your real API.

### Directory
```
modules/pricing/
  ├─ dynamic_pricing_engine.py
  ├─ pricing_guardrails.json
  ├─ sample_requests.csv
  ├─ sendgrid_emailer.py
  ├─ pdf_deal_summary.py
  ├─ sportskey_api_stub.py
  └─ pricing_suite_ext.py   # run_* tabs for: Dynamic Pricing, Quote Emailer, Deal Summary, Live Requests
templates/email/
  └─ quote_email_template.html
```

### main_app.py wiring
```python
from modules.pricing.pricing_suite_ext import (
    run_dynamic_pricing_tab,
    run_quote_emailer_tab,
    run_deal_summary_tab,
    run_live_requests_tab,
)

# In your category routing under "Pricing Tools":
tool = st.sidebar.radio("Pricing Tools", [
    "Dynamic Pricing",
    "Quote Emailer",
    "Deal Summary",
    "Live Requests"
])

if tool == "Dynamic Pricing":
    run_dynamic_pricing_tab()
elif tool == "Quote Emailer":
    run_quote_emailer_tab()
elif tool == "Deal Summary":
    run_deal_summary_tab()
else:
    run_live_requests_tab()
```

### Notes
- Set `SENDGRID_API_KEY` in your environment for production; this pack only builds the JSON body.
- For PDF creation, install `reportlab`: `pip install reportlab`. Otherwise you'll get an HTML file.
- Replace `sportskey_api_stub.py` calls with your real SportsKey API client.
