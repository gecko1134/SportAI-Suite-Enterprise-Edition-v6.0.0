
"""
SendGrid emailer (admin/analyst use). Requires SENDGRID_API_KEY environment variable.
In Streamlit Cloud, set it under Secrets. Locally, export it before running.
"""
import os
import json
from typing import Dict, Any, List

def render_template(html_template: str, context: Dict[str, Any]) -> str:
    html = html_template
    for k, v in context.items():
        html = html.replace("{{"+k+"}}", str(v))
    return html

def build_quote_email(context: Dict[str, Any], template_path: str) -> Dict[str, Any]:
    with open(template_path, "r") as f:
        html_template = f.read()
    html = render_template(html_template, context)
    subject = context.get("subject", "Your Quote from National Sports Dome & Performance Complex")
    to_email = context.get("to_email")
    from_email = context.get("from_email", "quotes@nxscomplex.org")
    data = {"subject": subject, "to_email": to_email, "from_email": from_email, "html": html}
    return data

def send_via_sendgrid(email_payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    This function returns the HTTP request body you would send to SendGrid.
    We do not perform the network request in this environment.
    """
    to_email = email_payload["to_email"]
    from_email = email_payload["from_email"]
    subject = email_payload["subject"]
    html = email_payload["html"]

    sg_body = {
        "personalizations": [{"to": [{"email": to_email}], "subject": subject}],
        "from": {"email": from_email, "name": "National Sports Dome & Performance Complex"},
        "content": [{"type": "text/html", "value": html}]
    }
    # In production, you'd do: requests.post("https://api.sendgrid.com/v3/mail/send", headers=..., json=sg_body)
    return sg_body
