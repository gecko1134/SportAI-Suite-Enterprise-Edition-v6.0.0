
"""
Deal summary generator.
- Preferred: PDF via reportlab (if available)
- Fallback: HTML file (print-ready)
"""
import os, datetime, json
from typing import Dict, Any

def generate_summary_files(data: Dict[str, Any], out_dir: str) -> Dict[str, str]:
    os.makedirs(out_dir, exist_ok=True)
    title = data.get("title", "Booking Deal Summary")
    fname_base = data.get("file_base", "deal_summary")

    # Try PDF (reportlab)
    pdf_path = os.path.join(out_dir, f"{fname_base}.pdf")
    html_path = os.path.join(out_dir, f"{fname_base}.html")
    generated = {}

    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import inch

        c = canvas.Canvas(pdf_path, pagesize=LETTER)
        width, height = LETTER
        y = height - 1*inch
        c.setFont("Helvetica-Bold", 16)
        c.drawString(1*inch, y, title)
        y -= 0.4*inch
        c.setFont("Helvetica", 10)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        c.drawString(1*inch, y, f"Generated: {stamp}")
        y -= 0.3*inch

        # key fields
        for key in ["org_name","contact","asset","start_dt","duration_hours","quoted_price","ai_recommended","shadow_price","rationale"]:
            val = str(data.get(key, ""))
            if val:
                c.drawString(1*inch, y, f"{key.replace('_',' ').title()}: {val}")
                y -= 0.25*inch
                if y < 1*inch:
                    c.showPage()
                    y = height - 1*inch
        c.showPage()
        c.save()
        generated["pdf"] = pdf_path
    except Exception:
        pass

    # Always generate HTML fallback
    html = f"""<!DOCTYPE html><html><head><meta charset='utf-8'><title>{title}</title>
    <style>body{{font-family:Arial, sans-serif; max-width:700px;margin:auto; line-height:1.6}}</style>
    </head><body>
      <h2>{title}</h2>
      <p><strong>Organization:</strong> {data.get('org_name','')}</p>
      <p><strong>Contact:</strong> {data.get('contact','')}</p>
      <p><strong>Asset:</strong> {data.get('asset','')}</p>
      <p><strong>Start:</strong> {data.get('start_dt','')}</p>
      <p><strong>Duration (hrs):</strong> {data.get('duration_hours','')}</p>
      <p><strong>Quoted:</strong> ${data.get('quoted_price','')}</p>
      <p><strong>AI Recommended:</strong> ${data.get('ai_recommended','')}</p>
      <p><strong>Shadow Price:</strong> ${data.get('shadow_price','')}</p>
      <p><strong>Rationale:</strong> {data.get('rationale','')}</p>
      <hr>
      <p style="font-size:12px;color:#666;">This summary is for internal review and client confirmation.</p>
    </body></html>"""
    with open(html_path, "w") as f:
        f.write(html)
    generated["html"] = html_path

    return generated
