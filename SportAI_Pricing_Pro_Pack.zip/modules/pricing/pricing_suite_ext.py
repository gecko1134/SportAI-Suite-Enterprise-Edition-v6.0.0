
import json, os
import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt

from .dynamic_pricing_engine import DynamicPricingEngine
from .sendgrid_emailer import build_quote_email, send_via_sendgrid
from .pdf_deal_summary import generate_summary_files
from .sportskey_api_stub import fetch_recent_requests, push_quote_decision

def _load_guardrails(uploaded_json=None, default_path="modules/pricing/pricing_guardrails.json"):
    if uploaded_json is not None:
        return json.loads(uploaded_json.read().decode("utf-8"))
    try:
        with open(default_path, "r") as f:
            return json.load(f)
    except Exception:
        return {"floors":{}, "ceilings":{}, "discounts":{}, "prime_hours":{}, "weather_cap_multiplier":1.10}

def run_dynamic_pricing_tab():
    st.header("Dynamic Pricing — Shadow Mode")
    colA, colB = st.columns(2)
    with colA:
        upl_guard = st.file_uploader("Guardrails JSON (optional)", type=["json"], key="dp_guard")
    with colB:
        weight = st.slider("Adopt model weight (shadow blend)", 0.0, 1.0, 0.25, 0.05)

    guardrails = _load_guardrails(upl_guard)
    upl = st.file_uploader("Upload Requests CSV", type=["csv"], key="dp_csv")
    if upl:
        df = pd.read_csv(upl)
    else:
        try:
            df = pd.read_csv("modules/pricing/sample_requests.csv")
        except Exception:
            st.warning("No sample_requests.csv found. Upload a file to proceed.")
            return

    required_cols = ["request_id","asset","start_dt","duration_hours","lead_time_hours",
                     "org_type","quoted_price","final_price","accepted","event_count_nearby","weather_flag"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        st.error(f"Missing columns: {missing}")
        return

    engine = DynamicPricingEngine(guardrails)
    engine.fit(df)

    recs = []
    for _, row in df.iterrows():
        r = engine.recommend(row)
        blended = (1 - weight) * float(row.get("quoted_price", r.recommended_price)) + weight * r.recommended_price
        recs.append({
            "request_id": row["request_id"],
            "asset": row["asset"],
            "start_dt": row["start_dt"],
            "org_type": row["org_type"],
            "quoted_price": float(row["quoted_price"]),
            "ai_recommended": r.recommended_price,
            "shadow_price": round(blended, 2),
            "ai_multiplier": r.multiplier,
            "ai_confidence": r.confidence,
            "rationale": r.rationale,
            "accepted": int(row.get("accepted", 0)),
        })
    out = pd.DataFrame(recs)

    k1,k2,k3,k4 = st.columns(4)
    k1.metric("Rows", len(out))
    k2.metric("Avg Quoted", f"${out['quoted_price'].mean():.2f}")
    k3.metric("Avg AI", f"${out['ai_recommended'].mean():.2f}")
    k4.metric("Avg Shadow", f"${out['shadow_price'].mean():.2f}")

    st.dataframe(out, use_container_width=True)

    st.subheader("Variance: Quoted vs AI by Asset")
    agg = out.groupby("asset")[["quoted_price","ai_recommended"]].mean().reset_index()
    plt.figure()
    x = np.arange(len(agg))
    plt.plot(x, agg["quoted_price"], marker="o", label="Quoted")
    plt.plot(x, agg["ai_recommended"], marker="o", label="AI")
    plt.xticks(x, agg["asset"], rotation=0)
    plt.title("Average Prices by Asset")
    plt.legend()
    st.pyplot(plt.gcf())

    st.subheader("Multiplier Distribution")
    plt.figure()
    plt.hist(out["ai_multiplier"], bins=20)
    plt.title("AI Multiplier Histogram")
    st.pyplot(plt.gcf())

    st.download_button("Download Recommendations CSV", data=out.to_csv(index=False).encode("utf-8"),
                       file_name="ai_pricing_recommendations.csv", mime="text/csv")

    st.markdown("---")
    st.subheader("Quote Email + Deal Summary")
    idx = st.number_input("Row index to prepare", min_value=0, max_value=len(out)-1, value=0, step=1)
    if len(out) > 0:
        sel = out.iloc[int(idx)]
        context = {
            "facility_name": "National Sports Dome & Performance Complex",
            "contact_name": "Partner",
            "asset": sel["asset"],
            "start_dt": sel["start_dt"],
            "duration_hours": sel["start_dt"],
            "quoted_price": sel["quoted_price"],
            "ai_recommended": sel["ai_recommended"],
            "shadow_price": sel["shadow_price"],
            "notes": sel["rationale"],
            "subject": f"Quote for {sel['asset']} on {sel['start_dt']}",
            "to_email": "partner@example.com"
        }
        tmpl_path = "templates/email/quote_email_template.html"
        if not os.path.exists(tmpl_path):
            os.makedirs("templates/email", exist_ok=True)
            with open(tmpl_path, "w") as f:
                f.write("<p>Quote: ${{quoted_price}} (AI: ${{ai_recommended}})</p>")
        payload = build_quote_email(context, tmpl_path)
        st.code(json.dumps(payload, indent=2), language="json")

        # Deal summary files
        files = generate_summary_files({
            "title": "Booking Deal Summary",
            "org_name": "Demo Org",
            "contact": context["contact_name"],
            "asset": sel["asset"],
            "start_dt": sel["start_dt"],
            "duration_hours": 1,
            "quoted_price": sel["quoted_price"],
            "ai_recommended": sel["ai_recommended"],
            "shadow_price": sel["shadow_price"],
            "rationale": sel["rationale"],
            "file_base": "deal_summary_demo"
        }, out_dir="modules/pricing/exports")
        if "pdf" in files:
            with open(files["pdf"], "rb") as f:
                st.download_button("Download PDF Summary", data=f.read(), file_name="deal_summary.pdf", mime="application/pdf")
        if "html" in files:
            with open(files["html"], "rb") as f:
                st.download_button("Download HTML Summary", data=f.read(), file_name="deal_summary.html", mime="text/html")

def run_quote_emailer_tab():
    st.header("Quote Emailer (SendGrid)")
    st.caption("Build and send HTML quote emails. This demo shows the SendGrid JSON payload (no network calls here).")
    to_email = st.text_input("To email", "partner@example.com")
    asset = st.selectbox("Asset", ["turf_full","turf_half","court_full"])
    start_dt = st.text_input("Start (YYYY-mm-dd HH:MM)", "2025-11-15 18:00")
    quoted = st.number_input("Quoted Price", value=250.0, step=5.0)
    ai_val = st.number_input("AI Recommended", value=265.0, step=5.0)
    shadow = st.number_input("Shadow Price", value=258.0, step=5.0)
    notes = st.text_area("Notes", "prime hour / nearby events")
    subject = st.text_input("Subject", f"Quote for {asset} on {start_dt}")
    template_path = "templates/email/quote_email_template.html"
    ctx = {
        "facility_name": "National Sports Dome & Performance Complex",
        "contact_name": "Partner",
        "asset": asset, "start_dt": start_dt, "duration_hours": 1,
        "quoted_price": quoted, "ai_recommended": ai_val, "shadow_price": shadow,
        "notes": notes, "subject": subject, "to_email": to_email
    }
    if st.button("Build email payload"):
        payload = build_quote_email(ctx, template_path)
        sg_body = send_via_sendgrid(payload)
        st.success("Payload built. Use this with SendGrid /mail/send endpoint.")
        st.code(json.dumps(sg_body, indent=2), language="json")

def run_deal_summary_tab():
    st.header("Deal Summary (PDF/HTML)")
    org = st.text_input("Organization", "Demo Org")
    contact = st.text_input("Contact", "Partner")
    asset = st.selectbox("Asset", ["turf_full","turf_half","court_full"])
    start_dt = st.text_input("Start (YYYY-mm-dd HH:MM)", "2025-11-15 18:00")
    quoted = st.number_input("Quoted Price", value=250.0, step=5.0)
    ai_val = st.number_input("AI Recommended", value=265.0, step=5.0)
    shadow = st.number_input("Shadow Price", value=258.0, step=5.0)
    rationale = st.text_area("Rationale", "prime hour / nearby events")
    if st.button("Generate"):
        files = generate_summary_files({
            "title": "Booking Deal Summary",
            "org_name": org, "contact": contact, "asset": asset,
            "start_dt": start_dt, "duration_hours": 1,
            "quoted_price": quoted, "ai_recommended": ai_val,
            "shadow_price": shadow, "rationale": rationale,
            "file_base": "deal_summary_export"
        }, out_dir="modules/pricing/exports")
        if "pdf" in files:
            with open(files["pdf"], "rb") as f:
                st.download_button("Download PDF Summary", data=f.read(), file_name="deal_summary.pdf", mime="application/pdf")
        if "html" in files:
            with open(files["html"], "rb") as f:
                st.download_button("Download HTML Summary", data=f.read(), file_name="deal_summary.html", mime="text/html")

def run_live_requests_tab():
    st.header("Live Requests (SportsKey) — Stub")
    st.caption("Fetch recent requests from SportsKey (replace stub with real API).")
    df = fetch_recent_requests(limit=50)
    if df.empty:
        st.info("No live data returned (stub). Replace with real SportsKey API calls.")
    else:
        st.dataframe(df, use_container_width=True)
    st.markdown("---")
    st.subheader("Push Decision")
    request_id = st.text_input("Request ID", "")
    decision = st.selectbox("Decision", ["Accept","Revise","Reject"])
    price = st.number_input("Price", value=0.0, step=5.0)
    notes = st.text_area("Notes","")
    if st.button("Submit Decision"):
        resp = push_quote_decision(request_id, decision, price, notes)
        st.code(resp, language="json")
