import streamlit as st
import json
from pathlib import Path

# Import the contract generator tab
from sponsor_contract_app import run as contract_generator_run

APP_TITLE = "Sponsor Admin Suite"
USERS_FILE = Path("users.json")

def _load_users():
    if USERS_FILE.exists():
        return json.loads(USERS_FILE.read_text())
    return {"users":[{"email":"admin@nxscomplex.org","password":"admin123","role":"admin"}]}

def login_screen():
    st.title("🔐 Sponsor Admin Login")
    email = st.text_input("Email", value="admin@nxscomplex.org")
    password = st.text_input("Password", type="password", value="admin123")
    if st.button("Sign in"):
        users = _load_users().get("users", [])
        for u in users:
            if u["email"].lower()==email.lower() and u["password"]==password:
                st.session_state["auth"] = {"email": email, "role": u.get("role","admin")}
                st.success("Signed in.")
                st.rerun()
        st.error("Invalid credentials.")
    st.caption("Demo credentials: admin@nxscomplex.org / admin123")

def sidebar_nav():
    st.sidebar.title("Navigation")
    return st.sidebar.radio("Go to", ["Contract Generator", "Renewal Alerts (coming soon)", "Inventory & Pricing (coming soon)"])

def main():
    st.set_page_config(page_title="Sponsor Admin Suite", page_icon="🏟️", layout="wide")
    if "auth" not in st.session_state:
        login_screen()
        return

    choice = sidebar_nav()
    if choice == "Contract Generator":
        contract_generator_run()
    elif choice == "Renewal Alerts (coming soon)":
        st.title("📬 Renewal Alerts")
        st.info("This tab will visualize and email upcoming renewals from the generated renewal JSON files.")
    else:
        st.title("📊 Inventory & Pricing")
        st.info("This tab will connect to your live sponsorship inventory and pricing trends.")

if __name__ == "__main__":
    main()
