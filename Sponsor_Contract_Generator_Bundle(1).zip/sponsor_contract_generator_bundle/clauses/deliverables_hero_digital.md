## Deliverables — Hero Digital
- Center-hung LED or equivalent premium digital board, {{qty}} unit(s)
- Inclusion in livestream lower-third rotation where applicable
- Standard flighting across marquee events within the facility main bowl