## Deliverables — Court Static
- Court-side stanchion wraps on Court A, {{qty}} unit(s)
- Printed to spec, installed by Facility-approved vendor
- Reasonable wear-and-tear replacement policy included