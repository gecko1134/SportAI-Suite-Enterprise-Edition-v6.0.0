## Measurement & Reporting
- QR/UTM convention: `{{qr_scheme}}`
- Reporting cadence: {{report_cadence}}
- Access to Facility’s dashboard for impression logs on digital assets