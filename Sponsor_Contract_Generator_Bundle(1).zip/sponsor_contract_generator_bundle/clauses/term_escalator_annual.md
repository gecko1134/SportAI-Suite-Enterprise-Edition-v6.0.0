## Escalator
For multi-year terms, a {{escalator_pct}} annual escalator applies to fees beginning in year two.