import argparse
import os
from pathlib import Path
from datetime import datetime, timedelta
import yaml
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

# Optional PDF via reportlab (fallback to text-only if not available)
try:
    from reportlab.lib.pagesizes import LETTER
    from reportlab.pdfgen import canvas
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

BASE = Path(__file__).resolve().parents[1]
CLAUSES = BASE / "clauses"
RULES = BASE / "rules.yaml"

def load_rules():
    with open(RULES, "r") as f:
        return yaml.safe_load(f)

def money(x):
    return "${:,.0f}".format(round(float(x)))

def calc_price(inv_items, tier, term_months, rules):
    tier_info = rules["tiers"][tier]
    term_years = term_months / 12.0
    base_total = 0.0
    detail = []
    for item in inv_items:
        loc = rules["locations"][item["type"]]
        base = loc["base_rate"]
        weight = loc.get("visibility_weight", 1.0)
        qty = item.get("qty", 1)
        annual = base * weight * qty
        base_total += annual * term_years
        detail.append({
            "code": item.get("code", item["type"]),
            "annual": annual,
            "qty": qty
        })

    # Tier multiplier
    base_total *= tier_info["tier_multiplier"]

    # Multi-year discount
    discount = 0.0
    for k, v in rules["terms"]["multi_year_discount_pct"].items():
        if term_months >= int(k):
            discount = max(discount, float(v))
    base_total *= (1 - discount)

    # Short run surcharge
    if term_months <= rules["terms"]["short_run_months_threshold"]:
        base_total *= (1 + rules["terms"]["short_run_surcharge_pct"])

    return max(base_total, 0.0), detail, discount, tier_info.get("escalator_pct", 0.0)

def render_text(spec, rules, price_info):
    price, line_items, discount, escalator = price_info
    tier_info = rules["tiers"][spec["sponsor_profile"]["tier"]]

    # Build a simple markdown-ish text
    lines = []
    lines.append(f"# Sponsorship Agreement")
    lines.append("")
    sp = spec["sponsor_profile"]
    lines.append(f"**Sponsor:** {sp['name']}  |  **Category:** {sp['category']}  |  **Tier:** {sp['tier']}")
    lines.append(f"**Term:** {spec['sponsor_profile']['term_months']} months")
    lines.append(f"**Dates:** {spec['sponsor_profile']['start_date']} to {spec['sponsor_profile'].get('end_date', 'TBD')}")
    lines.append("")
    lines.append("## Pricing Summary")
    lines.append(f"- Gross Contract Value: {money(price)}")
    lines.append(f"- Multi-year Discount: {int(discount*100)}%")
    lines.append(f"- Annual Escalator (if multi-year): {int(escalator*100)}%")
    lines.append("")
    lines.append("### Line Items")
    for li in line_items:
        lines.append(f"- {li['code']}: {money(li['annual'])} per year x {spec['sponsor_profile']['term_months']/12:.1f} years")

    # Clause selection
    selected_clauses = []
    selected_clauses += rules["general_clauses"]
    if tier_info.get("category_exclusivity"):
        selected_clauses.append("exclusivity_category.md")
    if tier_info.get("zone_exclusivity"):
        selected_clauses.append("exclusivity_zone.md")

    # Inventory-specific clauses
    for item in spec["inventory"]:
        loc = rules["locations"][item["type"]]
        for c in loc.get("clauses", []):
            if c not in selected_clauses:
                selected_clauses.append(c)

    # Merge clauses
    from jinja2 import Template  # jinja2 is lightweight; streamlit often ships with it
    vars = {
        "start_date": spec["sponsor_profile"]["start_date"],
        "end_date": spec["sponsor_profile"].get("end_date",""),
        "term_months": spec["sponsor_profile"]["term_months"],
        "escalator_pct": f"{int(escalator*100)}%",
        "qr_scheme": spec["measurement"]["qr_scheme"],
        "report_cadence": spec["measurement"]["report_cadence"],
        "creative_due_days_before_launch": spec["sla"]["creative_due_days_before_launch"],
        "revision_rounds_included": spec["sla"]["revision_rounds_included"],
        "qty": sum([i.get("qty",1) for i in spec["inventory"]])
    }

    clause_texts = []
    for cf in selected_clauses:
        p = CLAUSES / cf
        if p.exists():
            raw = p.read_text()
            clause_texts.append(Template(raw).render(**vars))

    lines.append("")
    lines += clause_texts

    return "\n".join(lines)

def write_docx(text, outpath):
    doc = Document()
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(11)

    for block in text.split("\n\n"):
        p = doc.add_paragraph()
        for line in block.split("\n"):
            if line.startswith("# "):
                run = p.add_run(line.replace("# ", "").strip())
                run.bold = True
                run.font.size = Pt(16)
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            elif line.startswith("## "):
                run = p.add_run(line.replace("## ", "").strip())
                run.bold = True
                run.font.size = Pt(14)
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            elif line.startswith("### "):
                run = p.add_run(line.replace("### ", "").strip())
                run.bold = True
                run.font.size = Pt(12)
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            else:
                p = doc.add_paragraph(line)

    doc.save(outpath)

def write_pdf(text, outpath):
    if not REPORTLAB_AVAILABLE:
        # Fallback to a .txt if reportlab is missing
        with open(outpath.with_suffix(".txt"), "w") as f:
            f.write(text)
        return False
    c = canvas.Canvas(str(outpath), pagesize=LETTER)
    width, height = LETTER
    x = 72
    y = height - 72
    for line in text.split("\n"):
        if y < 72:
            c.showPage()
            y = height - 72
        c.drawString(x, y, line[:110])
        y -= 14
    c.save()
    return True

def build(spec_path, outdir):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    with open(spec_path, "r") as f:
        spec = yaml.safe_load(f)

    # compute end_date if not provided
    if not spec["sponsor_profile"].get("end_date"):
        sd = datetime.fromisoformat(spec["sponsor_profile"]["start_date"])
        months = spec["sponsor_profile"]["term_months"]
        ed = sd + timedelta(days=int(months*30.4167))
        spec["sponsor_profile"]["end_date"] = ed.date().isoformat()

    rules = load_rules()
    price_info = calc_price(spec["inventory"], spec["sponsor_profile"]["tier"], spec["sponsor_profile"]["term_months"], rules)
    text = render_text(spec, rules, price_info)

    # filenames
    base_name = f"{spec['sponsor_profile']['name'].replace(' ','_')}_{spec['sponsor_profile']['tier']}_{spec['sponsor_profile']['term_months']}m"
    md_path = outdir / f"{base_name}.md"
    docx_path = outdir / f"{base_name}.docx"
    pdf_path = outdir / f"{base_name}.pdf"

    # Write outputs
    md_path.write_text(text)
    write_docx(text, docx_path)
    wrote_pdf = write_pdf(text, pdf_path)

    # write a simple renewal alert ticket (JSON) for ops systems
    renewal = {
        "sponsor": spec["sponsor_profile"]["name"],
        "tier": spec["sponsor_profile"]["tier"],
        "start_date": spec["sponsor_profile"]["start_date"],
        "end_date": spec["sponsor_profile"]["end_date"],
        "notice_window_days": spec["renewal"]["notice_window_days"],
        "auto_renew": spec["renewal"]["auto_renew"],
        "alert_emails": spec["renewal"]["alert_emails"],
    }
    (outdir / f"{base_name}_renewal.json").write_text(yaml.safe_dump(renewal))

    return {
        "markdown": str(md_path),
        "docx": str(docx_path),
        "pdf": str(pdf_path) if wrote_pdf else None,
        "renewal_json": str(outdir / f"{base_name}_renewal.json")
    }

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()
    res = build(args.input, args.outdir)
    print(res)
