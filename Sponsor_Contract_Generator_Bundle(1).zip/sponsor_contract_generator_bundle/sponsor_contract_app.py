import streamlit as st
import yaml
from pathlib import Path
from generator.contract_builder import build, load_rules

def run():
    st.set_page_config(page_title="Sponsor Contract Generator", page_icon="📄", layout="centered")
    st.title("📄 Sponsor Contract Generator")

    rules = load_rules()
    tiers = list(rules["tiers"].keys())
    locations = list(rules["locations"].keys())

    st.subheader("Sponsor Profile")
    sponsor_name = st.text_input("Sponsor Name", "Acme Health")
    category = st.text_input("Sponsor Category", "Healthcare")
    tier = st.selectbox("Tier", tiers, index=tiers.index("Gold") if "Gold" in tiers else 0)
    term_months = st.number_input("Term (months)", min_value=3, max_value=120, value=24, step=3)
    start_date = st.date_input("Start Date")
    vip_passes = st.number_input("VIP Passes", min_value=0, value=12, step=1)
    community_days = st.number_input("Community Days", min_value=0, value=1, step=1)
    livestream_logo = st.checkbox("Livestream Logo Lockup", value=True)

    st.subheader("Inventory")
    inv = []
    with st.expander("Add Inventory Items"):
        for i in range(1,4):
            st.markdown(f"**Item {i}**")
            loc = st.selectbox(f"Location Type {i}", locations, key=f"loc{i}")
            code = st.text_input(f"Code {i}", f"ITEM_{i}")
            qty = st.number_input(f"Qty {i}", min_value=0, value=1, step=1, key=f"qty{i}")
            if qty > 0:
                inv.append({"code": code, "type": loc, "qty": qty})

    st.subheader("Rights & SLAs")
    creative_due = st.number_input("Creative due (days before launch)", 0, 60, 21)
    revisions = st.number_input("Revision rounds included", 0, 10, 2)

    st.subheader("Exclusivity & Renewal")
    auto_renew = st.checkbox("Auto-renew", value=True)
    notice_days = st.number_input("Renewal notice window (days)", 0, 365, 90)
    alert_emails = st.text_input("Alert emails (comma-separated)", "sponsorship@nxscomplex.org,gm@nxscomplex.org")

    st.subheader("Measurement")
    qr_scheme = st.text_input("QR/UTM scheme", "nxs{yyyy}{tier}{loc}{seq}")
    cadence = st.selectbox("Report cadence", ["monthly","quarterly","seasonal"], index=1)

    generate = st.button("Generate Agreement")

    if generate:
        # assemble spec
        spec = {
            "sponsor_profile": {
                "name": sponsor_name,
                "category": category,
                "tier": tier,
                "term_months": int(term_months),
                "start_date": start_date.isoformat()
            },
            "inventory": inv if inv else [{"code":"DOME_CENTER_HUNG","type":"hero_digital","qty":1}],
            "rights": {
                "vip_passes": int(vip_passes),
                "community_days": int(community_days),
                "livestream_logo": bool(livestream_logo)
            },
            "pricing": {},
            "sla": {
                "creative_due_days_before_launch": int(creative_due),
                "revision_rounds_included": int(revisions)
            },
            "exclusivity": {},
            "renewal": {
                "auto_renew": bool(auto_renew),
                "notice_window_days": int(notice_days),
                "alert_emails": [x.strip() for x in alert_emails.split(",") if x.strip()]
            },
            "measurement": {
                "qr_scheme": qr_scheme,
                "report_cadence": cadence
            }
        }

        # write temp spec and build
        outdir = Path("samples/output")
        outdir.mkdir(parents=True, exist_ok=True)
        tmp_spec = outdir / "tmp_spec.yaml"
        with open(tmp_spec, "w") as f:
            yaml.safe_dump(spec, f)

        res = build(tmp_spec, outdir)
        st.success("Agreement generated.")
        st.write("Outputs:")
        if res.get("docx"):
            st.download_button("Download DOCX", data=open(res["docx"], "rb").read(), file_name=Path(res["docx"]).name)
        if res.get("pdf"):
            st.download_button("Download PDF", data=open(res["pdf"], "rb").read(), file_name=Path(res["pdf"]).name)
        else:
            # Offer markdown as fallback
            st.download_button("Download Markdown", data=open(res["markdown"], "rb").read(), file_name=Path(res["markdown"]).name)

        # Show renewal ticket
        st.download_button("Download Renewal JSON", data=open(res["renewal_json"], "rb").read(), file_name=Path(res["renewal_json"]).name)

if __name__ == "__main__":
    run()
