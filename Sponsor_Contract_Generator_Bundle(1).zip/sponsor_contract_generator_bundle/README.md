# Sponsor Contract Generator (Streamlit + Rules Engine)

This bundle includes:
- **sponsor_contract_app.py** — Streamlit app with a `.run()` function. Generates DOCX + (attempts) PDF and schedules renewal logic.
- **generator/contract_builder.py** — Core logic: rules, clause loading, pricing, and document assembly.
- **clauses/** — Modular clause library (Markdown) selected by tier, signage type, and term.
- **rules.yaml** — Tier/location/term rules, pricing multipliers, and defaults.
- **samples/** — `sample_deal.yaml` input and one pre-generated contract output for reference.
- **README.md** — You’re reading it.

## Quick start
1. Install:
   ```bash
   pip install streamlit pyyaml python-docx reportlab
   ```
2. Run locally:
   ```bash
   streamlit run sponsor_contract_app.py
   ```
3. Generate without UI (CLI example):
   ```bash
   python -m generator.contract_builder --input samples/sample_deal.yaml --outdir samples/output
   ```

## Notes
- PDF: We generate DOCX via `python-docx` and attempt a simple PDF via `reportlab`. If `reportlab` is not installed, the app will still produce a DOCX and a Markdown text fallback.
- Clause library: Add or edit files in `clauses/` to change legal language. The engine automatically picks the right clauses by rules.yaml and inventory types.
- Renewal alerts: The Streamlit app writes a renewal.json "alert ticket" that your ops/CRM can ingest to send emails (or wire to SendGrid in your environment).

## Structure
```
sponsor_contract_generator_bundle/
├─ sponsor_contract_app.py
├─ rules.yaml
├─ generator/
│  └─ contract_builder.py
├─ clauses/
│  ├─ grant_of_rights_base.md
│  ├─ exclusivity_category.md
│  ├─ exclusivity_zone.md
│  ├─ term_standard.md
│  ├─ term_escalator_annual.md
│  ├─ deliverables_hero_digital.md
│  ├─ deliverables_court_static.md
│  ├─ make_good_min_impressions.md
│  ├─ insurance_standard_indoor.md
│  ├─ measurement_qr_utms.md
│  ├─ termination_morals.md
│  └─ branding_creative_sla.md
├─ samples/
│  ├─ sample_deal.yaml
│  └─ output/ (created after first run)
└─ README.md
```


## Admin launcher
You can run the full admin launcher (with a simple login) instead of the single-page generator:
```bash
streamlit run app.py
```
Default demo login:
- Email: `admin@nxscomplex.org`
- Password: `admin123`
