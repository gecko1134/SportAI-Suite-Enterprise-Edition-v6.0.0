import streamlit as st
import pandas as pd
import json
import matplotlib.pyplot as plt
from shared.ui.traffic_lights import render_cards

TOOL_NAME = "Lead-Time Watch"
TOOL_CATEGORY = "Pricing Tools"
REQUIRED_ROLES = ["Admin","Board"]

def get_tool_metadata():
    return {"name":TOOL_NAME,"category":TOOL_CATEGORY,"roles":REQUIRED_ROLES,"description":"Lead-time + utilization signals with weekly price move suggestions","slug":"lead_time_watch"}

def _band_label(row, bands):
    dow = row['slot_start'].isoweekday(); hr = row['slot_start'].hour
    for b in bands:
        if b['resource_type'] in (row['resource_type'], 'turf_or_court'):
            if dow in b['days_of_week'] and b['start_hour'] <= hr < b['end_hour']:
                return b['name']
    return 'Off_Peak'

@st.cache_data
def _compute_metrics(df, cfg):
    df = df.copy()
    for col in ['slot_start','slot_end','booking_created_at']:
        df[col] = pd.to_datetime(df[col])
    df = df[df['status'].str.lower().eq('confirmed')]
    df['lead_days'] = (df['slot_start'].dt.normalize() - df['booking_created_at'].dt.normalize()).dt.days
    df['week'] = df['slot_start'].dt.to_period('W-MON').apply(lambda r: r.start_time)
    df['band'] = df.apply(lambda r: _band_label(r, cfg['bands']), axis=1)
    slots_per_week = (df.groupby(['band','week','resource_id','slot_start']).size().reset_index(name='bookings'))
    total_slots = (slots_per_week.groupby(['band','week'])['slot_start'].nunique().reset_index(name='unique_slots'))
    booked_slots = (df.groupby(['band','week'])['slot_start'].nunique().reset_index(name='booked_slots'))
    metrics = total_slots.merge(booked_slots, on=['band','week'], how='outer').fillna(0)
    metrics['utilization'] = metrics.apply(lambda r: (r['booked_slots']/r['unique_slots']) if r['unique_slots'] else None, axis=1)
    lead = (df.groupby(['band','week'])['lead_days'].median().reset_index().rename(columns={'lead_days':'median_lead_days'}))
    price = (df.groupby(['band','week'])[['price_list_rate','price_paid']].median().reset_index().rename(columns={'price_list_rate':'median_list','price_paid':'median_paid'}))
    out = metrics.merge(lead, on=['band','week'], how='left').merge(price, on=['band','week'], how='left')
    out = out.sort_values(['band','week'])
    out['prev_median_lead'] = out.groupby('band')['median_lead_days'].shift(1)
    out['leadtime_change_pct'] = (out['median_lead_days'] - out['prev_median_lead'])/out['prev_median_lead']
    return out

def _decide_moves(metrics, cfg):
    recs = []
    for band, g in metrics.groupby('band'):
        last = g.dropna(subset=['median_lead_days']).tail(1)
        prev = g.dropna(subset=['median_lead_days']).tail(2).head(1)
        if last.empty or prev.empty: continue
        m = last.iloc[0]; p = prev.iloc[0]
        lt_drop = -((m['median_lead_days'] - p['median_lead_days'])/p['median_lead_days']) if p['median_lead_days'] and p['median_lead_days']>0 else 0
        util = m['utilization']
        rec = {"band": band, "median_lead_days": m['median_lead_days'], "utilization": util, "leadtime_drop_pct": lt_drop, "rec":"HOLD","delta_pct":0.0,"reason":""}
        if pd.notna(util) and util >= cfg['utilization_thresholds']['aggressive_sellout'] and m['median_lead_days'] <= 7:
            rec.update({"rec":"RAISE","delta_pct": min(0.12, cfg['max_single_move_pct']), "reason":"Sellout + short lead-time"})
        elif pd.notna(util) and util >= cfg['utilization_thresholds']['raise_high'] and lt_drop >= cfg['leadtime_drop_thresholds']['raise_high']:
            rec.update({"rec":"RAISE","delta_pct": cfg['default_raise_high_pct'], "reason":"Lead-time ↓≥30% & util high"})
        elif pd.notna(util) and util >= cfg['utilization_thresholds']['raise_low'] and lt_drop >= cfg['leadtime_drop_thresholds']['raise_low']:
            rec.update({"rec":"RAISE","delta_pct": cfg['default_raise_low_pct'], "reason":"Lead-time ↓≥20% & util strong"})
        elif pd.notna(util) and util < cfg['rollback_utilization_floor']:
            rec.update({"rec":"PROMO/REDUCE","delta_pct": -cfg['default_raise_low_pct']/2, "reason":"Under 80% util"})
        recs.append(rec)
    return pd.DataFrame(recs)

def run(role:str="Admin"):
    st.header("Lead-Time Watch")
    st.caption("Median lead-time + utilization → weekly pricing signals")
    if role not in REQUIRED_ROLES:
        st.warning("You don't have access to this tool."); return
    left, right = st.columns([2,1])
    with right:
        cfg_src = st.radio("Config source", ["Bundled default","Upload JSON"], horizontal=True)
        if cfg_src == "Bundled default":
            try:
                with open("shared/config/sportai_lead_time_config.json","r") as f:
                    cfg_obj = json.load(f)
            except FileNotFoundError:
                st.error("Bundled config missing. Upload a config instead."); cfg_obj = None
        else:
            cfg_file = st.file_uploader("Upload config JSON", type=["json"])
            cfg_obj = json.loads(cfg_file.getvalue().decode("utf-8")) if cfg_file else None
    with left:
        csv = st.file_uploader("Upload SportsKey CSV export", type=["csv"])
    if not (cfg_obj and csv):
        st.info("Upload both the config and CSV to generate signals."); return
    df = pd.read_csv(csv)
    metrics = _compute_metrics(df, cfg_obj)
    st.subheader("This Week’s Signals")
    recs = _decide_moves(metrics, cfg_obj)
    render_cards(recs)
    with st.expander("View tables"):
        st.dataframe(recs, use_container_width=True, height=250)
        st.dataframe(metrics, use_container_width=True, height=300)
    st.download_button("Download recommendations CSV", data=recs.to_csv(index=False), file_name="pricing_recommendations.csv", mime="text/csv")
    st.subheader("Trends by band")
    for band, g in metrics.groupby('band'):
        st.markdown(f"**{band}**")
        fig1, ax1 = plt.subplots(); ax1.plot(g['week'], g['median_lead_days'], marker='o'); ax1.set_xlabel("Week"); ax1.set_ylabel("Median lead days"); st.pyplot(fig1)
        fig2, ax2 = plt.subplots(); ax2.plot(g['week'], g['utilization'], marker='o'); ax2.set_xlabel("Week"); ax2.set_ylabel("Utilization"); st.pyplot(fig2)
