"""
SportAI Main App — Branded + Auto-Apply Switch + SendGrid
---------------------------------------------------------
Run:
    streamlit run sportai_main_app_branded.py

Env:
    SENDGRID_API_KEY must be set to send emails.
"""
import os, io, json, hashlib, datetime, requests
import pandas as pd
import numpy as np
import streamlit as st
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

st.set_page_config(page_title="SportAI (Branded)", layout="wide")

BRAND_PATH = "branding_config.json"
PROMOTE_PATH = "promote_flags.json"
USERS_PATH = "users.json"

def load_brand(path=BRAND_PATH):
    default = {"facility_name": "NXS National Sports Complex","primary_hex": "#0A2E5D","accent_hex": "#E6B800","logo_path": "","pdf_watermark": "NXS National Complex"}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f); default.update({k:v for k,v in data.items() if v is not None})
    except Exception:
        pass
    return default

brand = load_brand()

def brand_css(primary, accent):
    return f"""
    <style>
    :root {{ --primary: {primary}; --accent: {accent}; }}
    .stApp {{ background: linear-gradient(180deg, rgba(0,0,0,0.02), rgba(0,0,0,0)) !important; }}
    .stSidebar [data-testid="stSidebarNav"]::before {{ content: "{brand.get('facility_name','SportAI')}"; margin-left: 8px; font-weight: 700; color: {primary}; }}
    .stButton>button, .stDownloadButton>button {{ border-radius: 12px !important; border: 1px solid {primary} !important; }}
    </style>
    """

st.markdown(brand_css(brand["primary_hex"], brand["accent_hex"]), unsafe_allow_html=True)

if brand.get("logo_path") and os.path.exists(brand["logo_path"]):
    st.sidebar.image(brand["logo_path"], caption=brand.get("facility_name","SportAI"), use_column_width=True)
else:
    st.sidebar.markdown(f"### {brand.get('facility_name','SportAI')}")

# Auth
def load_users(path=USERS_PATH):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"users": []}

def verify_login(email, password, users_db):
    for u in users_db.get("users", []):
        if u.get("email","").lower() == email.lower() and u.get("password","") == password:
            return {"email": email, "role": u.get("role","member"), "name": u.get("name", email.split("@")[0])}
    return None

def require_role(allowed):
    return st.session_state.get("user", {}).get("role") in allowed

users_db = load_users(USERS_PATH)
st.sidebar.title("Login")
if "user" not in st.session_state: st.session_state.user = None
if st.session_state.user is None:
    email = st.sidebar.text_input("Email")
    pwd = st.sidebar.text_input("Password", type="password")
    if st.sidebar.button("Sign In"):
        user = verify_login(email, pwd, users_db)
        if user: st.session_state.user = user; st.sidebar.success(f"Welcome, {user['name']}")
        else: st.sidebar.error("Invalid credentials")
    st.stop()

user = st.session_state.user
st.sidebar.markdown(f"**Signed in:** {user['email']} — `{user['role']}`")
if st.sidebar.button("Sign Out"): st.session_state.user = None; st.experimental_rerun()

# Utils
SUG_FINGERPRINT_FIELDS = ["asset_id","asset_type","time_block_start","time_block_end","tier","event_type","suggested_price","suggested_layout","suggested_pod","predicted_revenue","predicted_utilization","predicted_sponsor_hits","would_do_action"]

def try_float(x, default=0.0):
    try: return float(str(x).strip())
    except Exception: return default
def try_int(x, default=0):
    try: return int(float(str(x).strip()))
    except Exception: return default
def mape(y_true, y_pred):
    y_true = np.array(y_true, dtype=float); y_pred = np.array(y_pred, dtype=float)
    mask = y_true != 0
    if mask.sum() == 0: return np.nan
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100.0
def dataset_checksum(df):
    import hashlib
    def fingerprint_row(row, fields=SUG_FINGERPRINT_FIELDS):
        buff = "|".join([str(row.get(k,"")).strip() for k in fields])
        return hashlib.sha256(buff.encode("utf-8")).hexdigest()
    df2 = df.sort_values("suggestion_id") if "suggestion_id" in df.columns else df.copy()
    concat = "\n".join([fingerprint_row(r) for _, r in df2.iterrows()])
    return hashlib.sha256(concat.encode("utf-8")).hexdigest()

# Nav
sections = ["Shadow Report", "Asset Promotion", "Board PDF & Email"]
choice = st.sidebar.radio("Navigation", sections, index=0)

st.header("Data Inputs")
logs = st.file_uploader("Upload shadow_logs.csv", type=["csv"], key="logs")
actuals = st.file_uploader("Upload actuals.csv (optional)", type=["csv"], key="acts")

def load_joined_dataframe(logs, actuals):
    if logs is None: return None
    df = pd.read_csv(logs)
    if actuals is not None:
        act = pd.read_csv(actuals)
        if "suggestion_id" in act.columns and "suggestion_id" in df.columns:
            df = df.merge(act, on="suggestion_id", how="left", suffixes=("","_actfile"))
            for tgt, src in [("actual_revenue","actual_revenue_actfile"),("actual_utilization","actual_utilization_actfile"),("actual_sponsor_hits","actual_sponsor_hits_actfile")]:
                if src in df.columns and tgt in df.columns: df[tgt] = df[tgt].fillna(df[src])
        elif set(["asset_id","time_block_start","time_block_end"]).issubset(act.columns):
            df = df.merge(act, on=["asset_id","time_block_start","time_block_end"], how="left", suffixes=("","_actfile"))
    return df

df = load_joined_dataframe(logs, actuals)

with st.sidebar.expander("Guardrail Settings", expanded=False):
    floor_price = st.number_input("Global price floor ($)", min_value=0.0, value=75.0, step=5.0)
    ceiling_price = st.number_input("Global price ceiling ($)", min_value=0.0, value=450.0, step=10.0)
    max_override_rate = st.slider("Max human override rate (%)", 0, 100, 15, step=1)
    mape_threshold = st.slider("MAPE promote threshold (%)", 1, 50, 10, step=1)
    min_lift = st.slider("Min net revenue lift to promote (%)", 0, 20, 3, step=1)

# Shadow Report
if choice == "Shadow Report":
    st.header(f"{brand.get('facility_name','SportAI')} — Shadow Mode Report")
    if df is None: st.info("Upload shadow_logs.csv to begin."); st.stop()
    st.markdown(f"<div style='height:6px;background:{brand['primary_hex']}'></div>", unsafe_allow_html=True)
    st.subheader("Data Integrity")
    try: st.code(f"Dataset SHA256: {dataset_checksum(df)}")
    except Exception as e: st.warning(f"Checksum error: {e}")
    st.subheader("Raw Suggestions"); st.dataframe(df)
    st.subheader("Key Metrics")
    col1, col2, col3, col4 = st.columns(4)
    mape_rev = mape(df["actual_revenue"].fillna(0), df["predicted_revenue"].fillna(0)) if "actual_revenue" in df.columns else np.nan
    mape_util = mape(df["actual_utilization"].fillna(0), df["predicted_utilization"].fillna(0)) if "actual_utilization" in df.columns else np.nan
    avg_lift = ((df["actual_revenue"] - df["predicted_revenue"]) / df["predicted_revenue"] * 100.0).replace([np.inf,-np.inf], np.nan).mean()
    col1.metric("Revenue MAPE", f"{mape_rev:.2f}%" if pd.notna(mape_rev) else "—")
    col2.metric("Utilization MAPE", f"{mape_util:.2f}%" if pd.notna(mape_util) else "—")
    col3.metric("Avg. Net Revenue Lift", f"{avg_lift:.2f}%" if pd.notna(avg_lift) else "—")
    col4.metric("Suggestions Logged", f"{len(df):,}")
    st.subheader("Promotion Readiness by Asset")
    rows = []
    for asset, g in df.groupby("asset_id"):
        mr = mape(g["actual_revenue"].fillna(0), g["predicted_revenue"].fillna(0)) if "actual_revenue" in g.columns else np.nan
        lift = ((g["actual_revenue"].fillna(0) - g["predicted_revenue"].fillna(0)) / g["predicted_revenue"].replace(0,np.nan) * 100.0).replace([np.inf,-np.inf], np.nan).mean()
        overrides = g["guardrail_flags"].dropna().apply(lambda x: len(x) if isinstance(x,list) else 0).sum() if "guardrail_flags" in g.columns else 0
        status = "PROMOTE → Auto-Apply" if (pd.notna(mr) and mr <= mape_threshold and (pd.notna(lift) and lift >= min_lift)) else "KEEP in Review"
        rows.append({"asset_id": asset, "MAPE_Revenue_%": mr, "Avg_Lift_%": lift, "Status": status})
    if rows: st.dataframe(pd.DataFrame(rows).sort_values(["Status","MAPE_Revenue_%"]))

# Asset Promotion
if choice == "Asset Promotion":
    st.header("Promote to Auto-Apply — Per Asset")
    if user["role"] != "admin": st.warning("Admin only."); st.stop()
    flags = {}
    try:
        with open(PROMOTE_PATH, "r", encoding="utf-8") as f: flags = json.load(f)
    except Exception: flags = {}
    if df is None or "asset_id" not in df.columns:
        st.info("Upload shadow_logs.csv to list assets.")
    else:
        assets = sorted(df["asset_id"].dropna().unique().tolist())
        st.write("Assets detected:", assets)
        for a in assets:
            current = flags.get(a, {"status":"shadow","updated_by":user["email"],"updated_at":str(datetime.date.today())})
            status = st.selectbox(f"{a} status", ["shadow","recommend","auto"], index=["shadow","recommend","auto"].index(current.get("status","shadow")))
            if st.button(f"Save {a}"):
                flags[a] = {"status": status, "updated_by": user["email"], "updated_at": str(datetime.date.today())}
                with open(PROMOTE_PATH, "w", encoding="utf-8") as f: json.dump(flags, f, indent=2)
                st.success(f"Saved: {a} → {status}")
    st.subheader("Current Promote Flags (JSON)")
    st.code(json.dumps(flags, indent=2))

# Board PDF & Email
if choice == "Board PDF & Email":
    st.header("Board PDF & SendGrid Email")
    if df is None: st.info("Upload shadow_logs.csv to generate PDF."); st.stop()
    if st.button("Generate Board PDF"):
        price_floor, price_ceiling = 75, 450
        mape_rev = mape(df["actual_revenue"].fillna(0), df["predicted_revenue"].fillna(0)) if "actual_revenue" in df.columns else np.nan
        mape_util = mape(df["actual_utilization"].fillna(0), df["predicted_utilization"].fillna(0)) if "actual_utilization" in df.columns else np.nan
        avg_lift = ((df["actual_revenue"].fillna(0) - df["predicted_revenue"].fillna(0)) / df["predicted_revenue"].replace(0,np.nan) * 100.0).replace([np.inf,-np.inf], np.nan).mean()
        promote = review = 0
        try:
            with open(PROMOTE_PATH, "r", encoding="utf-8") as f: flags = json.load(f)
            promote = sum(1 for v in flags.values() if v.get("status")=="auto")
            review = sum(1 for v in flags.values() if v.get("status")!="auto")
        except Exception: pass
        guard_viol = 0
        if "suggested_price" in df.columns:
            sp = pd.to_numeric(df["suggested_price"], errors="coerce")
            guard_viol = int(((sp < price_floor) | (sp > price_ceiling)).sum())
        buff = io.BytesIO()
        c = canvas.Canvas(buff, pagesize=LETTER)
        w, h = LETTER; y = h - 72
        def line(txt, dy=16, font="Times-Roman", size=11):
            nonlocal y; c.setFont(font, size); c.drawString(72, y, txt); y -= dy
        if brand.get("logo_path") and os.path.exists(brand["logo_path"]):
            try: c.drawImage(ImageReader(brand["logo_path"]), 72, h-100, width=120, preserveAspectRatio=True, mask='auto')
            except Exception: pass
        today = datetime.date.today().strftime("%Y-%m-%d")
        line(f"{brand.get('facility_name','SportAI')} — Board Snapshot", dy=20, font="Times-Bold", size=14)
        line(f"Date: {today}"); line(f"Shadow Suggestions Logged: {len(df):,}")
        line("Key Metrics", dy=18, font="Times-Bold", size=12)
        line(f"Revenue MAPE: {mape_rev:.2f}%  |  Utilization MAPE: {mape_util:.2f}%  |  Avg Net Lift: {avg_lift:.2f}%")
        line("Promotion Readiness", dy=18, font="Times-Bold", size=12)
        line(f"Assets set to AUTO: {promote}  |  Remaining in SHADOW/RECOMMEND: {review}")
        line("Guardrail Alerts", dy=18, font="Times-Bold", size=12)
        line(f"Price floor/ceiling violations: {guard_viol} (floor=${price_floor}, ceiling=${price_ceiling})")
        try:
            c.setFont("Times-Roman", 48); c.setFillGray(0.85, 0.5); c.saveState(); c.translate(300, 300); c.rotate(30)
            c.drawCentredString(0, 0, brand.get("pdf_watermark","SportAI")); c.restoreState()
        except Exception: pass
        c.showPage(); c.save()
        st.session_state.board_pdf_bytes = buff.getvalue()
        st.success("Board PDF generated.")
        st.download_button("Download Board Snapshot PDF", st.session_state.board_pdf_bytes, file_name="Board_Snapshot.pdf", mime="application/pdf")
    st.subheader("Email the Board PDF (SendGrid)")
    from_email = st.text_input("From email", value="no-reply@nxscomplex.org")
    to_emails = st.text_input("To emails (comma-separated)", value="board@example.com")
    subject = st.text_input("Subject", value=f"{brand.get('facility_name','SportAI')} — Board Snapshot")
    body = st.text_area("Plaintext body", value="Attached is the latest board snapshot generated by SportAI.")
    if st.button("Send via SendGrid", disabled=("board_pdf_bytes" not in st.session_state)):
        api_key = os.environ.get("SENDGRID_API_KEY","")
        if not api_key: st.error("SENDGRID_API_KEY not set in environment.")
        else:
            try:
                import base64 as _b64
                payload = {
                  "personalizations": [{"to": [{"email": e.strip()} for e in to_emails.split(",") if e.strip()]}],
                  "from": {"email": from_email},
                  "subject": subject,
                  "content": [{"type": "text/plain", "value": body}],
                  "attachments": [{
                    "content": _b64.b64encode(st.session_state.board_pdf_bytes).decode("utf-8"),
                    "type": "application/pdf",
                    "filename": "Board_Snapshot.pdf"
                  }]
                }
                headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
                resp = requests.post("https://api.sendgrid.com/v3/mail/send", headers=headers, json=payload, timeout=20)
                if resp.status_code in (200, 202): st.success("Email sent via SendGrid.")
                else: st.error(f"SendGrid error: {resp.status_code} {resp.text}")
            except Exception as e: st.error(f"Email failed: {e}")
