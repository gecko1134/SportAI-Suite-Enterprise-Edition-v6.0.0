# SportAI (Branded) — Auto-Apply + SendGrid

Run:
```bash
streamlit run sportai_main_app_branded.py
```

Branding:
- Edit `branding_config.json` to set facility name, colors, logo path, and PDF watermark.

Promote flags:
- Use the **Asset Promotion** tab to set per-asset status: `shadow` / `recommend` / `auto`.
- States are saved in `promote_flags.json`.

Email via SendGrid:
- Set env var `SENDGRID_API_KEY` (see `sendgrid_env_sample.txt`).
- Generate the Board PDF in the app, then click **Send via SendGrid**.
- From/To/Subject/Body are editable in the UI.

(Optional) Weekly email: run this app in a small CLI batch with `streamlit run` and trigger the email path using a headless test with Playwright, or wrap the PDF/send code in a cron-invoked Python script that imports the PDF builder from this file.
