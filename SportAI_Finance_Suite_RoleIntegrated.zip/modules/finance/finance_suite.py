
import os, json
from datetime import datetime
import pandas as pd
import streamlit as st

# Reuse the Payments Dashboard from pricing module
from modules.pricing.pricing_suite_billing import run_payments_dashboard_tab

AR_EXPORT_DIR = "modules/finance/exports"
os.makedirs(AR_EXPORT_DIR, exist_ok=True)

def _ar_bucketize(df: pd.DataFrame):
    if df.empty:
        return pd.DataFrame([{"bucket":"current","amount":0.0},
                             {"bucket":"1-30","amount":0.0},
                             {"bucket":"31-60","amount":0.0},
                             {"bucket":"61-90","amount":0.0},
                             {"bucket":"90+","amount":0.0}])
    # Expect a 'days' column or 'ts' epoch; compute days from 'ts' if needed
    out = df.copy()
    if "days" not in out.columns:
        out["ts"] = pd.to_datetime(out["ts"], unit="s", errors="coerce")
        out["days"] = (pd.Timestamp.utcnow() - out["ts"]).dt.days
    open_df = out[out["status"].str.lower().isin(["open","unpaid","partial"])]
    def bucket(d):
        if d <= 0: return "current"
        if d <= 30: return "1-30"
        if d <= 60: return "31-60"
        if d <= 90: return "61-90"
        return "90+"
    open_df["bucket"] = open_df["days"].apply(lambda d: bucket(int(d) if pd.notna(d) else 0))
    ar = open_df.groupby("bucket")["amount"].sum().reindex(["current","1-30","31-60","61-90","90+"], fill_value=0.0).reset_index()
    return ar

def _render_pdf(ar_df: pd.DataFrame, as_of: str, out_path: str) -> bool:
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import inch
        c = canvas.Canvas(out_path, pagesize=LETTER)
        w,h = LETTER
        y = h - 1*inch
        c.setFont("Helvetica-Bold", 16); c.drawString(1*inch, y, f"A/R Aging Report (as of {as_of})"); y -= 0.4*inch
        c.setFont("Helvetica", 10)
        total = float(ar_df["amount"].sum())
        c.drawString(1*inch, y, f"Total Open: ${total:,.2f}"); y -= 0.3*inch
        c.setFont("Helvetica-Bold", 12); c.drawString(1*inch, y, "Bucket"); c.drawString(3*inch, y, "Amount"); y -= 0.25*inch
        c.setFont("Helvetica", 10)
        for _, r in ar_df.iterrows():
            c.drawString(1*inch, y, str(r["bucket"])); c.drawString(3*inch, y, f"${float(r['amount']):,.2f}"); y -= 0.22*inch
            if y < 1*inch: c.showPage(); y = h - 1*inch
        c.showPage(); c.save()
        return True
    except Exception:
        return False

def _render_html(ar_df: pd.DataFrame, as_of: str, out_path: str) -> None:
    total = float(ar_df["amount"].sum())
    rows = "".join([f"<tr><td>{r['bucket']}</td><td style='text-align:right'>${float(r['amount']):,.2f}</td></tr>" for _, r in ar_df.iterrows()])
    html = f"""<!DOCTYPE html><html><head><meta charset='utf-8'><title>A/R Aging Report</title>
    <style>body{{font-family:Arial; max-width:800px; margin:auto}} table{{width:100%; border-collapse:collapse}} td,th{{border-bottom:1px solid #ddd; padding:8px}}</style>
    </head><body><h2>A/R Aging Report</h2><p>As of {as_of}</p>
    <table><thead><tr><th>Bucket</th><th>Amount</th></tr></thead><tbody>{rows}</tbody></table>
    <p><strong>Total Open: ${total:,.2f}</strong></p></body></html>"""
    with open(out_path, "w") as f:
        f.write(html)

def run_finance_overview_tab():
    st.header("Finance Overview")
    st.caption("View and manage payments activity (webhook-fed) — includes paid/open KPIs, A/R aging, status updates, import/export.")
    run_payments_dashboard_tab()

def run_ar_aging_report_tab():
    st.header("A/R Aging Report (PDF/HTML)")
    st.caption("Build an A/R aging summary from the payments ledger and export as a board-ready PDF or HTML.")
    # Load ledger if available from pricing ledger
    ledger_path = "modules/pricing/payments_ledger.csv"
    if not os.path.exists(ledger_path):
        st.warning("No payments ledger found yet. Use the Payments Dashboard tab to import or seed data.")
        return
    df = pd.read_csv(ledger_path)
    st.dataframe(df.head(20), use_container_width=True)

    as_of = st.text_input("As of (YYYY-mm-dd)", datetime.utcnow().strftime("%Y-%m-%d"))
    # Optional filters
    srcs = st.multiselect("Sources", sorted(df["event_source"].dropna().unique()), default=None)
    if srcs: df = df[df["event_source"].isin(srcs)]
    ar_df = _ar_bucketize(df)

    st.subheader("Aging Buckets")
    st.dataframe(ar_df, use_container_width=True)

    # Export
    if st.button("Export PDF/HTML"):
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        pdf_path = os.path.join(AR_EXPORT_DIR, f"ar_report_{ts}.pdf")
        html_path = os.path.join(AR_EXPORT_DIR, f"ar_report_{ts}.html")
        made_pdf = _render_pdf(ar_df, as_of, pdf_path)
        _render_html(ar_df, as_of, html_path)
        if made_pdf and os.path.exists(pdf_path):
            with open(pdf_path, "rb") as f:
                st.download_button("Download A/R Aging PDF", data=f.read(), file_name=os.path.basename(pdf_path), mime="application/pdf")
        with open(html_path, "rb") as f:
            st.download_button("Download A/R Aging HTML", data=f.read(), file_name=os.path.basename(html_path), mime="text/html")
