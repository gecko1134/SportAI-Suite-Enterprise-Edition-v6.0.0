
# SportAI Finance Suite — Role Integrated

## What's included
- Updated `shared/roles.py` with **Finance** role and category permissions
- `modules/finance/finance_suite.py` with:
  - `run_finance_overview_tab()` — embeds the Payments Dashboard
  - `run_ar_aging_report_tab()` — generates **PDF/HTML** A/R aging reports from the ledger
- `templates/report/ar_report_template.html` (placeholder)
- `main_app_finance_stub.py` — demo with role gate

## Quick start (demo)
```bash
pip install streamlit pandas reportlab matplotlib
streamlit run main_app_finance_stub.py
```

## Integration in your real `main_app.py`
```python
from shared.roles import ROLE_PERMISSIONS
from modules.finance.finance_suite import run_finance_overview_tab, run_ar_aging_report_tab

role = st.session_state.get("role","Member")
if "Finance Tools" in ROLE_PERMISSIONS.get(role, {}).get("categories", []):
    st.sidebar.header("Finance Tools")
    tool = st.sidebar.radio("Finance Tools", ROLE_PERMISSIONS[role]["finance_tools"])
    if tool == "Finance Overview":
        run_finance_overview_tab()
    elif tool == "A/R Aging Report":
        run_ar_aging_report_tab()
```
