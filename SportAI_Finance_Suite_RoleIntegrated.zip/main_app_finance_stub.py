
import streamlit as st
from shared.roles import ROLE_PERMISSIONS
from modules.finance.finance_suite import run_finance_overview_tab, run_ar_aging_report_tab

st.set_page_config(page_title="SportAI — Finance Suite Demo", layout="wide")

st.sidebar.title("Role Login (Demo)")
role = st.sidebar.selectbox("Role", ["Admin","Finance","Board","Analyst","Sponsor","Member"], index=0)
st.session_state["role"] = role
st.sidebar.success(f"Role: {role}")

allowed = ROLE_PERMISSIONS.get(role, {}).get("categories", [])
if "Finance Tools" not in allowed:
    st.warning("You don't have access to Finance Tools.")
    st.stop()

st.sidebar.header("Finance Tools")
tools = ROLE_PERMISSIONS.get(role, {}).get("finance_tools", [])
choice = st.sidebar.radio("Select tool", tools or ["(No tools permitted)"])

if choice == "Finance Overview":
    run_finance_overview_tab()
elif choice == "A/R Aging Report":
    run_ar_aging_report_tab()
else:
    st.info("No tool permitted.")
