
ROLE_PERMISSIONS = {
    "Admin": {
        "categories": ["Pricing Tools", "Finance Tools", "Sponsorship Tools", "Ops Tools", "Membership Tools"],
        "pricing_tools": ["Dynamic Pricing", "Guardrails Editor", "SportsKey Mapper", "Quote Emailer", "Deal Summary", "Live Requests", "Invoice Generator", "Auto-Renewal Alerts", "Payments Dashboard"],
        "finance_tools": ["Finance Overview", "A/R Aging Report"]
    },
    "Finance": {
        "categories": ["Finance Tools"],
        "finance_tools": ["Finance Overview", "A/R Aging Report"]
    },
    "Board": {
        "categories": ["Finance Tools"],
        "finance_tools": ["A/R Aging Report"]
    },
    "Analyst": {
        "categories": ["Pricing Tools", "Finance Tools"],
        "pricing_tools": ["Dynamic Pricing", "Guardrails Editor", "SportsKey Mapper", "Invoice Generator", "Auto-Renewal Alerts"],
        "finance_tools": ["A/R Aging Report"]
    },
    "Sponsor": {"categories": [], "pricing_tools": [], "finance_tools": []},
    "Member":  {"categories": [], "pricing_tools": [], "finance_tools": []}
}
