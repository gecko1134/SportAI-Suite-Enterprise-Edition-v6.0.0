
import os, json, pandas as pd
import streamlit as st
from shared.ui import page_header
from shared.storage import load_json

def run(user):
    page_header("Sales Pipeline Dashboard", "Sent → Viewed → Interested → Won")

    latest = load_json("data/proposals/latest_proposal.json", {})
    events = load_json("data/proposals/events.json", {"events":[]})
    interests = load_json("data/proposals/interests.json", {"submissions":[]})
    ev = events.get("events", [])
    subs = interests.get("submissions", [])

    # Aggregate status for latest proposal_id
    pid = latest.get("proposal_id")
    sent = sum(1 for e in ev if e.get("proposal_id")==pid and e.get("event")=="sent")
    viewed = sum(1 for e in ev if e.get("proposal_id")==pid and e.get("event")=="viewed")
    interested = sum(1 for s in subs if s.get("proposal_id")==pid)

    st.subheader("Funnel (current proposal)")
    stages = pd.DataFrame({
        "stage":["Sent","Viewed","Interested"],
        "count":[sent, viewed, interested]
    })
    st.bar_chart(stages.set_index("stage"))

    st.subheader("Events Log")
    if ev:
        st.dataframe(pd.DataFrame(ev))
    else:
        st.caption("No events yet. Run the webhook service and email proposals with the tracking pixel.")

    st.subheader("Interest Submissions")
    if subs:
        st.dataframe(pd.DataFrame(subs))
    else:
        st.caption("No interest submissions yet. Landing page form submissions will appear here.")

    st.subheader("Mark Won")
    won = st.checkbox("Mark latest proposal as WON", value=False)
    if won:
        latest["status"] = "Won"
        os.makedirs("data/proposals", exist_ok=True)
        json.dump(latest, open("data/proposals/latest_proposal.json","w"), indent=2)
        st.success("Marked as WON.")
