
import json
from pathlib import Path
from sportai.fincast.validator import validate_config, load_json
from sportai.pricing.guardrails import clamp, apply_fairness

BASE = Path(__file__).resolve().parents[1]

def test_schema_accepts_sample():
    schema = load_json(BASE / 'fincast_config.schema.json')
    cfg = load_json(BASE / 'sample_fincast_config.json')
    errors = validate_config(cfg, schema)
    assert errors == [], f'Config should be valid, but got: {errors}'

def test_schema_rejects_missing_required():
    schema = load_json(BASE / 'fincast_config.schema.json')
    bad = {"version": "1.0.0"}  # missing blocks
    errors = validate_config(bad, schema)
    assert errors and any('assets' in e for e in errors)

def test_price_clamp_absolute_and_percent():
    base = 100.0
    # floor at $80 absolute, ceiling at 150% of base -> $150
    val = 200.0
    clamped = clamp(val, base, {"type":"absolute","value":80}, {"type":"percent_of_base","value":1.5})
    assert clamped == 150.0
    clamped2 = clamp(50.0, base, {"type":"absolute","value":80}, {"type":"percent_of_base","value":1.5})
    assert clamped2 == 80.0

def test_fairness_youth_nonprime_cap():
    base = 100.0
    rate = 140.0
    hour = 9  # non-prime in sample
    booking_ctx = {"groups":["youth"]}
    fairness = load_json(BASE / 'sample_fincast_config.json')["controls"]["fairness_rules"]
    adjusted = apply_fairness(rate, base, hour, booking_ctx, fairness)
    assert adjusted <= base * 0.9 + 1e-9  # capped at 90% of base

def test_fairness_community_discount_window():
    base = 100.0
    rate = 100.0
    hour = 10
    booking_ctx = {"groups":["nonprofit_501c3"]}
    fairness = load_json(BASE / 'sample_fincast_config.json')["controls"]["fairness_rules"]
    adjusted = apply_fairness(rate, base, hour, booking_ctx, fairness)
    # percent_of_base 20% off => 80
    assert abs(adjusted - 80.0) < 1e-9

def test_fairness_ada_never_above_base():
    base = 100.0
    rate = 140.0
    hour = 18
    booking_ctx = {"groups":["disabled_athletes"]}
    fairness = load_json(BASE / 'sample_fincast_config.json')["controls"]["fairness_rules"]
    adjusted = apply_fairness(rate, base, hour, booking_ctx, fairness)
    assert adjusted <= base

