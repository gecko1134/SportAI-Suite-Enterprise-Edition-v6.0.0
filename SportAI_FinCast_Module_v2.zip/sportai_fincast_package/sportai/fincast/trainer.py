
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional
import pandas as pd
import numpy as np
from pathlib import Path

@dataclass
class FinCastResult:
    forecasts: pd.DataFrame  # columns: date, asset_id, occupancy_pct, expected_rate, expected_revenue, yield_per_sqft

class FinCastTrainer:
    """
    Lightweight trainer that uses seasonal-naive + moving average baselines.
    - Groups by asset_id and day
    - Seasonal features: day-of-week mean, 7/14/28-day moving averages
    - Signal multipliers: waitlist (+), inquiries (+), lead_time (inverse)
    This is a production-safe stub (no heavy deps). Replace with Prophet/ARIMA/XGB behind same interface.
    """
    def __init__(self, config: Dict):
        self.config = config

    def _daily_agg(self, df: pd.DataFrame) -> pd.DataFrame:
        # Expect cols: date, asset_id, booked_minutes, revenue, sq_ft (merge), searches,inquiries,waitlist,lead_time_days
        if 'sq_ft' not in df.columns:
            df = df.copy()
            df['sq_ft'] = np.nan
        day = df.copy()
        day['date'] = pd.to_datetime(day['date']).dt.date
        agg_dict = {
            'booked_minutes': ('booked_minutes','sum'),
            'revenue': ('revenue','sum'),
            'searches': ('searches','sum'),
            'inquiries': ('inquiries','sum'),
            'waitlist': ('waitlist','sum'),
            'lead_time_days': ('lead_time_days','mean')
        }
        if 'sq_ft' in day.columns:
            agg_dict['sq_ft'] = ('sq_ft','max')
        g = day.groupby(['asset_id','date'], as_index=False).agg(**agg_dict)
        if 'sq_ft' not in g.columns:
            g['sq_ft'] = np.nan
        g['occupancy_pct'] = np.clip(g['booked_minutes'] / (60*16), 0, 1.0)  # assume 16h ops/day
        g['avg_rate'] = g.apply(lambda r: (r['revenue']/r['booked_minutes'])*60 if r['booked_minutes']>0 else np.nan, axis=1)
        if 'sq_ft' not in g.columns:
            g['sq_ft'] = np.nan
        return g

    def _seasonal_baseline(self, df: pd.DataFrame) -> pd.DataFrame:
        d = df.copy()
        d['date'] = pd.to_datetime(d['date'])
        d['dow'] = d['date'].dt.dayofweek
        out = []
        for aid, sub in d.groupby('asset_id'):
            sub = sub.sort_values('date').copy()
            # DOW means
            dow_means_occ = sub.groupby('dow')['occupancy_pct'].mean().to_dict()
            dow_means_rate = sub.groupby('dow')['avg_rate'].mean().to_dict()
            # Moving averages
            sub['occ_ma7'] = sub['occupancy_pct'].rolling(7, min_periods=1).mean()
            sub['rate_ma7'] = sub['avg_rate'].rolling(7, min_periods=1).mean()
            sub['occ_ma28'] = sub['occupancy_pct'].rolling(28, min_periods=1).mean()
            sub['rate_ma28'] = sub['avg_rate'].rolling(28, min_periods=1).mean()
            sub['dow_mean_occ'] = sub['dow'].map(dow_means_occ)
            sub['dow_mean_rate'] = sub['dow'].map(dow_means_rate)
            sub['occ_baseline'] = sub[['occ_ma7','occ_ma28','dow_mean_occ']].mean(axis=1)
            sub['rate_baseline'] = sub[['rate_ma7','rate_ma28','dow_mean_rate']].mean(axis=1)
            out.append(sub)
        d2 = pd.concat(out, ignore_index=True)
        return d2

    def _apply_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        d = df.copy()
        # Simple elasticities (tunable)
        a_wait = 0.02   # +2% occupancy per waitlist unit
        a_inq  = 0.005  # +0.5% per inquiry
        a_lead = -0.01  # -1% occupancy per extra day of lead_time
        d['occ_adj'] = d['occ_baseline'] * (1 + a_wait*d['waitlist'] + a_inq*d['inquiries'] + a_lead*np.nan_to_num(d['lead_time_days']))
        d['rate_adj'] = d['rate_baseline'] * (1 + 0.4*(d['occ_adj']-d['occ_baseline']))
        d['occ_adj'] = np.clip(d['occ_adj'], 0, 1.0)
        return d

    def forecast(self, history: pd.DataFrame, horizon_days: int = 14, assets: Optional[pd.DataFrame] = None) -> FinCastResult:
        hist = self._daily_agg(history)
        if 'sq_ft' not in hist.columns:
            hist['sq_ft'] = 1000
        hist['sq_ft'] = hist['sq_ft'].fillna(1000)
        base = self._seasonal_baseline(hist)
        base = self._apply_signals(base)

        # Use last known baselines/signals as seed; project flat with dow means
        last_date = pd.to_datetime(base['date']).max().date()
        future_dates = [last_date + pd.Timedelta(days=i) for i in range(1, horizon_days+1)]
        rows = []
        for aid, sub in base.groupby('asset_id'):
            sub = sub.sort_values('date')
            sq_ft = sub['sq_ft'].dropna().iloc[-1] if 'sq_ft' in sub else 1000
            dow_occ = sub.groupby(sub['date'].dt.dayofweek)['occ_baseline'].mean().to_dict()
            dow_rate = sub.groupby(sub['date'].dt.dayofweek)['rate_baseline'].mean().to_dict()
            last_signals = sub[['waitlist','inquiries','lead_time_days']].tail(7).mean(numeric_only=True)
            for dte in future_dates:
                dow = pd.to_datetime(dte).dayofweek
                occ_b = dow_occ.get(dow, sub['occ_baseline'].tail(7).mean())
                rate_b = dow_rate.get(dow, sub['rate_baseline'].tail(7).mean())
                occ_adj = np.clip(occ_b * (1 + 0.02*last_signals.get('waitlist',0) + 0.005*last_signals.get('inquiries',0) - 0.01*last_signals.get('lead_time_days',0)), 0, 1.0)
                rate_adj = rate_b * (1 + 0.4*(occ_adj - occ_b))
                exp_rev = occ_adj * 16 * (rate_adj)  # 16 hours * hourly rate approximation
                ypsf = exp_rev / max(sq_ft,1)
                rows.append({'date': pd.to_datetime(dte).date(), 'asset_id': aid,
                             'occupancy_pct': float(occ_adj),
                             'expected_rate': float(rate_adj) if not np.isnan(rate_adj) else float(sub['avg_rate'].dropna().tail(7).mean()),
                             'expected_revenue': float(exp_rev),
                             'yield_per_sqft': float(ypsf),
                             'sq_ft': float(sq_ft)})
        fc = pd.DataFrame(rows)
        return FinCastResult(forecasts=fc)
