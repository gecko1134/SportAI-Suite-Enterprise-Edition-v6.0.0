
from __future__ import annotations
import pandas as pd
import numpy as np

def _ts(s): return pd.to_datetime(s, errors='coerce')

def from_bookings_csv(
    path: str,
    asset_id_col: str = 'resource_id',
    start_col: str = 'start_time',
    end_col: str = 'end_time',
    price_col: str = 'price',
    created_col: str = 'created_at',
    sq_ft_map: dict | None = None
) -> pd.DataFrame:
    """
    Convert a SportsKey bookings export CSV to SportAI daily history format.
    Output columns: date, asset_id, booked_minutes, revenue, searches, inquiries, waitlist, lead_time_days, sq_ft
    Unknown signals default to 0; lead_time uses created_at if available.
    """
    df = pd.read_csv(path)
    req = [asset_id_col, start_col, end_col]
    for c in req:
        if c not in df.columns:
            raise ValueError(f"Missing required column: {c}")
    df[start_col] = _ts(df[start_col])
    df[end_col]   = _ts(df[end_col])
    if created_col in df.columns:
        df[created_col] = _ts(df[created_col])
    else:
        df[created_col] = df[start_col]

    dur = (df[end_col] - df[start_col]).dt.total_seconds() / 60.0
    df['duration_min'] = dur.clip(lower=0).fillna(0.0)
    df['asset_id'] = df[asset_id_col].astype(str)
    df['date'] = df[start_col].dt.date
    df['revenue'] = pd.to_numeric(df.get(price_col, 0), errors='coerce').fillna(0.0)

    # Signals (placeholders if not present in export)
    df['searches']   = pd.to_numeric(df.get('searches', 0), errors='coerce').fillna(0).astype(int)
    df['inquiries']  = pd.to_numeric(df.get('inquiries', 0), errors='coerce').fillna(0).astype(int)
    df['waitlist']   = pd.to_numeric(df.get('waitlist', 0), errors='coerce').fillna(0).astype(int)

    lead_days = (df[start_col] - df[created_col]).dt.total_seconds() / (3600*24.0)
    df['lead_time_days'] = lead_days.clip(lower=0).fillna(0.0)

    out = df.groupby(['asset_id','date'], as_index=False).agg(
        booked_minutes=('duration_min','sum'),
        revenue=('revenue','sum'),
        searches=('searches','sum'),
        inquiries=('inquiries','sum'),
        waitlist=('waitlist','sum'),
        lead_time_days=('lead_time_days','mean')
    )

    if sq_ft_map:
        out['sq_ft'] = out['asset_id'].map(sq_ft_map).astype(float)
    else:
        out['sq_ft'] = np.nan

    cols = ['date','asset_id','booked_minutes','revenue','searches','inquiries','waitlist','lead_time_days','sq_ft']
    return out[cols]
