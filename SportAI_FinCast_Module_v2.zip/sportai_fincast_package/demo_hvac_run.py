
import pandas as pd
from pathlib import Path
from sportai.fincast.trainer import FinCastTrainer
from sportai.fincast.validator import load_json, validate_config
from sportai.ops.hvac_planner import plan_setpoints

BASE = Path(__file__).resolve().parent
cfg = load_json(BASE / 'sample_fincast_config.json')
schema = load_json(BASE / 'fincast_config.schema.json')
errs = validate_config(cfg, schema)
assert not errs, f'Config invalid: {errs}'

fc_path = BASE / 'forecast_14d.csv'
if not fc_path.exists():
    # build forecast from sample data
    assets = pd.read_csv(BASE / 'sample_data' / 'assets.csv')
    history = pd.read_csv(BASE / 'sample_data' / 'history.csv')
    trainer = FinCastTrainer(cfg)
    res = trainer.forecast(history, horizon_days=14, assets=assets)
    res.forecasts.to_csv(fc_path, index=False)

fc = pd.read_csv(fc_path, parse_dates=['date'])
plan = plan_setpoints(fc, str(BASE / 'sample_fincast_config.json'))
out = BASE / 'hvac_plan.csv'
plan.to_csv(out, index=False)
print('HVAC plan saved to', out)
