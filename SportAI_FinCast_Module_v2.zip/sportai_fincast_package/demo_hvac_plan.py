
import pandas as pd
from pathlib import Path
import json
from sportai.ops.hvac_planner import build_hvac_plan
from sportai.fincast.validator import load_json, validate_config
from sportai.fincast.trainer import FinCastTrainer

BASE = Path(__file__).resolve().parent
cfg_path = BASE / 'sample_fincast_config.json'
schema_path = BASE / 'fincast_config.schema.json'

def main():
    schema = load_json(schema_path)
    cfg = load_json(cfg_path)
    errors = validate_config(cfg, schema)
    assert not errors, f'Config invalid: {errors}'

    # Prepare forecast (use existing file if present)
    fc_path = BASE / 'forecast_14d.csv'
    if fc_path.exists():
        fc = pd.read_csv(fc_path, parse_dates=['date']).assign(date=lambda d: d['date'].dt.date)
    else:
        assets = pd.read_csv(BASE / 'sample_data' / 'assets.csv')
        history = pd.read_csv(BASE / 'sample_data' / 'history.csv')
        trainer = FinCastTrainer(cfg)
        res = trainer.forecast(history, horizon_days=7)
        fc = res.forecasts

    hvac_cfg = cfg['actions']['hvac']
    plan = build_hvac_plan(fc[['date','asset_id','occupancy_pct','expected_rate','sq_ft']], hvac_cfg)
    out_path = BASE / 'hvac_schedule.csv'
    plan.schedule.sort_values(['date','asset_id','hour']).to_csv(out_path, index=False)
    print('HVAC schedule saved to:', out_path)

if __name__ == '__main__':
    main()
