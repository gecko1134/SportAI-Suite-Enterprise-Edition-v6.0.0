
import json
from pathlib import Path
import pandas as pd
import streamlit as st

st.set_page_config(page_title="SportAI FinCast Dashboard", layout="wide")

BASE = Path(__file__).resolve().parents[1]
fc_path = BASE / "forecast_14d.csv"
assets_path = BASE / "sample_data" / "assets.csv"
sponsor_path = BASE / "sponsor_zones.json"

st.title("SportAI FinCast — Courts & Sponsor Zones")

@st.cache_data
def load_data():
    fc = pd.read_csv(fc_path, parse_dates=["date"])
    assets = pd.read_csv(assets_path)
    sponsors = json.loads(sponsor_path.read_text())
    return fc, assets, sponsors

fc, assets, sponsors = load_data()

left, right = st.columns([3,2])

with left:
    st.subheader("Yield/ft² Forecast (next 14 days)")
    asset_filter = st.multiselect("Assets", sorted(fc["asset_id"].unique().tolist()), default=sorted(fc["asset_id"].unique().tolist()))
    fc_f = fc[fc["asset_id"].isin(asset_filter)].copy()
    # KPI tiles
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Avg Yield/ft²", f"${fc_f['yield_per_sqft'].mean():.2f}")
    k2.metric("Avg Rate", f"${fc_f['expected_rate'].mean():.0f}/hr")
    k3.metric("Avg Occ.", f"{fc_f['occupancy_pct'].mean()*100:.0f}%")
    k4.metric("Total Forecast Rev", f"${fc_f['expected_revenue'].sum():,.0f}")
    st.dataframe(
        fc_f.sort_values(["date","yield_per_sqft"], ascending=[True, False]).reset_index(drop=True),
        use_container_width=True, height=420
    )

with right:
    st.subheader("Sponsor Zones — Forecasted Impressions")
    cfg = sponsors
    peak_hours = set(cfg.get("assumptions",{}).get("peak_hours", []))
    imp_per_hr = cfg["assumptions"]["impressions_per_occupied_hour"]
    dwell_peak = cfg["assumptions"]["dwell_multiplier_peak"]
    # Create a quick hourly expansion (assume uniform occupancy across open hours)
    # We'll approximate with 16-hr open day; impressions scaled by occupancy_pct and peak dwell
    fc2 = fc.copy()
    fc2["open_hours"] = 16
    fc2["occ_hours"] = fc2["occupancy_pct"] * fc2["open_hours"]
    # For peak adjustment, add 25% of occ_hours as peak share
    fc2["peak_adjust"] = 0.25 * fc2["occ_hours"]
    zone_rows = []
    for z in cfg["zones"]:
        linked = set(z["linked_assets"])
        zdf = fc2[fc2["asset_id"].isin(linked)]
        # impressions baseline
        imps = (zdf["occ_hours"] * imp_per_hr).sum()
        # peak dwell bump
        imps *= dwell_peak
        # zone factor
        imps *= z["impression_factor"]
        zone_rows.append({"sponsor_zone_id": z["sponsor_zone_id"], "name": z["name"], "linked_assets": ", ".join(sorted(linked)), "forecast_impressions": int(imps)})
    ztable = pd.DataFrame(zone_rows).sort_values("forecast_impressions", ascending=False)
    st.dataframe(ztable, use_container_width=True, height=420)

st.caption("Config-driven: change pricing guardrails & HVAC in JSON; refresh to see updated projections.")
