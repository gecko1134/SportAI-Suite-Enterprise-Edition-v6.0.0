
#!/usr/bin/env python3
"""
SportAI FinCast Sync Script
- Pulls bookings from SportsKey API (stubbed client)
- Writes history.csv
- Regenerates forecast_14d.csv and hvac_plan.csv
- Optional Git commit & push

Usage:
  python sportai_sync.py --api-base https://api.example.com --api-key $KEY \
      --start 2025-01-01 --end 2025-01-31 \
      --sqft-map '{"Court-1":7488,"Court-2":7488}' \
      --git-commit --git-branch main
"""

import os, sys, json, argparse, subprocess
from pathlib import Path
import pandas as pd

# Local imports
sys.path.append(str(Path(__file__).resolve().parent))
from sportai.ingest.sportskey_api import SportsKeyClient, bookings_to_history
from sportai.fincast.trainer import FinCastTrainer
from sportai.fincast.validator import load_json, validate_config
from sportai.ops.hvac_planner import plan_setpoints

def run(cmd, cwd=None):
    try:
        res = subprocess.run(cmd, cwd=cwd, check=True, capture_output=True, text=True)
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        return f"[WARN] Command failed: {' '.join(cmd)}\n{e.stdout}\n{e.stderr}"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--api-base", required=True)
    ap.add_argument("--api-key", required=True)
    ap.add_argument("--start", required=True, help="YYYY-MM-DD")
    ap.add_argument("--end", required=True, help="YYYY-MM-DD")
    ap.add_argument("--sqft-map", default="", help='JSON mapping of asset_id to sq_ft')
    ap.add_argument("--out-dir", default=".", help="Output directory (package root)")
    ap.add_argument("--git-commit", action="store_true", help="Commit & push changes")
    ap.add_argument("--git-branch", default="main")
    args = ap.parse_args()

    base = Path(args.out_dir).resolve()

    # Load config
    cfg = load_json(base / "sample_fincast_config.json")
    schema = load_json(base / "fincast_config.schema.json")
    errs = validate_config(cfg, schema)
    if errs:
        print("Config invalid:", errs, file=sys.stderr)
        sys.exit(1)

    # Fetch bookings via API
    client = SportsKeyClient(args.api_base, args.api_key)
    raw = client.fetch_bookings(start_date=args.start, end_date=args.end)

    # Convert to daily history
    sqft_map = json.loads(args.sqft_map) if args.sqft_map.strip() else None
    hist = bookings_to_history(raw, sq_ft_map=sqft_map)

    # Merge (append) with existing history if present
    hist_path = base / "sample_data" / "history.csv"
    hist_path.parent.mkdir(parents=True, exist_ok=True)
    if hist_path.exists():
        old = pd.read_csv(hist_path, parse_dates=["date"])
        old["date"] = old["date"].dt.date
        # Align types
        hist["date"] = pd.to_datetime(hist["date"]).dt.date
        combined = pd.concat([old, hist], ignore_index=True).drop_duplicates(subset=["date","asset_id"], keep="last")
    else:
        combined = hist
    combined.to_csv(hist_path, index=False)
    print(f"Wrote history: {hist_path} ({len(combined)} rows)")

    # Run FinCast
    trainer = FinCastTrainer(cfg)
    res = trainer.forecast(combined, horizon_days=14)
    fc = res.forecasts
    fc_path = base / "forecast_14d.csv"
    fc.to_csv(fc_path, index=False)
    print(f"Wrote forecast: {fc_path} ({len(fc)} rows)")

    # HVAC plan
    plan = plan_setpoints(fc, str(base / "sample_fincast_config.json"))
    hvac_path = base / "hvac_plan.csv"
    plan.to_csv(hvac_path, index=False)
    print(f"Wrote HVAC plan: {hvac_path} ({len(plan)} rows)")

    # Optional Git commit & push
    if args.git_commit:
        msgs = []
        msgs.append(run(["git", "add", str(hist_path), str(fc_path), str(hvac_path)], cwd=str(base)))
        msgs.append(run(["git", "commit", "-m", f"FinCast sync: {args.start}..{args.end}"], cwd=str(base)))
        msgs.append(run(["git", "push", "origin", args.git_branch], cwd=str(base)))
        print("\n".join(msgs))

if __name__ == "__main__":
    main()
