
#!/usr/bin/env bash
# Example: run every night at 2:10 AM via crontab -e
# 10 2 * * * /usr/bin/env bash /path/to/SportAI_FinCast_v5/cron_example.sh >> /var/log/sportai_fincast.log 2>&1

set -euo pipefail
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Export secrets from env or a secure store
API_BASE="https://api.sportskey.io"
API_KEY="$SPORTSKEY_API_KEY"  # ensure exported in the environment

python3 sportai_sync.py   --api-base "$API_BASE"   --api-key "$API_KEY"   --start "$(date -d 'yesterday 00:00' +%F)"   --end   "$(date -d 'yesterday 23:59' +%F)"   --sqft-map '{"Court-1":7488,"Court-2":7488,"Court-3":7488,"Court-4":7488}'   --out-dir .   --git-commit --git-branch main
