#!/usr/bin/env bash
set -euo pipefail
BRANCH="${1:-feature/lead-time-watch}"
REPO_DIR="${2:-.}"

echo ">> Using branch: $BRANCH"
echo ">> Repo dir: $REPO_DIR"

cd "$REPO_DIR"
git checkout -b "$BRANCH" || git checkout "$BRANCH"

# Copy files
cp -R "${BASH_SOURCE%/*}/src/modules" ./
cp -R "${BASH_SOURCE%/*}/src/shared" ./
mkdir -p ./icons
cp "${BASH_SOURCE%/*}/src/icons/lead_time_watch_icon.svg" ./icons/

# Apply patch
git apply "${BASH_SOURCE%/*}/main_app.patch" || echo "Patch failed to apply cleanly — please merge the snippet manually."

git add modules/pricing/lead_time_watch.py shared/ui/traffic_lights.py shared/config/sportai_lead_time_config.json icons/lead_time_watch_icon.svg || true
git add main_app.py || true
git commit -m "feat(pricing): add Lead-Time Watch (pricing signals via median lead-time & utilization)"
echo ">> Committed. Push with: git push -u origin $BRANCH"
