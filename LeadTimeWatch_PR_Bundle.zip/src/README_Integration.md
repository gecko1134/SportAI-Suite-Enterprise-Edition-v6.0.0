# SportAI Integration — Lead-Time Watch
Files:
- modules/pricing/lead_time_watch.py
- shared/ui/traffic_lights.py
- shared/config/sportai_lead_time_config.json

Add to `main_app.py`:
```python
from modules.pricing import lead_time_watch
TOOLS.append({
    "name": lead_time_watch.get_tool_metadata()["name"],
    "category": lead_time_watch.get_tool_metadata()["category"],
    "roles": lead_time_watch.get_tool_metadata()["roles"],
    "slug": lead_time_watch.get_tool_metadata()["slug"],
    "runner": lead_time_watch.run
})
```
