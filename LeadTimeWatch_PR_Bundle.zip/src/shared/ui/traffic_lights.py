import streamlit as st

def _pill(text:str, variant:str="neutral"):
    colors = {"good":("#0d7a0d","#eaf6ea"),"warn":("#9d6a00","#fff4e5"),"bad":("#8f1d1d","#fdeaea"),"neutral":("#2d3a4a","#eef2f7")}
    fg, bg = colors.get(variant, colors["neutral"])
    st.markdown(f"<span style='background:{bg};color:{fg};padding:4px 8px;border-radius:999px;font-weight:600'>{text}</span>", unsafe_allow_html=True)

def render_cards(recs_df):
    if recs_df is None or recs_df.empty:
        st.info("No recommendations yet — upload data to see signals.")
        return
    cols = st.columns(min(3, len(recs_df)))
    for i, row in enumerate(recs_df.itertuples(), start=0):
        with cols[i % len(cols)]:
            st.markdown(f"### {row.band}")
            if row.rec == "RAISE":
                _pill("RAISE", "good")
            elif row.rec.startswith("PROMO"):
                _pill("PROMO/REDUCE", "bad")
            else:
                _pill("HOLD", "warn" if getattr(row, "leadtime_drop_pct", 0) else "neutral")
            st.metric("Lead-time (days)", f"{int(row.median_lead_days) if row.median_lead_days==row.median_lead_days else '—'}")
            st.metric("Utilization", f"{row.utilization:.0%}" if row.utilization==row.utilization else "—")
            st.caption(f"Δ target: {row.delta_pct:+.0%} • {row.reason}")
