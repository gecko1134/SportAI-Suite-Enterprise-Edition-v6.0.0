# Add Lead-Time Watch (Pricing Signals)

This PR adds a new **Pricing Tools** tab, *Lead-Time Watch*, that monitors median booking lead-time and utilization by band to suggest **RAISE / HOLD / PROMO** actions.

## What’s included
- `modules/pricing/lead_time_watch.py` — Streamlit tab (`run()`)
- `shared/ui/traffic_lights.py` — UI helper for traffic-light cards
- `shared/config/sportai_lead_time_config.json` — default thresholds/bands
- `icons/lead_time_watch_icon.svg` — sidebar icon
- `main_app.py` wiring (TOOLS, ICON_MAP, CATEGORY_ORDER)

## Why
Shrinking lead-time while utilization is high is a robust underpricing signal for peak bands. This adds a low-noise rule to nudge price moves before sell-outs.

## How to test
- Launch the app and open **Pricing Tools → Lead-Time Watch**
- Upload `sportai_lead_time_config.json` (or keep default)
- Upload a SportsKey export CSV (sample columns: `resource_id, resource_type, slot_start, slot_end, booking_created_at, status, price_list_rate, price_paid, discount_applied`)
- Confirm cards render and `pricing_recommendations.csv` downloads

## Safety rails
- Single-move cap (`max_single_move_pct`), rollbacks if util < 80%
- Band-specific thresholds and windows
