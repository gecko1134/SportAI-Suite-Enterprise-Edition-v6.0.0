
# SportAI FinCast v4

Includes:
- JSON Schema + Sample Config
- Validator + Pricing Guardrails + Integration Helper
- FinCastTrainer (baseline) with 14-day forecast
- SportsKey CSV Ingest Adapter
- HVAC Setpoint Planner (what-if overrides)
- Sponsor Zones config + What-If logic
- Streamlit Dashboard (KPIs, Sponsor Zones, Ingest & HVAC, Pricing Guardrails + PDF/HTML exports)
- Notebook demo
- Tests
- Sample data and demos

## Quickstart
```bash
cd SportAI_FinCast_v4
python -m pip install -e .
pytest -q
python demo_fincast_run.py
python demo_hvac_run.py

# Dashboard
cd dashboard
streamlit run app.py
```


## SportsKey API (Stub)
- File: `sportai/ingest/sportskey_api.py`
- Use `SportsKeyClient(base_url, api_key).fetch_bookings(start_date, end_date)` then `bookings_to_history(df, sq_ft_map)` to convert to history.
- Replace `_fetch_json` with real HTTP logic and pagination.

## Sponsor Admin Suite Inventory
- If `sponsorship_inventory.json` exists at the package root, the dashboard auto-loads zones/placements and maps linked assets.
- Supported shapes:
  - `{"zones":[{"id":"Z-1","name":"", "linked_assets":[...], "impression_factor":1.0}, ...]}`
  - or `{"placements":[{"zone_id":"Z-1","name":"", "assets":[...], "impression_factor":1.0}, ...]}`
