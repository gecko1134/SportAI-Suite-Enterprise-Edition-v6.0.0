
import json
from io import StringIO
from pathlib import Path
import pandas as pd
import streamlit as st

from sportai.fincast.trainer import FinCastTrainer
from sportai.fincast.validator import load_json, validate_config
from sportai.ingest.sportskey_adapter import from_bookings_csv
from sportai.ops.hvac_planner import plan_setpoints
from sportai.pricing.guardrails import clamp, apply_fairness
from sportai.export.pdf_builder import build_pricing_pdf_bytes, build_sponsor_packet_pdf_bytes


def _load_sponsor_cfg_with_inventory(base_path: Path, default_cfg: dict) -> dict:
    inv_path = base_path / "sponsorship_inventory.json"
    if not inv_path.exists():
        return default_cfg
    try:
        inv = json.loads(inv_path.read_text())
        # Expect either "zones" with linked_assets or "placements" that include asset links.
        zones = []
        if "zones" in inv:
            # Normalize to expected structure
            for z in inv["zones"]:
                zones.append({
                    "sponsor_zone_id": z.get("id") or z.get("sponsor_zone_id") or z.get("name"),
                    "name": z.get("name","Zone"),
                    "linked_assets": z.get("linked_assets", []),
                    "impression_factor": z.get("impression_factor", 1.0)
                })
        elif "placements" in inv:
            # Group placements by zone key
            from collections import defaultdict
            group = defaultdict(lambda: {"name":"", "assets": set(), "factor": 1.0})
            for p in inv["placements"]:
                zid = p.get("zone_id") or p.get("placement_id") or p.get("name","Z")
                group[zid]["name"] = p.get("name", zid)
                if "assets" in p:
                    for a in p["assets"]:
                        group[zid]["assets"].add(a)
                group[zid]["factor"] = p.get("impression_factor", group[zid]["factor"])
            for zid, g in group.items():
                zones.append({
                    "sponsor_zone_id": zid,
                    "name": g["name"] or zid,
                    "linked_assets": sorted(list(g["assets"])),
                    "impression_factor": g["factor"]
                })
        if zones:
            default_cfg = dict(default_cfg) if default_cfg else {"zones":[], "assumptions": {"impressions_per_occupied_hour":35,"dwell_multiplier_peak":1.25,"peak_hours":[17,18,19,20]}}
            default_cfg["zones"] = zones
        return default_cfg
    except Exception:
        return default_cfg


st.set_page_config(page_title="SportAI FinCast Dashboard", layout="wide")
BASE = Path(__file__).resolve().parents[1]
cfg_path = BASE / "sample_fincast_config.json"
schema_path = BASE / "fincast_config.schema.json"
sponsor_path = BASE / "sponsor_zones.json"
forecast_path = BASE / "forecast_14d.csv"
hvac_path = BASE / "hvac_plan.csv"

st.title("SportAI FinCast — Courts, Pricing, & Sponsor Zones")

@st.cache_data
def load_config():
    cfg = load_json(cfg_path)
    schema = load_json(schema_path)
    errs = validate_config(cfg, schema)
    return cfg, errs

@st.cache_data
def load_sample():
    fc = pd.read_csv(forecast_path, parse_dates=["date"]) if forecast_path.exists() else None
    raw_sponsors = json.loads(sponsor_path.read_text()) if sponsor_path.exists() else {"zones": [], "assumptions": {"impressions_per_occupied_hour": 35, "dwell_multiplier_peak": 1.25, "peak_hours": [17,18,19,20]}}
    sponsors = _load_sponsor_cfg_with_inventory(BASE, raw_sponsors)
    return fc, sponsors

cfg, errs = load_config()
if errs:
    st.error(f"Config invalid: {errs}")
fc, sponsors_cfg = load_sample()

tab1, tab2, tab3, tab4 = st.tabs(["Forecast & KPIs", "Sponsor Zones", "Ingest & HVAC What-If", "Pricing Guardrails"])

with tab1:
    st.subheader("Yield/ft² Forecast (next 14 days)")
    if fc is None:
        st.info("No forecast found yet. Use 'Ingest & HVAC What-If' to generate from CSV or run the demo.")
    else:
        asset_filter = st.multiselect("Assets", sorted(fc["asset_id"].unique().tolist()), default=sorted(fc["asset_id"].unique().tolist()))
        fc_f = fc[fc["asset_id"].isin(asset_filter)].copy()
        k1, k2, k3, k4 = st.columns(4)
        k1.metric("Avg Yield/ft²", f"${fc_f['yield_per_sqft'].mean():.2f}")
        k2.metric("Avg Rate", f"${fc_f['expected_rate'].mean():.0f}/hr")
        k3.metric("Avg Occ.", f"{fc_f['occupancy_pct'].mean()*100:.0f}%")
        k4.metric("Total Forecast Rev", f"${fc_f['expected_revenue'].sum():,.0f}")
        st.dataframe(fc_f.sort_values(["date","yield_per_sqft"], ascending=[True, False]).reset_index(drop=True), use_container_width=True, height=420)

with tab2:
    st.subheader("Sponsor Zones — Forecasted Impressions (What-If)")
    if fc is None:
        st.info("Generate a forecast first (tab 3) or run the notebook/demo.")
    else:
        imp_per_hr = st.slider("Impressions per occupied hour", 10, 120, int(sponsors_cfg.get("assumptions",{}).get("impressions_per_occupied_hour", 35)), 5)
        dwell_peak = st.slider("Dwell multiplier (peak)", 1.0, 2.0, float(sponsors_cfg.get("assumptions",{}).get("dwell_multiplier_peak", 1.25)), 0.05)
        fc2 = fc.copy(); fc2["open_hours"] = 16; fc2["occ_hours"] = fc2["occupancy_pct"] * fc2["open_hours"]
        zones = sponsors_cfg.get("zones", [])
        if zones:
            zdf = pd.DataFrame(zones)
            zdf = st.data_editor(zdf, num_rows="dynamic", use_container_width=True, key="zones_editor")
            zones = zdf.to_dict(orient="records")
        rows = []
        for z in zones:
            linked = set(z.get("linked_assets", []))
            zdf = fc2[fc2["asset_id"].isin(linked)]
            imps = (zdf["occ_hours"] * imp_per_hr).sum() * dwell_peak * float(z.get("impression_factor", 1.0))
            rows.append({"sponsor_zone_id": z.get("sponsor_zone_id",""), "name": z.get("name",""), "linked_assets": ", ".join(sorted(linked)) if linked else "", "impression_factor": float(z.get("impression_factor", 1.0)), "forecast_impressions": int(imps)})
        ztable = pd.DataFrame(rows).sort_values("forecast_impressions", ascending=False) if rows else pd.DataFrame(columns=["sponsor_zone_id","name","linked_assets","impression_factor","forecast_impressions"])
        st.dataframe(ztable, use_container_width=True, height=420)
        st.download_button("Download Sponsor Impressions CSV", data=ztable.to_csv(index=False), file_name="sponsor_zone_impressions.csv", mime="text/csv")
        if not ztable.empty:
            pdf_bytes, mime = build_sponsor_packet_pdf_bytes(ztable, {"impressions_per_occupied_hour": imp_per_hr, "dwell_multiplier_peak": dwell_peak})
            fname = "sponsor_zone_packet.pdf" if mime == "application/pdf" else "sponsor_zone_packet.html"
            st.download_button("Export Sponsor Packet (PDF)", data=pdf_bytes, file_name=fname, mime=mime)

with tab3:
    st.subheader("Ingest SportsKey CSV → Forecast → HVAC Plan")
    uploaded = st.file_uploader("Drop a SportsKey bookings CSV", type=["csv"])
    colA, colB = st.columns([2,1])
    with colB:
        st.caption("Optional: sq_ft mapping (JSON)")
        sqft_json = st.text_area("sq_ft_map (e.g., {"Court-1":7488})", value="")
        try: sqft_map = json.loads(sqft_json) if sqft_json.strip() else None
        except Exception: sqft_map=None; st.warning("Invalid JSON in sq_ft_map; ignoring.")

    if uploaded is not None:
        csv_bytes = uploaded.getvalue().decode("utf-8"); buf = StringIO(csv_bytes)
        try:
            hist = from_bookings_csv(buf, sq_ft_map=sqft_map)
            st.success(f"Ingested {len(hist)} daily rows from CSV.")
            trainer = FinCastTrainer(cfg); res = trainer.forecast(hist, horizon_days=14); fc = res.forecasts
            fc.to_csv(forecast_path, index=False); st.session_state['fc_df'] = fc; st.write("Forecast generated. Sample:", fc.head())
        except Exception as e:
            st.error(f"Failed to process CSV: {e}")

    st.markdown("### HVAC What-If")
    idle_shift = st.slider("Idle setpoint shift", 0.0, 6.0, float(cfg['actions']['hvac'].get('idle_setpoint_shift', 3)), 0.5)
    precond = st.slider("Precondition hours", 0.0, 3.0, float(cfg['actions']['hvac'].get('precondition_hours', 1)), 0.5)

    fc_src = st.session_state.get('fc_df', None)
    if fc_src is None and fc is not None: fc_src = fc
    if fc_src is not None:
        plan = plan_setpoints(fc_src, str(cfg_path), idle_override=idle_shift, precond_override=precond)
        st.dataframe(plan.head(100), use_container_width=True, height=420)
        st.download_button("Download HVAC Plan CSV", data=plan.to_csv(index=False), file_name="hvac_plan.csv", mime="text/csv")
        plan.to_csv(hvac_path, index=False)
    else:
        st.info("No forecast available yet. Upload a CSV or run the notebook/demo to create one.")

with tab4:
    st.subheader("Pricing Guardrails — Live Preview & PDF Export")
    c1, c2, c3 = st.columns(3)
    with c1: base_rate = st.number_input("Base rate ($/hr)", min_value=0.0, value=100.0, step=1.0)
    with c2: proposed = st.number_input("Proposed rate ($/hr)", min_value=0.0, value=125.0, step=1.0)
    with c3: hour = st.number_input("Hour of day (0-23)", min_value=0, max_value=23, value=10, step=1)
    groups_all = ["youth","schools_k12","nonprofit_501c3","rec_leagues","disabled_athletes"]
    groups = st.multiselect("Booking groups (select all that apply)", groups_all, default=[])
    try:
        cfg_json = load_json(cfg_path)
        clamped = clamp(proposed, base_rate, cfg_json["controls"]["price_floor"], cfg_json["controls"]["price_ceiling"])
        fair = apply_fairness(clamped, base_rate, hour, {"groups": groups}, cfg_json["controls"]["fairness_rules"])
        r_final = fair
        df = pd.DataFrame([{"step":"Base","rate":base_rate},{"step":"Proposed","rate":proposed},{"step":"Clamp","rate":clamped},{"step":"Clamp + Fairness","rate":fair}])
        st.dataframe(df, use_container_width=True, height=200)
        st.metric("Recommended Rate", f"${r_final:.2f}")
        pdf_bytes, mime = build_pricing_pdf_bytes(base_rate, proposed, clamped, fair, groups, {"subtitle":"Config-driven guardrails"})
        fname = "pricing_guardrails_preview.pdf" if mime == "application/pdf" else "pricing_guardrails_preview.html"
        st.download_button("Export Pricing Preview (PDF)", data=pdf_bytes, file_name=fname, mime=mime)
    except Exception as e:
        st.error(f"Could not compute pricing preview: {e}")
