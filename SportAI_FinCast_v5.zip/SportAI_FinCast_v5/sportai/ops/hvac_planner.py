
from __future__ import annotations
import pandas as pd, numpy as np, json
from pathlib import Path

def plan_setpoints(forecast_df: pd.DataFrame, config_path: str, open_hours=(6,22), idle_override=None, precond_override=None) -> pd.DataFrame:
    cfg = json.loads(Path(config_path).read_text())
    hvac_cfg = cfg['actions']['hvac']
    idle_shift = float(hvac_cfg.get('idle_setpoint_shift', 3)) if idle_override is None else float(idle_override)
    precond_hrs = float(hvac_cfg.get('precondition_hours', 1)) if precond_override is None else float(precond_override)

    df = forecast_df.copy()
    df['open_hours'] = max(1, int(open_hours[1]-open_hours[0]))
    df['occ_hours'] = df['occupancy_pct'] * df['open_hours']

    rows = []
    for (asset, date), sub in df.groupby(['asset_id','date']):
        hours = list(range(open_hours[0], open_hours[1]))
        occ_per_hr = (sub['occ_hours'].iloc[0] / len(hours)) if len(sub) else 0.0
        peak = occ_per_hr >= 0.6
        first_peak_hr = hours[0] if peak else None
        for h in hours:
            mode = 'idle'; shift = idle_shift
            if peak: mode='peak'; shift=0.0
            if first_peak_hr is not None and (h >= first_peak_hr - int(precond_hrs)) and (h < first_peak_hr):
                mode='precondition'; shift=-1.0
            rows.append({'date': pd.to_datetime(date), 'asset_id': asset, 'hour': h, 'mode': mode, 'setpoint_shift': float(shift)})
    return pd.DataFrame(rows).sort_values(['date','asset_id','hour']).reset_index(drop=True)
