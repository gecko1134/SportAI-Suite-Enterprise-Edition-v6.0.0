
from jsonschema import Draft7Validator
import json

def load_json(path):
    import pathlib
    with open(path, 'r') as f:
        return json.load(f)

def validate_config(config: dict, schema: dict):
    validator = Draft7Validator(schema)
    errors = sorted(validator.iter_errors(config), key=lambda e: e.path)
    messages = []
    for err in errors:
        loc = ".".join([str(p) for p in err.path])
        messages.append(f"{loc}: {err.message}")
    return messages

def validate_files(config_path: str, schema_path: str):
    config = load_json(config_path)
    schema = load_json(schema_path)
    return validate_config(config, schema)
