
from __future__ import annotations
from typing import Optional, Dict, Any
import pandas as pd
import datetime as dt

class SportsKeyClient:
    """
    Minimal stub for SportsKey REST API.
    Replace `_fetch_json` with real requests.get(...) using your API base and key.
    """
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def _fetch_json(self, endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
        # TODO: implement real HTTP call with pagination & auth headers.
        # For now, return an empty payload structure.
        return {"data": []}

    def fetch_bookings(self, start_date: str, end_date: str) -> pd.DataFrame:
        """
        Fetch bookings between ISO dates (YYYY-MM-DD). Expected fields:
        resource_id, start_time, end_time, price, created_at
        """
        payload = self._fetch_json("/bookings", {"start_date": start_date, "end_date": end_date})
        rows = payload.get("data", [])
        return pd.DataFrame(rows)

def bookings_to_history(df: pd.DataFrame, sq_ft_map: Optional[Dict[str, float]] = None) -> pd.DataFrame:
    """
    Convert raw SportsKey API bookings DataFrame to SportAI daily history.
    Columns out: date, asset_id, booked_minutes, revenue, searches, inquiries, waitlist, lead_time_days, sq_ft
    """
    if df.empty:
        return pd.DataFrame(columns=["date","asset_id","booked_minutes","revenue","searches","inquiries","waitlist","lead_time_days","sq_ft"])
    # Ensure columns
    for c in ["resource_id","start_time","end_time"]:
        if c not in df.columns:
            raise ValueError(f"Missing required column from API: {c}")
    ts = pd.to_datetime
    df = df.copy()
    df["start_time"] = ts(df["start_time"], errors="coerce")
    df["end_time"]   = ts(df["end_time"], errors="coerce")
    if "created_at" in df.columns:
        df["created_at"] = ts(df["created_at"], errors="coerce")
    else:
        df["created_at"] = df["start_time"]

    df["duration_min"] = (df["end_time"] - df["start_time"]).dt.total_seconds() / 60.0
    df["date"] = df["start_time"].dt.date
    df["asset_id"] = df["resource_id"].astype(str)
    df["revenue"] = pd.to_numeric(df.get("price", 0), errors="coerce").fillna(0.0)
    df["lead_time_days"] = ((df["start_time"] - df["created_at"]).dt.total_seconds()/(3600*24)).clip(lower=0).fillna(0.0)
    # Optional signals (default 0 if missing)
    for s in ["searches","inquiries","waitlist"]:
        if s not in df.columns:
            df[s] = 0

    out = df.groupby(["asset_id","date"], as_index=False).agg(
        booked_minutes=("duration_min","sum"),
        revenue=("revenue","sum"),
        searches=("searches","sum"),
        inquiries=("inquiries","sum"),
        waitlist=("waitlist","sum"),
        lead_time_days=("lead_time_days","mean")
    )
    out["sq_ft"] = out["asset_id"].map(sq_ft_map).astype(float) if sq_ft_map else float("nan")
    cols = ["date","asset_id","booked_minutes","revenue","searches","inquiries","waitlist","lead_time_days","sq_ft"]
    return out[cols]
