
import pandas as pd
from pathlib import Path
from sportai.fincast.trainer import FinCastTrainer
from sportai.fincast.validator import load_json, validate_config

BASE = Path(__file__).resolve().parent
cfg = load_json(BASE / 'sample_fincast_config.json')
schema = load_json(BASE / 'fincast_config.schema.json')
errs = validate_config(cfg, schema); assert not errs, f"Config invalid: {errs}"

assets = pd.read_csv(BASE / 'sample_data' / 'assets.csv')
history = pd.read_csv(BASE / 'sample_data' / 'history.csv')

trainer = FinCastTrainer(cfg)
res = trainer.forecast(history, horizon_days=14, assets=assets)
res.forecasts.to_csv(BASE / 'forecast_14d.csv', index=False)
print("Saved forecast_14d.csv")
