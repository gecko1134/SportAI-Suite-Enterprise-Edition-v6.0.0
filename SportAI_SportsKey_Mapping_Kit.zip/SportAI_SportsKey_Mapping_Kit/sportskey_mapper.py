"""
SportsKey ↔︎ SportAI Shadow Mode Mapper
---------------------------------------
Transforms SportsKey CSV exports into shadow_logger-compatible CSVs
and builds a SportsKey import template from shadow logs.

Run examples:
    python sportskey_mapper.py export_to_shadow sportskey_export.csv shadow_logs.csv
    python sportskey_mapper.py shadow_to_import shadow_logs.csv sportskey_import.csv
"""

import sys, csv, json, uuid, datetime

# ---- Config: map your column names here if your SportsKey export differs ----
EXPORT_COLS = {
    "booking_id": "booking_id",
    "resource_id": "resource_id",
    "resource_type": "resource_type",
    "start_time": "start_time",
    "end_time": "end_time",
    "member_tier": "member_tier",
    "booking_type": "booking_type",
    "proposed_price": "proposed_price",
    "layout": "layout",
    "pod": "pod",
    "predicted_revenue": "predicted_revenue",
    "predicted_utilization": "predicted_utilization",
    "predicted_impressions": "predicted_impressions",
    "demand_lead_time_days": "demand_lead_time_days",
    "historic_util_4w": "historic_util_4w",
    "prime": "prime",
    "season": "season",
    "city_policy": "city_policy",
    "reason_codes": "reason_codes",
    "would_do_action": "would_do_action",
    "guardrail_flags": "guardrail_flags",
    "actual_revenue": "actual_revenue",
    "actual_utilization": "actual_utilization",
    "actual_impressions": "actual_impressions",
}

def _get(row, key, default=""):
    col = EXPORT_COLS.get(key, key)
    return row.get(col, default)

def export_to_shadow(export_csv_path, out_csv_path):
    headers = [
        "suggestion_id","created_at","asset_id","asset_type","time_block_start","time_block_end",
        "tier","event_type","suggested_price","suggested_layout","suggested_pod",
        "predicted_revenue","predicted_utilization","predicted_sponsor_hits",
        "inputs","reason_codes","would_do_action","guardrail_flags",
        "actual_revenue","actual_utilization","actual_sponsor_hits"
    ]
    with open(export_csv_path, newline="", encoding="utf-8") as fin, \
         open(out_csv_path, "w", newline="", encoding="utf-8") as fout:
        r = csv.DictReader(fin)
        w = csv.DictWriter(fout, fieldnames=headers)
        w.writeheader()
        for row in r:
            sug_id = f"SUG-{_get(row, 'booking_id', uuid.uuid4().hex[:8]).upper()}"
            created_at = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            inputs = {
                "lead_time_days": try_float(_get(row,"demand_lead_time_days",0)),
                "historic_util_4w": try_float(_get(row,"historic_util_4w",0)),
                "prime": parse_bool(_get(row,"prime","false")),
                "season": _get(row,"season",""),
                "city_policy": _get(row,"city_policy",""),
                "booking_id": _get(row,"booking_id",""),  # retained for traceability
            }
            reason_codes = parse_jsonish_list(_get(row,"reason_codes","[]"))
            guardrails = parse_jsonish_list(_get(row,"guardrail_flags","[]"))
            w.writerow({
                "suggestion_id": sug_id,
                "created_at": created_at,
                "asset_id": _get(row,"resource_id",""),
                "asset_type": _get(row,"resource_type",""),
                "time_block_start": _get(row,"start_time",""),
                "time_block_end": _get(row,"end_time",""),
                "tier": _get(row,"member_tier",""),
                "event_type": _get(row,"booking_type",""),
                "suggested_price": try_float(_get(row,"proposed_price",0)),
                "suggested_layout": _get(row,"layout",""),
                "suggested_pod": _get(row,"pod",""),
                "predicted_revenue": try_float(_get(row,"predicted_revenue",0)),
                "predicted_utilization": try_float(_get(row,"predicted_utilization",0)),
                "predicted_sponsor_hits": try_int(_get(row,"predicted_impressions",0)),
                "inputs": json.dumps(inputs, ensure_ascii=False),
                "reason_codes": json.dumps(reason_codes, ensure_ascii=False),
                "would_do_action": _get(row,"would_do_action",""),
                "guardrail_flags": json.dumps(guardrails, ensure_ascii=False),
                "actual_revenue": try_float(_get(row,"actual_revenue","")) if _get(row,"actual_revenue","")!="" else "",
                "actual_utilization": try_float(_get(row,"actual_utilization","")) if _get(row,"actual_utilization","")!="" else "",
                "actual_sponsor_hits": try_int(_get(row,"actual_impressions","")) if _get(row,"actual_impressions","")!="" else "",
            })

def shadow_to_import(shadow_csv_path, out_csv_path):
    headers = [
        "external_ref","resource_id","resource_type","start_time","end_time",
        "member_tier","booking_type","price","layout","pod","action_hint","guardrail_flags"
    ]
    with open(shadow_csv_path, newline="", encoding="utf-8") as fin, \
         open(out_csv_path, "w", newline="", encoding="utf-8") as fout:
        r = csv.DictReader(fin)
        w = csv.DictWriter(fout, fieldnames=headers)
        w.writeheader()
        for row in r:
            w.writerow({
                "external_ref": row.get("suggestion_id",""),
                "resource_id": row.get("asset_id",""),
                "resource_type": row.get("asset_type",""),
                "start_time": row.get("time_block_start",""),
                "end_time": row.get("time_block_end",""),
                "member_tier": row.get("tier",""),
                "booking_type": row.get("event_type",""),
                "price": safe_round(row.get("suggested_price","")),
                "layout": row.get("suggested_layout",""),
                "pod": row.get("suggested_pod",""),
                "action_hint": row.get("would_do_action",""),
                "guardrail_flags": row.get("guardrail_flags",""),
            })

def try_float(x, default=0.0):
    try:
        return float(str(x).strip())
    except Exception:
        return default

def try_int(x, default=0):
    try:
        return int(float(str(x).strip()))
    except Exception:
        return default

def parse_bool(x):
    return str(x).strip().lower() in ("1","true","yes","y","t")

def parse_jsonish_list(x):
    s = str(x).strip()
    if not s:
        return []
    try:
        val = json.loads(s)
        if isinstance(val, list):
            return val
        return [val]
    except Exception:
        # Fallback: split by comma
        return [p.strip() for p in s.split(",") if p.strip()]

def safe_round(x):
    try:
        return f"{float(x):.2f}"
    except Exception:
        return ""

def main():
    if len(sys.argv) < 4:
        print("Usage:")
        print("  export_to_shadow sportskey_export.csv shadow_logs.csv")
        print("  shadow_to_import shadow_logs.csv sportskey_import.csv")
        sys.exit(1)
    cmd, inp, out = sys.argv[1], sys.argv[2], sys.argv[3]
    if cmd == "export_to_shadow":
        export_to_shadow(inp, out)
    elif cmd == "shadow_to_import":
        shadow_to_import(inp, out)
    else:
        print("Unknown command:", cmd)
        sys.exit(2)

if __name__ == "__main__":
    main()
