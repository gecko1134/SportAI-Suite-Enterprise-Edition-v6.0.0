# SportsKey ↔︎ SportAI Shadow Mode Mapping

This guide maps typical **SportsKey** booking export fields to **SportAI Shadow Logger** fields and provides a reverse template for importing updates.

> Note: SportsKey instances can be customized. If your column names differ, adjust the mapper config at the top of `sportskey_mapper.py`.

## A. Field Mapping (SportsKey Export → Shadow Logger)

| SportsKey Export Field | Example | Shadow Logger Field | Notes |
|---|---|---|---|
| booking_id | BK-10293 | suggestion_id* | If absent, logger will auto-generate SUG-XXXX. |
| resource_id | court_1 | asset_id | Use your canonical resource keys. |
| resource_type | court | asset_type | e.g., `court`, `turf_full`, `turf_half`. |
| start_time | 2025-10-12 18:00 | time_block_start | Must be ISO-like string. |
| end_time | 2025-10-12 19:00 | time_block_end | — |
| member_tier | AthleteElite | tier | Map from your membership table. |
| booking_type | league | event_type | practice/league/tournament/open_play/etc. |
| proposed_price | 95 | suggested_price | AI's suggested price; can differ from SportsKey price. |
| layout | full | suggested_layout | full/half/third/pod, etc. |
| pod | Pod 2 | suggested_pod | optional |
| predicted_revenue | 100 | predicted_revenue | from AI |
| predicted_utilization | 0.70 | predicted_utilization | 0–1 |
| predicted_impressions | 90 | predicted_sponsor_hits | |
| demand_lead_time_days | 11 | inputs.lead_time_days | stored as JSON in `inputs` |
| historic_util_4w | 0.62 | inputs.historic_util_4w | 0–1 |
| prime | false | inputs.prime | boolean |
| season | fall | inputs.season | string |
| city_policy | standard | inputs.city_policy | string |
| reason_codes | LEAGUE_RATE | reason_codes | JSON list |
| would_do_action | bundle:+1hr | would_do_action | string |
| guardrail_flags | PRICE_FLOOR | guardrail_flags | JSON list |
| actual_revenue | 98 | actual_revenue | optional at export |
| actual_utilization | 0.72 | actual_utilization | optional |
| actual_impressions | 92 | actual_sponsor_hits | optional |

\* *If you want to keep booking_id and suggestion_id separate, the mapper will prefix `SUG-` by default and retain booking_id in `inputs`.*

## B. Reverse Mapping (Shadow Logger → SportsKey Import)

| Shadow Logger Field | SportsKey Import Field | Notes |
|---|---|---|
| suggestion_id | external_ref | for traceability |
| asset_id | resource_id | |
| asset_type | resource_type | |
| time_block_start | start_time | |
| time_block_end | end_time | |
| tier | member_tier | |
| event_type | booking_type | |
| suggested_price | price | rounded to 2 decimals |
| suggested_layout | layout | |
| suggested_pod | pod | optional |
| would_do_action | action_hint | non-binding suggestion |
| guardrail_flags | guardrail_flags | JSON string |

## C. Data Types & Validation
- Times must be strings in `YYYY-MM-DD HH:MM` (24h).
- Numeric rates in [0,1].
- Lists provided as JSON arrays (e.g., `["LT_POS","OFFPEAK_BUMP"]`).

## D. Minimal Required Columns
- **resource_id, resource_type, start_time, end_time, booking_type, member_tier**

## E. Suggested Enrichment from SportsKey
- Customer account id/name for auditing
- Status (booked/penciled/cancelled)
- Payment status

