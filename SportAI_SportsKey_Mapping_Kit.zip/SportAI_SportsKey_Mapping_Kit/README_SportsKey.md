# SportsKey Integration — Quick Start

## Transform SportsKey export → Shadow Logs
```bash
python sportskey_mapper.py export_to_shadow sportskey_export.csv shadow_logs.csv
```
- Use `sportskey_export_sample.csv` as a reference format.
- Adjust column names in `EXPORT_COLS` if your export differs.

## Build SportsKey import file from Shadow Logs
```bash
python sportskey_mapper.py shadow_to_import shadow_logs.csv sportskey_import.csv
```

## Suggested Flow with the Shadow Mode Kit
1. Export recent bookings from SportsKey → CSV.
2. Run `export_to_shadow` → produce `shadow_logs.csv`.
3. Log new AI suggestions using `shadow_logger.py` alongside imported rows.
4. After outcomes, run the Streamlit report to evaluate MAPE/lift.
5. If ready, run `shadow_to_import` to produce `sportskey_import.csv` with pre-approved changes.

— Generated 2025-10-10 14:11:19
