
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import streamlit as st
from .dynamic_pricing_engine import DynamicPricingEngine

# No set_page_config here — main_app controls it.

def _load_guardrails(uploaded_json=None, default_path="modules/pricing/pricing_guardrails.json"):
    if uploaded_json is not None:
        return json.loads(uploaded_json.read().decode("utf-8"))
    try:
        with open(default_path, "r") as f:
            return json.load(f)
    except Exception:
        return {
            "version": "1.0",
            "prime_hours": {"start_hour": 17, "end_hour": 21, "weekend_prime": [8, 20]},
            "floors": {"turf_full": {"prime": 275.0, "offpeak": 165.0},
                       "turf_half": {"prime": 165.0, "offpeak": 95.0},
                       "court_full": {"prime": 85.0, "offpeak": 55.0}},
            "ceilings": {"turf_full": {"prime": 350.0, "offpeak": 225.0},
                         "turf_half": {"prime": 225.0, "offpeak": 145.0},
                         "court_full": {"prime": 125.0, "offpeak": 85.0}},
            "discounts": {"school": 0.85, "youth_nonprofit": 0.88},
            "weather_cap_multiplier": 1.10
        }


def run_dynamic_pricing_tab():
    st.header("Dynamic Pricing — Shadow Mode")
    colA, colB = st.columns(2)
    with colA:
        upl_guard = st.file_uploader("Guardrails JSON (optional)", type=["json"], key="dp_guard")
    with colB:
        weight = st.slider("Adopt model weight (shadow blend)", 0.0, 1.0, 0.25, 0.05)

    guardrails = _load_guardrails(upl_guard)

    upl = st.file_uploader("Upload Requests CSV", type=["csv"], key="dp_csv")
    if upl:
        df = pd.read_csv(upl)
    else:
        try:
            df = pd.read_csv("modules/pricing/sample_requests.csv")
        except Exception:
            st.warning("No sample_requests.csv found. Upload a file to proceed.")
            return

    required_cols = ["request_id","asset","start_dt","duration_hours","lead_time_hours",
                     "org_type","quoted_price","final_price","accepted","event_count_nearby","weather_flag"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        st.error(f"Missing columns: {missing}")
        return

    engine = DynamicPricingEngine(guardrails)
    engine.fit(df)

    recs = []
    for _, row in df.iterrows():
        r = engine.recommend(row)
        blended = (1 - weight) * float(row.get("quoted_price", r.recommended_price)) + weight * r.recommended_price
        recs.append({
            "request_id": row["request_id"],
            "asset": row["asset"],
            "start_dt": row["start_dt"],
            "org_type": row["org_type"],
            "quoted_price": float(row["quoted_price"]),
            "ai_recommended": r.recommended_price,
            "shadow_price": round(blended, 2),
            "ai_multiplier": r.multiplier,
            "ai_confidence": r.confidence,
            "rationale": r.rationale,
            "accepted": int(row.get("accepted", 0)),
        })
    out = pd.DataFrame(recs)

    k1,k2,k3,k4 = st.columns(4)
    k1.metric("Rows", len(out))
    k2.metric("Avg Quoted", f"${out['quoted_price'].mean():.2f}")
    k3.metric("Avg AI", f"${out['ai_recommended'].mean():.2f}")
    k4.metric("Avg Shadow", f"${out['shadow_price'].mean():.2f}")

    st.dataframe(out, use_container_width=True)

    st.subheader("Variance: Quoted vs AI by Asset")
    agg = out.groupby("asset")[["quoted_price","ai_recommended"]].mean().reset_index()
    plt.figure()
    x = np.arange(len(agg))
    plt.plot(x, agg["quoted_price"], marker="o", label="Quoted")
    plt.plot(x, agg["ai_recommended"], marker="o", label="AI")
    plt.xticks(x, agg["asset"], rotation=0)
    plt.title("Average Prices by Asset")
    plt.legend()
    st.pyplot(plt.gcf())

    st.subheader("Multiplier Distribution")
    plt.figure()
    plt.hist(out["ai_multiplier"], bins=20)
    plt.title("AI Multiplier Histogram")
    st.pyplot(plt.gcf())

    st.download_button("Download Recommendations CSV", data=out.to_csv(index=False).encode("utf-8"),
                       file_name="ai_pricing_recommendations.csv", mime="text/csv")


def run_guardrails_editor_tab():
    st.header("Pricing Guardrails Editor")
    upl = st.file_uploader("Upload pricing_guardrails.json (optional)", type=["json"], key="ge_json")
    data = _load_guardrails(upl)

    st.subheader("Prime Hours")
    ph = data.get("prime_hours", {})
    c1, c2, c3 = st.columns(3)
    ph["start_hour"] = c1.number_input("Weekday prime start hour (0-23)", value=int(ph.get("start_hour", 17)), min_value=0, max_value=23)
    ph["end_hour"] = c2.number_input("Weekday prime end hour (0-23)", value=int(ph.get("end_hour", 21)), min_value=0, max_value=23)
    wk = ph.get("weekend_prime", [8, 20])
    wk_start = c3.number_input("Weekend prime start (0-23)", value=int(wk[0]), min_value=0, max_value=23)
    wk_end = c3.number_input("Weekend prime end (0-23)", value=int(wk[1]), min_value=0, max_value=23)
    ph["weekend_prime"] = [int(wk_start), int(wk_end)]
    data["prime_hours"] = ph

    st.subheader("Floors & Ceilings")
    assets = list(set(list(data.get("floors", {}).keys()) + list(data.get("ceilings", {}).keys()) + ["turf_full","turf_half","court_full"]))
    for a in assets:
        st.markdown(f"**{a}**")
        fc1, fc2, fc3, fc4 = st.columns(4)
        floors = data.setdefault("floors", {}).setdefault(a, {"prime":0.0,"offpeak":0.0})
        ceilings = data.setdefault("ceilings", {}).setdefault(a, {"prime":0.0,"offpeak":0.0})
        floors["prime"] = fc1.number_input(f"{a} floor (prime)", value=float(floors.get("prime", 0.0)))
        floors["offpeak"] = fc2.number_input(f"{a} floor (offpeak)", value=float(floors.get("offpeak", 0.0)))
        ceilings["prime"] = fc3.number_input(f"{a} ceiling (prime)", value=float(ceilings.get("prime", 0.0)))
        ceilings["offpeak"] = fc4.number_input(f"{a} ceiling (offpeak)", value=float(ceilings.get("offpeak", 0.0)))

    st.subheader("Discounts & Policies")
    d1, d2, d3 = st.columns(3)
    discounts = data.setdefault("discounts", {})
    discounts["school"] = d1.number_input("School discount multiplier", value=float(discounts.get("school", 0.85)))
    discounts["youth_nonprofit"] = d2.number_input("Youth nonprofit multiplier", value=float(discounts.get("youth_nonprofit", 0.88)))
    data["discounts"] = discounts
    wcap = d3.number_input("Weather cap multiplier (applies to surge)", value=float(data.get("weather_cap_multiplier", 1.10)))
    data["weather_cap_multiplier"] = float(wcap)

    st.subheader("Community Hours")
    ch_enabled = st.checkbox("Enable community hours discount", value=bool(data.get("community_hours", {}).get("enabled", True)))
    ch_disc = st.number_input("Off-peak extra discount (multiplier)", value=float(data.get("community_hours", {}).get("offpeak_extra_discount", 0.90)))
    ch_hours_text = st.text_area("Hours (one per line)", value="\\n".join(data.get("community_hours", {}).get("hours", [])))
    data["community_hours"] = {"enabled": bool(ch_enabled),
                               "offpeak_extra_discount": float(ch_disc),
                               "hours": [h.strip() for h in ch_hours_text.splitlines() if h.strip()]}

    st.download_button("Download pricing_guardrails.json", data=json.dumps(data, indent=2).encode("utf-8"),
                       file_name="pricing_guardrails.json", mime="application/json")


def run_sportskey_mapper_tab():
    st.header("SportsKey → AI Pricing Mapper")
    st.caption("Map columns from your raw SportsKey export to the required schema and download a normalized CSV.")
    REQUIRED_SCHEMA = {
        "request_id": "Unique request identifier",
        "asset": "turf_full | turf_half | court_full",
        "start_dt": "Start datetime (YYYY-mm-dd HH:MM:SS)",
        "duration_hours": "Duration in hours (e.g., 1, 1.5, 2)",
        "lead_time_hours": "Hours between request and start time",
        "org_type": "school | youth_nonprofit | club | individual",
        "quoted_price": "Quoted price",
        "final_price": "Final/accepted price (if any)",
        "accepted": "0 or 1 (accepted?)",
        "event_count_nearby": "Nearby events count (0 if unknown)",
        "weather_flag": "0 or 1 (weather impact if flagged)"
    }

    upl = st.file_uploader("Upload SportsKey CSV", type=["csv"], key="map_csv")
    if not upl:
        st.info("Or use modules/pricing/sample_requests.csv as a reference for column names.")
        return

    df = pd.read_csv(upl)
    st.dataframe(df.head(20), use_container_width=True)

    st.markdown("### Map Columns")
    src_cols = ["<none>"] + list(df.columns)
    mappings = {}
    cols = list(REQUIRED_SCHEMA.keys())
    for c in cols:
        default_index = src_cols.index(c) if c in df.columns else 0
        mappings[c] = st.selectbox(f"{c} — {REQUIRED_SCHEMA[c]}", options=src_cols, index=default_index, key=f"map_{c}")

    asset_norm = st.checkbox("Normalize asset names", value=True)
    org_norm = st.checkbox("Normalize org_type labels", value=True)

    if st.button("Build Clean CSV"):
        out = pd.DataFrame()
        for target, src in mappings.items():
            if src != "<none>" and src in df.columns:
                out[target] = df[src]
            else:
                if target in ["event_count_nearby", "weather_flag", "accepted"]:
                    out[target] = 0
                elif target in ["final_price"]:
                    out[target] = None
                else:
                    out[target] = ""

        if "start_dt" in out.columns:
            out["start_dt"] = pd.to_datetime(out["start_dt"], errors="coerce").dt.strftime("%Y-%m-%d %H:%M:%S")
        if "duration_hours" in out.columns:
            out["duration_hours"] = pd.to_numeric(out["duration_hours"], errors="coerce").fillna(1.0)
        if "lead_time_hours" in out.columns:
            out["lead_time_hours"] = pd.to_numeric(out["lead_time_hours"], errors="coerce").fillna(72.0)

        def norm_asset(x: str) -> str:
            if not isinstance(x, str): return "court_full"
            s = x.strip().lower()
            if "turf" in s and "half" in s: return "turf_half"
            if "turf" in s: return "turf_full"
            if "court" in s or "gym" in s: return "court_full"
            return "court_full"

        def norm_org(x: str) -> str:
            if not isinstance(x, str): return "club"
            s = x.strip().lower()
            if "school" in s or "district" in s: return "school"
            if "youth" in s or "nonprofit" in s or "501" in s: return "youth_nonprofit"
            if "indiv" in s or "walk-in" in s: return "individual"
            return "club"

        if asset_norm:
            out["asset"] = out["asset"].apply(norm_asset)
        if org_norm:
            out["org_type"] = out["org_type"].apply(norm_org)

        for c in ["quoted_price","final_price"]:
            if c in out.columns:
                out[c] = pd.to_numeric(out[c], errors="coerce")

        if "request_id" in out.columns and out["request_id"].isna().any():
            out["request_id"] = out["request_id"].fillna(method="ffill").fillna(method="bfill")
            out["request_id"] = out["request_id"].fillna("REQ")

        st.success("CSV normalized. Download below.")
        st.download_button("Download Clean CSV", data=out.to_csv(index=False).encode("utf-8"),
                           file_name="sportskey_clean_for_pricing.csv", mime="text/csv")
