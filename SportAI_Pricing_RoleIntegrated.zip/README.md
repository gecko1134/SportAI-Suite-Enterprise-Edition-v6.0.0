
# SportAI Pricing Tools — Role Integrated

## Structure
```
/modules/pricing/
  ├─ pricing_suite.py            # run_dynamic_pricing_tab(), run_guardrails_editor_tab(), run_sportskey_mapper_tab()
  ├─ dynamic_pricing_engine.py   # core engine
  ├─ pricing_guardrails.json     # sample guardrails
  └─ sample_requests.csv         # sample data
/shared/
  ├─ roles.py                    # role permission map
  └─ users.json                  # sample users
main_app_pricing_stub.py         # standalone demo with role gate
```

## Quick Start (Demo)
```
pip install streamlit pandas numpy scikit-learn matplotlib
streamlit run main_app_pricing_stub.py
```

## Integrating into your real `main_app.py`
```python
from modules.pricing.pricing_suite import (
    run_dynamic_pricing_tab,
    run_guardrails_editor_tab,
    run_sportskey_mapper_tab,
)
from shared.roles import ROLE_PERMISSIONS

role = st.session_state.get("role", "Member")
if "Pricing Tools" in ROLE_PERMISSIONS.get(role, {}).get("categories", []):
    st.sidebar.header("Pricing Tools")
    tool = st.sidebar.radio("Select tool", ROLE_PERMISSIONS[role]["pricing_tools"])
    if tool == "Dynamic Pricing":
        run_dynamic_pricing_tab()
    elif tool == "Guardrails Editor":
        run_guardrails_editor_tab()
    elif tool == "SportsKey Mapper":
        run_sportskey_mapper_tab()
```

> Replace the demo login with your actual auth. Map your existing roles to `ROLE_PERMISSIONS` as needed.
