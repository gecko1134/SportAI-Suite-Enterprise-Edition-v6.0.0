
"""
Drop-in demo main app with role-based loader that exposes Pricing Tools only to allowed roles.
This file is a *standalone* example. In your real app, integrate the snippet instead.
"""
import json
import streamlit as st
from shared.roles import ROLE_PERMISSIONS
from modules.pricing.pricing_suite import (
    run_dynamic_pricing_tab,
    run_guardrails_editor_tab,
    run_sportskey_mapper_tab,
)

st.set_page_config(page_title="SportAI — Pricing Tools Demo", layout="wide")

st.sidebar.title("SportAI Login (Demo)")
email = st.sidebar.text_input("Email", value="admin@nxscomplex.org")
password = st.sidebar.text_input("Password", value="admin123", type="password")
login = st.sidebar.button("Login")

if login:
    if email == "admin@nxscomplex.org" and password == "admin123":
        st.session_state["role"] = "Admin"
    elif email == "board@nxscomplex.org" and password == "board123":
        st.session_state["role"] = "Board"
    elif email == "analyst@nxscomplex.org" and password == "analyst123":
        st.session_state["role"] = "Analyst"
    elif email == "sponsor@demo.com" and password == "sponsor123":
        st.session_state["role"] = "Sponsor"
    elif email == "member@demo.com" and password == "member123":
        st.session_state["role"] = "Member"
    else:
        st.session_state["role"] = "Member"

role = st.session_state.get("role", "Member")
st.sidebar.success(f"Role: {role}")

# Category routing by role
allowed_categories = ROLE_PERMISSIONS.get(role, {}).get("categories", [])
if "Pricing Tools" not in allowed_categories:
    st.warning("You don't have access to Pricing Tools.")
    st.stop()

st.sidebar.header("Pricing Tools")
allowed_tools = ROLE_PERMISSIONS.get(role, {}).get("pricing_tools", [])
choice = st.sidebar.radio("Select tool", allowed_tools or ["(No tools permitted)"])

if choice == "Dynamic Pricing":
    run_dynamic_pricing_tab()
elif choice == "Guardrails Editor":
    run_guardrails_editor_tab()
elif choice == "SportsKey Mapper":
    run_sportskey_mapper_tab()
else:
    st.info("No tool is permitted for this role.")
