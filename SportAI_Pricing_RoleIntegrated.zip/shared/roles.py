
# Simple role permissions map for SportAI
ROLE_PERMISSIONS = {
    "Admin": {
        "categories": ["Pricing Tools", "Sponsorship Tools", "Ops Tools", "Finance Tools", "Membership Tools"],
        "pricing_tools": ["Dynamic Pricing", "Guardrails Editor", "SportsKey Mapper"]
    },
    "Board": {
        "categories": ["Pricing Tools", "Finance Tools"],
        "pricing_tools": ["Dynamic Pricing", "Guardrails Editor"]
    },
    "Analyst": {
        "categories": ["Pricing Tools", "Finance Tools"],
        "pricing_tools": ["Dynamic Pricing", "SportsKey Mapper", "Guardrails Editor"]
    },
    "Sponsor": {
        "categories": [],
        "pricing_tools": []
    },
    "Member": {
        "categories": [],
        "pricing_tools": []
    }
}
