
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional
import pandas as pd, numpy as np

@dataclass
class FinCastResult:
    forecasts: pd.DataFrame

class FinCastTrainer:
    def __init__(self, config: Dict):
        self.config = config

    def _daily_agg(self, df: pd.DataFrame) -> pd.DataFrame:
        day = df.copy()
        day['date'] = pd.to_datetime(day['date']).dt.date
        agg = {
            'booked_minutes': ('booked_minutes','sum'),
            'revenue': ('revenue','sum'),
            'searches': ('searches','sum'),
            'inquiries': ('inquiries','sum'),
            'waitlist': ('waitlist','sum'),
            'lead_time_days': ('lead_time_days','mean')
        }
        if 'sq_ft' in day.columns:
            agg['sq_ft'] = ('sq_ft','max')
        g = day.groupby(['asset_id','date'], as_index=False).agg(**agg)
        if 'sq_ft' not in g.columns:
            g['sq_ft'] = np.nan
        g['occupancy_pct'] = np.clip(g['booked_minutes'] / (60*16), 0, 1.0)
        g['avg_rate'] = g.apply(lambda r: (r['revenue']/r['booked_minutes'])*60 if r['booked_minutes']>0 else np.nan, axis=1)
        return g

    def _seasonal_baseline(self, df: pd.DataFrame) -> pd.DataFrame:
        d = df.copy()
        d['date'] = pd.to_datetime(d['date'])
        d['dow'] = d['date'].dt.dayofweek
        out = []
        for aid, sub in d.groupby('asset_id'):
            sub = sub.sort_values('date').copy()
            dow_means_occ = sub.groupby('dow')['occupancy_pct'].mean().to_dict()
            dow_means_rate = sub.groupby('dow')['avg_rate'].mean().to_dict()
            sub['occ_ma7'] = sub['occupancy_pct'].rolling(7, min_periods=1).mean()
            sub['rate_ma7'] = sub['avg_rate'].rolling(7, min_periods=1).mean()
            sub['occ_ma28'] = sub['occupancy_pct'].rolling(28, min_periods=1).mean()
            sub['rate_ma28'] = sub['avg_rate'].rolling(28, min_periods=1).mean()
            sub['dow_mean_occ'] = sub['dow'].map(dow_means_occ)
            sub['dow_mean_rate'] = sub['dow'].map(dow_means_rate)
            sub['occ_baseline'] = sub[['occ_ma7','occ_ma28','dow_mean_occ']].mean(axis=1)
            sub['rate_baseline'] = sub[['rate_ma7','rate_ma28','dow_mean_rate']].mean(axis=1)
            out.append(sub)
        return pd.concat(out, ignore_index=True)

    def _apply_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        d = df.copy()
        a_wait = 0.02
        a_inq  = 0.005
        a_lead = -0.01
        d['occ_adj'] = d['occ_baseline'] * (1 + a_wait*d.get('waitlist',0) + a_inq*d.get('inquiries',0) + a_lead*np.nan_to_num(d.get('lead_time_days',0)))
        d['occ_adj'] = np.clip(d['occ_adj'], 0, 1.0)
        d['rate_adj'] = d['rate_baseline'] * (1 + 0.4*(d['occ_adj']-d['occ_baseline']))
        return d

    def forecast(self, history: pd.DataFrame, horizon_days: int = 14, assets: Optional[pd.DataFrame] = None) -> FinCastResult:
        hist = self._daily_agg(history)
        if 'sq_ft' not in hist.columns:
            hist['sq_ft'] = 1000
        hist['sq_ft'] = hist['sq_ft'].fillna(1000)
        base = self._seasonal_baseline(hist)
        base = self._apply_signals(base)

        last_date = pd.to_datetime(base['date']).max().date()
        future_dates = [last_date + pd.Timedelta(days=i) for i in range(1, horizon_days+1)]
        rows = []
        for aid, sub in base.groupby('asset_id'):
            sub = sub.sort_values('date')
            sq_ft = float(sub['sq_ft'].dropna().iloc[-1]) if 'sq_ft' in sub.columns else 1000.0
            dow_occ = sub.groupby(sub['date'].dt.dayofweek)['occ_baseline'].mean().to_dict()
            dow_rate = sub.groupby(sub['date'].dt.dayofweek)['rate_baseline'].mean().to_dict()
            last_signals = sub[['waitlist','inquiries','lead_time_days']].tail(7).mean(numeric_only=True)
            for dte in future_dates:
                dow = pd.to_datetime(dte).dayofweek
                occ_b = dow_occ.get(dow, sub['occ_baseline'].tail(7).mean())
                rate_b = dow_rate.get(dow, sub['rate_baseline'].tail(7).mean())
                occ_adj = np.clip(occ_b * (1 + 0.02*last_signals.get('waitlist',0) + 0.005*last_signals.get('inquiries',0) - 0.01*last_signals.get('lead_time_days',0)), 0, 1.0)
                rate_adj = float(rate_b * (1 + 0.4*(occ_adj - occ_b))) if pd.notna(rate_b) else float(sub['avg_rate'].dropna().tail(7).mean())
                exp_rev = float(occ_adj * 16 * rate_adj)
                ypsf = exp_rev / max(sq_ft,1.0)
                rows.append({'date': pd.to_datetime(dte).date(), 'asset_id': aid,
                             'occupancy_pct': float(occ_adj),
                             'expected_rate': float(rate_adj),
                             'expected_revenue': float(exp_rev),
                             'yield_per_sqft': float(ypsf),
                             'sq_ft': float(sq_ft)})
        fc = pd.DataFrame(rows)
        return FinCastResult(forecasts=fc)
