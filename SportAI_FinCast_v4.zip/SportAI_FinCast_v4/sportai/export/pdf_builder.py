
from __future__ import annotations
import io, datetime as dt
import pandas as pd

def _now_str(): return dt.datetime.now().strftime("%Y-%m-%d %H:%M")
def _html_table(df: pd.DataFrame) -> str:
    head = "<tr>" + "".join(f"<th style='text-align:left;padding:6px;border-bottom:1px solid #ddd'>{c}</th>" for c in df.columns) + "</tr>"
    rows = ["<tr>" + "".join(f"<td style='padding:6px;border-bottom:1px solid #f0f0f0'>{r.get(c,'')}</td>" for c in df.columns) + "</tr>" for _, r in df.iterrows()]
    return "<table style='border-collapse:collapse;width:100%;font-size:12px'>" + head + "".join(rows) + "</table>"
def _as_html_doc(title: str, subtitle: str, body_html: str) -> bytes:
    html = f"<!doctype html><html><head><meta charset='utf-8'><title>{title}</title></head><body style='font-family: Arial, Helvetica, sans-serif; margin:32px'><h1 style='margin:0'>{title}</h1><div style='color:#666;margin-bottom:16px'>{subtitle}</div><div style='font-size:12px;color:#888'>Generated { _now_str() }</div><hr style='margin:16px 0' />{body_html}</body></html>"
    return html.encode('utf-8')

def build_pricing_pdf_bytes(base_rate: float, proposed: float, clamped: float, fair: float, groups, config_meta=None):
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib import colors
        buf = io.BytesIO(); doc = SimpleDocTemplate(buf, pagesize=LETTER); styles=getSampleStyleSheet(); story=[]
        story += [Paragraph("SportAI Pricing Guardrails — Preview", styles["Title"]),
                  Paragraph(config_meta.get("subtitle","") if config_meta else "", styles["Normal"]),
                  Paragraph(f"Generated {_now_str()}", styles["Normal"]), Spacer(1,12)]
        data=[["Step","Rate ($/hr)"],["Base",f"{base_rate:.2f}"],["Proposed",f"{proposed:.2f}"],["Clamp",f"{clamped:.2f}"],["Clamp + Fairness",f"{fair:.2f}"]]
        tbl=Table(data,hAlign="LEFT"); tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("GRID",(0,0),(-1,-1),0.25,colors.grey),("ALIGN",(1,1),(1,-1),"RIGHT")])); story.append(tbl); story.append(Spacer(1,12))
        story.append(Paragraph("Booking Groups: " + (", ".join(groups) if groups else "None"), styles["Normal"]))
        doc.build(story); return buf.getvalue(), "application/pdf"
    except Exception:
        import pandas as pd
        df = pd.DataFrame([{"step":"Base","rate":base_rate},{"step":"Proposed","rate":proposed},{"step":"Clamp","rate":clamped},{"step":"Clamp + Fairness","rate":fair}])
        body = f"<p><b>Groups:</b> {( ', '.join(groups) if groups else 'None')}</p>" + _html_table(df)
        return _as_html_doc("SportAI Pricing Guardrails — Preview", config_meta.get("subtitle","") if config_meta else "", body), "text/html"

def build_sponsor_packet_pdf_bytes(ztable: pd.DataFrame, assumptions):
    title="Sponsor Zone — Impressions Forecast"; subtitle=f"Assumptions: {assumptions}"
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib import colors
        buf = io.BytesIO(); doc = SimpleDocTemplate(buf, pagesize=LETTER); styles=getSampleStyleSheet(); story=[]
        story += [Paragraph(title, styles["Title"]), Paragraph(subtitle, styles["Normal"]), Paragraph(f"Generated {_now_str()}", styles["Normal"]), Spacer(1,12)]
        cols=list(ztable.columns); data=[cols]+[[str(v) for v in row] for row in ztable.to_records(index=False)]
        tbl=Table(data,hAlign="LEFT"); tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("GRID",(0,0),(-1,-1),0.25,colors.grey)])); story.append(tbl); doc.build(story)
        return buf.getvalue(), "application/pdf"
    except Exception:
        return _as_html_doc(title, subtitle, _html_table(ztable)), "text/html"
