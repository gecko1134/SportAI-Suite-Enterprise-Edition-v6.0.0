
from __future__ import annotations
from typing import Dict
import json
from pathlib import Path
from sportai.pricing.guardrails import clamp, apply_fairness

def recommend_rate(base_rate: float, proposed_rate: float, hour: int, booking_ctx: Dict, config_path: str, schema_path: str = None) -> float:
    cfg = json.loads(Path(config_path).read_text())
    controls = cfg['controls']
    r = clamp(proposed_rate, base_rate, controls['price_floor'], controls['price_ceiling'])
    r = apply_fairness(r, base_rate, hour, booking_ctx, controls['fairness_rules'])
    return round(float(r), 2)
