
from __future__ import annotations
import pandas as pd, numpy as np

def _ts(s): return pd.to_datetime(s, errors='coerce')

def from_bookings_csv(path, asset_id_col='resource_id', start_col='start_time', end_col='end_time', price_col='price', created_col='created_at', sq_ft_map=None) -> pd.DataFrame:
    df = pd.read_csv(path)
    for c in [asset_id_col, start_col, end_col]:
        if c not in df.columns: raise ValueError(f"Missing required column: {c}")
    df[start_col] = _ts(df[start_col]); df[end_col] = _ts(df[end_col])
    if created_col in df.columns: df[created_col] = _ts(df[created_col])
    else: df[created_col] = df[start_col]
    df['duration_min'] = (df[end_col]-df[start_col]).dt.total_seconds()/60.0
    df['asset_id'] = df[asset_id_col].astype(str)
    df['date'] = df[start_col].dt.date
    df['revenue'] = pd.to_numeric(df.get(price_col,0), errors='coerce').fillna(0.0)
    df['searches'] = pd.to_numeric(df.get('searches',0), errors='coerce').fillna(0).astype(int)
    df['inquiries'] = pd.to_numeric(df.get('inquiries',0), errors='coerce').fillna(0).astype(int)
    df['waitlist'] = pd.to_numeric(df.get('waitlist',0), errors='coerce').fillna(0).astype(int)
    df['lead_time_days'] = ((df[start_col]-df[created_col]).dt.total_seconds()/(3600*24.0)).clip(lower=0).fillna(0.0)
    out = df.groupby(['asset_id','date'], as_index=False).agg(
        booked_minutes=('duration_min','sum'),
        revenue=('revenue','sum'),
        searches=('searches','sum'),
        inquiries=('inquiries','sum'),
        waitlist=('waitlist','sum'),
        lead_time_days=('lead_time_days','mean')
    )
    out['sq_ft'] = out['asset_id'].map(sq_ft_map).astype(float) if sq_ft_map else np.nan
    cols = ['date','asset_id','booked_minutes','revenue','searches','inquiries','waitlist','lead_time_days','sq_ft']
    return out[cols]
