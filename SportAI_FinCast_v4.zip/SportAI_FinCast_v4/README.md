
# SportAI FinCast v4

Includes:
- JSON Schema + Sample Config
- Validator + Pricing Guardrails + Integration Helper
- FinCastTrainer (baseline) with 14-day forecast
- SportsKey CSV Ingest Adapter
- HVAC Setpoint Planner (what-if overrides)
- Sponsor Zones config + What-If logic
- Streamlit Dashboard (KPIs, Sponsor Zones, Ingest & HVAC, Pricing Guardrails + PDF/HTML exports)
- Notebook demo
- Tests
- Sample data and demos

## Quickstart
```bash
cd SportAI_FinCast_v4
python -m pip install -e .
pytest -q
python demo_fincast_run.py
python demo_hvac_run.py

# Dashboard
cd dashboard
streamlit run app.py
```
