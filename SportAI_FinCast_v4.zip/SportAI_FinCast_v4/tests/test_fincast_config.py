
import json
from pathlib import Path
from sportai.fincast.validator import validate_config, load_json
from sportai.pricing.guardrails import clamp, apply_fairness

BASE = Path(__file__).resolve().parents[1]

def test_schema_accepts_sample():
    schema = load_json(BASE / 'fincast_config.schema.json')
    cfg = load_json(BASE / 'sample_fincast_config.json')
    errors = validate_config(cfg, schema)
    assert errors == []

def test_price_clamp_absolute_and_percent():
    base = 100.0
    clamped = clamp(200.0, base, {"type":"absolute","value":80}, {"type":"percent_of_base","value":1.5})
    assert clamped == 150.0
    clamped2 = clamp(50.0, base, {"type":"absolute","value":80}, {"type":"percent_of_base","value":1.5})
    assert clamped2 == 80.0

def test_fairness_youth_nonprime_cap():
    base = 100.0
    rate = 140.0
    hour = 9
    booking_ctx = {"groups":["youth"]}
    fairness = load_json(BASE / 'sample_fincast_config.json')["controls"]["fairness_rules"]
    adjusted = apply_fairness(rate, base, hour, booking_ctx, fairness)
    assert adjusted <= base * 0.9 + 1e-9
