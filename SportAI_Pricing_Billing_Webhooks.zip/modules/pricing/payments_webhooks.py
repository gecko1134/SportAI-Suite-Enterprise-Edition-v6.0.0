
import os, json, time
from typing import Dict, Any
from fastapi import FastAPI, Request, Header, HTTPException
import pandas as pd

LEDGER_PATH = "modules/pricing/payments_ledger.csv"
os.makedirs("modules/pricing", exist_ok=True)

app = FastAPI(title="SportAI Billing Webhooks")

def _append_ledger(row: Dict[str, Any]):
    df = pd.DataFrame([row])
    if os.path.exists(LEDGER_PATH):
        df.to_csv(LEDGER_PATH, mode="a", header=False, index=False)
    else:
        df.to_csv(LEDGER_PATH, mode="w", header=True, index=False)

def _base_row() -> Dict[str, Any]:
    return {
        "ts": int(time.time()),
        "event_source": "",
        "event_type": "",
        "invoice_no": "",
        "org_name": "",
        "email": "",
        "amount": 0.0,
        "currency": "USD",
        "status": "paid",
        "transaction_id": "",
        "meta": "{}"
    }

@app.post("/webhook/stripe")
async def stripe_webhook(request: Request, stripe_signature: str = Header(default="")):
    body = await request.body()
    try:
        event = json.loads(body.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    data = event.get("data", {}).get("object", {})
    row = _base_row()
    row["event_source"] = "stripe"
    row["event_type"] = event.get("type", "")
    row["invoice_no"] = data.get("metadata", {}).get("invoice_no", data.get("id",""))
    row["org_name"] = data.get("metadata", {}).get("org_name","")
    row["email"] = data.get("receipt_email", data.get("customer_email",""))
    row["amount"] = float(data.get("amount", 0))/100.0 if "amount" in data else float(data.get("amount_paid",0))/100.0
    row["currency"] = data.get("currency","USD").upper()
    row["status"] = data.get("status", "paid")
    row["transaction_id"] = data.get("id","")
    row["meta"] = json.dumps(data)
    _append_ledger(row)
    return {"ok": True}

@app.post("/webhook/quickbooks")
async def quickbooks_webhook(request: Request):
    body = await request.body()
    try:
        event = json.loads(body.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    data = event.get("invoice", event)
    row = _base_row()
    row["event_source"] = "quickbooks"
    row["event_type"] = event.get("eventNotifications", [{}])[0].get("eventId","qb_event")
    row["invoice_no"] = str(data.get("DocNumber", data.get("Id","")))
    row["org_name"] = data.get("CustomerRef", {}).get("name","")
    row["email"] = data.get("BillEmail", {}).get("Address","")
    row["amount"] = float(data.get("TotalAmt", 0))
    row["currency"] = data.get("CurrencyRef", {}).get("value","USD").upper()
    row["status"] = data.get("Balance",0) == 0 and "paid" or "open"
    row["transaction_id"] = str(data.get("Id",""))
    row["meta"] = json.dumps(data)
    _append_ledger(row)
    return {"ok": True}
