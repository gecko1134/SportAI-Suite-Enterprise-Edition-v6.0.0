
import os, json
from typing import Dict, Any, List, Tuple
import pandas as pd
from datetime import datetime

LEDGER_PATH = "modules/pricing/payments_ledger.csv"

def ensure_ledger():
    if not os.path.exists(LEDGER_PATH):
        cols = ["ts","event_source","event_type","invoice_no","org_name","email","amount","currency","status","transaction_id","meta"]
        pd.DataFrame(columns=cols).to_csv(LEDGER_PATH, index=False)

def load_ledger() -> pd.DataFrame:
    ensure_ledger()
    df = pd.read_csv(LEDGER_PATH)
    return df

def save_ledger(df: pd.DataFrame) -> None:
    df.to_csv(LEDGER_PATH, index=False)

def mark_invoice_status(invoice_no: str, status: str) -> bool:
    df = load_ledger()
    if "invoice_no" not in df.columns or df.empty:
        return False
    mask = df["invoice_no"] == invoice_no
    if not mask.any():
        return False
    df.loc[mask, "status"] = status
    save_ledger(df)
    return True

def ar_aging(df: pd.DataFrame, as_of: datetime = None) -> Dict[str, float]:
    from datetime import datetime as dt
    if as_of is None:
        as_of = dt.utcnow()
    if df.empty:
        return {"current":0.0,"1-30":0.0,"31-60":0.0,"61-90":0.0,"90+":0.0}
    df = df.copy()
    df["ts"] = pd.to_datetime(df["ts"], unit="s", errors="coerce")
    df["days"] = (as_of - df["ts"]).dt.days
    open_df = df[df["status"].str.lower().isin(["open","unpaid","partial"])]
    buckets = {"current":0.0,"1-30":0.0,"31-60":0.0,"61-90":0.0,"90+":0.0}
    for _, r in open_df.iterrows():
        amt = float(r.get("amount",0))
        d = int(r.get("days",0))
        if d <= 0: buckets["current"] += amt
        elif d <= 30: buckets["1-30"] += amt
        elif d <= 60: buckets["31-60"] += amt
        elif d <= 90: buckets["61-90"] += amt
        else: buckets["90+"] += amt
    return buckets

def totals(df: pd.DataFrame) -> Dict[str, float]:
    t_paid = float(df[df["status"].str.lower()=="paid"]["amount"].sum()) if not df.empty else 0.0
    t_open = float(df[df["status"].str.lower().isin(["open","unpaid","partial"])]["amount"].sum()) if not df.empty else 0.0
    return {"paid": t_paid, "open": t_open, "grand_total": float(df["amount"].sum()) if not df.empty else 0.0}
