
# SportAI Billing — Webhooks + Payments Dashboard

## Components
- `modules/pricing/payments_webhooks.py` — FastAPI app for Stripe/QuickBooks webhooks → ledger CSV
- `modules/pricing/payments_ledger.py` — helpers for ledger + aging
- `modules/pricing/pricing_suite_billing.py` — `run_payments_dashboard_tab()` Streamlit UI
- `templates/email/payment_receipt.html` — receipt

## Webhooks
```bash
pip install fastapi uvicorn pandas
uvicorn modules.pricing.payments_webhooks:app --host 0.0.0.0 --port 8080
```
Implement real signature verification for production.

## Dashboard wiring
```python
from modules.pricing.pricing_suite_billing import run_payments_dashboard_tab

if category == "Pricing Tools":
    tool = st.sidebar.radio("Pricing Tools", [
        "Dynamic Pricing", "Quote Emailer", "Deal Summary", "Live Requests",
        "Invoice Generator", "Auto-Renewal Alerts", "Payments Dashboard"
    ])
    if tool == "Payments Dashboard":
        run_payments_dashboard_tab()
```
