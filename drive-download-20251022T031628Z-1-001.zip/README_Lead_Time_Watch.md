# Lead-Time Watch (SportAI)
- sportai_lead_time_config.json
- lead_time_pricing.py
- lead_time_watch_tab.py
- sportskey_export_sample.csv

## CLI
python lead_time_pricing.py --csv sportskey_export_sample.csv --config sportai_lead_time_config.json --out ./out
