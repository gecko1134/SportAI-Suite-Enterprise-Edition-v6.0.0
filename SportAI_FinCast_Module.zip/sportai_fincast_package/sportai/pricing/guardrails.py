
from typing import Optional, Dict

def clamp(value: float, base_rate: float, floor_cfg: Dict, ceil_cfg: Dict) -> float:
    def to_abs(cfg):
        t = cfg.get('type')
        v = cfg.get('value', 0)
        if t == 'absolute':
            return v
        elif t == 'percent_of_base':
            return base_rate * v
        else:
            raise ValueError('unknown clamp type')
    floor_abs = to_abs(floor_cfg)
    ceil_abs = to_abs(ceil_cfg)
    if floor_abs > ceil_abs:
        # swap to be safe
        floor_abs, ceil_abs = ceil_abs, floor_abs
    return max(floor_abs, min(value, ceil_abs))

def apply_fairness(adjusted_rate: float, base_rate: float, hour: int, booking_ctx: Dict, fairness_cfg: Dict) -> float:
    # youth non-prime cap
    ycap = fairness_cfg.get('youth_nonprime_cap', {})
    groups = booking_ctx.get('groups', [])
    is_youth = 'youth' in groups or 'schools_k12' in groups
    if is_youth and hour in set(ycap.get('nonprime_hours', [])):
        cap_type = ycap.get('cap_type')
        cap_value = ycap.get('cap_value', 1.0)
        if cap_type == 'absolute':
            adjusted_rate = min(adjusted_rate, cap_value)
        elif cap_type == 'percent_of_base':
            adjusted_rate = min(adjusted_rate, base_rate * cap_value)

    # community access discounts
    comm = fairness_cfg.get('community_access', {})
    eligible = set(comm.get('eligible_groups', []))
    if eligible.intersection(set(groups)):
        for window in comm.get('hour_windows', []):
            if window['start'] <= hour <= window['end']:
                if comm.get('discount_type') == 'absolute':
                    adjusted_rate = max(0.0, adjusted_rate - comm.get('discount_value', 0))
                elif comm.get('discount_type') == 'percent_of_base':
                    adjusted_rate = max(0.0, adjusted_rate - base_rate * comm.get('discount_value', 0))
                break

    # ADA exemptions: never price above base for disabled-athletes
    ada = fairness_cfg.get('ada_exemptions', {})
    if ada.get('apply') and 'disabled_athletes' in groups:
        adjusted_rate = min(adjusted_rate, base_rate)

    return adjusted_rate
