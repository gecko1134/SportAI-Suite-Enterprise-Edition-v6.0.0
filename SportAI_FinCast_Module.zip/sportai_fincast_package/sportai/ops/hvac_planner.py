
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict
import pandas as pd
import numpy as np

@dataclass
class HVACPlan:
    schedule: pd.DataFrame  # columns: date, hour, asset_id, mode, setpoint_shift, note

def _hourly_profile_for_court():
    # simple 24h profile (relative weights) for courts
    # low mornings, peak evenings
    w = np.array([0.02,0.02,0.02,0.02,0.03,0.04,0.05,0.06,0.06,0.06,0.05,0.05,
                  0.05,0.05,0.06,0.08,0.10,0.11,0.11,0.09,0.05,0.03,0.02,0.02])
    return w / w.sum()

def expand_daily_to_hourly(fc_daily: pd.DataFrame) -> pd.DataFrame:
    prof = _hourly_profile_for_court()
    rows = []
    for _, r in fc_daily.iterrows():
        for h in range(24):
            occ_h = float(r['occupancy_pct']) * prof[h] * 24  # scale to daily occ
            rows.append({
                'date': r['date'],
                'asset_id': r['asset_id'],
                'hour': h,
                'occ_hourly': np.clip(occ_h, 0.0, 1.0),
                'expected_rate': r.get('expected_rate', np.nan),
                'sq_ft': r.get('sq_ft', np.nan)
            })
    return pd.DataFrame(rows)

def build_hvac_plan(forecast_daily: pd.DataFrame, hvac_cfg: Dict, occ_threshold: float = 0.15) -> HVACPlan:
    """
    Convert daily forecasts to an hourly HVAC schedule:
      - hours with occ_hourly >= threshold => 'occupied'
      - precondition N hours before first occupied block per day (per asset)
      - all other hours => 'idle' with idle_setpoint_shift degrees
    hvac_cfg: {'idle_setpoint_shift': number, 'precondition_hours': number}
    """
    hourly = expand_daily_to_hourly(forecast_daily)
    plans = []
    for (asset, date), sub in hourly.groupby(['asset_id','date']):
        sub = sub.sort_values('hour').copy()
        sub['mode'] = np.where(sub['occ_hourly'] >= occ_threshold, 'occupied', 'idle')
        # precondition before first occupied hour, if any
        occ_hours = sub.loc[sub['mode']=='occupied','hour'].tolist()
        if occ_hours:
            start = min(occ_hours)
            pre_h = int(hvac_cfg.get('precondition_hours', 1))
            for h in range(max(0, start - pre_h), start):
                sub.loc[sub['hour']==h, 'mode'] = 'precondition'
        sub['setpoint_shift'] = 0.0
        sub.loc[sub['mode']=='idle', 'setpoint_shift'] = float(hvac_cfg.get('idle_setpoint_shift', 0))
        sub.loc[sub['mode']=='precondition', 'setpoint_shift'] = max(float(hvac_cfg.get('idle_setpoint_shift', 0)) - 1.0, 0.0)
        sub['note'] = ''
        sub.loc[sub['mode']=='precondition', 'note'] = 'Precondition before occupancy'
        plans.append(sub[['date','hour','asset_id','mode','setpoint_shift','note']])
    plan_df = pd.concat(plans, ignore_index=True)
    return HVACPlan(schedule=plan_df)
