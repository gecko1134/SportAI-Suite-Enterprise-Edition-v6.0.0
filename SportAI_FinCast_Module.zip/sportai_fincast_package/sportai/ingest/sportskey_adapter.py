
from __future__ import annotations
import pandas as pd
import numpy as np

def _ensure_dt(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, errors='coerce')

def from_bookings_csv(path: str, asset_id_col='resource_id', start_col='start_time', end_col='end_time',
                      price_col='price', created_col='created_at', sq_ft_map: dict | None = None) -> pd.DataFrame:
    """
    Convert a SportsKey bookings export CSV into SportAI daily history format.
    Returns DataFrame with columns:
      date, asset_id, booked_minutes, revenue, searches, inquiries, waitlist, lead_time_days, sq_ft
    Unknown signals default to 0; lead_time uses created_at if present.
    """
    df = pd.read_csv(path)
    for c in [asset_id_col, start_col, end_col]:
        if c not in df.columns:
            raise ValueError(f"Missing required column: {c}")
    df[start_col] = _ensure_dt(df[start_col])
    df[end_col] = _ensure_dt(df[end_col])
    if created_col in df.columns:
        df[created_col] = _ensure_dt(df[created_col])
    else:
        df[created_col] = df[start_col]

    df['duration_min'] = (df[end_col] - df[start_col]).dt.total_seconds() / 60.0
    df['date'] = df[start_col].dt.date
    df['asset_id'] = df[asset_id_col].astype(str)
    df['revenue'] = pd.to_numeric(df.get(price_col, 0), errors='coerce').fillna(0.0)

    # lead time in days
    lt_days = (df[start_col] - df[created_col]).dt.total_seconds() / (3600*24.0)
    df['lead_time_days'] = np.clip(lt_days, 0, None).fillna(0.0)

    # Aggregate to daily
    g = df.groupby(['asset_id','date'], as_index=False).agg(
        booked_minutes=('duration_min','sum'),
        revenue=('revenue','sum')
    )

    # Optional sq_ft mapping
    if sq_ft_map:
        g['sq_ft'] = g['asset_id'].map(sq_ft_map).astype(float)
    else:
        g['sq_ft'] = np.nan

    # Placeholder demand signals
    g['searches'] = 0
    g['inquiries'] = 0
    g['waitlist'] = 0

    cols = ['date','asset_id','booked_minutes','revenue','searches','inquiries','waitlist','lead_time_days','sq_ft']
    # Merge lead_time_days (avg) from original df
    lt = df.groupby(['asset_id','date'], as_index=False)['lead_time_days'].mean()
    out = g.merge(lt, on=['asset_id','date'], how='left')
    return out[cols]
