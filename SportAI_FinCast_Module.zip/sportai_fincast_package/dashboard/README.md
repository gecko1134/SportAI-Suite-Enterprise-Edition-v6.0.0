
# FinCast Dashboard (Streamlit)

## Run
```bash
cd dashboard
streamlit run app.py
```
- The app reads `../forecast_14d.csv`. Run the notebook or demo to generate it first.
- Edit `../sponsor_zones.json` to change zone mapping and impression factors.
