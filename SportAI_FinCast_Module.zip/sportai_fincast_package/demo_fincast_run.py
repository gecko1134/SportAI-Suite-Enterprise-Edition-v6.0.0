
import json
import pandas as pd
from pathlib import Path
from sportai.fincast.trainer import FinCastTrainer
from sportai.fincast.validator import load_json, validate_config
from sportai.pricing.integration_example import recommend_rate

BASE = Path(__file__).resolve().parent
cfg_path = BASE / 'sample_fincast_config.json'
schema_path = BASE / 'fincast_config.schema.json'

def main():
    # Validate config
    schema = load_json(schema_path)
    cfg = load_json(cfg_path)
    errors = validate_config(cfg, schema)
    assert not errors, f'Config invalid: {errors}'

    # Load sample data
    assets = pd.read_csv(BASE / 'sample_data' / 'assets.csv')
    history = pd.read_csv(BASE / 'sample_data' / 'history.csv')

    # Train & forecast
    trainer = FinCastTrainer(cfg)
    res = trainer.forecast(history, horizon_days=14, assets=assets)
    fc = res.forecasts.sort_values(['date','yield_per_sqft'], ascending=[True, False]).copy()

    # Pricing example for a specific booking
    example = fc.iloc[0]
    base_rate = max(80.0, example['expected_rate'])  # assume base is forecasted expected rate
    proposed = example['expected_rate'] * 1.25       # surge 25% from model
    hour = 10  # late morning
    booking_ctx = {"groups": ["schools_k12"]}
    rec = recommend_rate(base_rate, proposed, hour, booking_ctx, str(cfg_path))

    # Save outputs
    out_fc = BASE / 'forecast_14d.csv'
    fc.to_csv(out_fc, index=False)

    print('Forecast saved to:', out_fc)
    print('\nSample top row:')
    print(example.to_dict())
    print('\nPricing recommendation:')
    print({'base_rate': round(float(base_rate),2), 'proposed': round(float(proposed),2), 'recommended': rec})

if __name__ == '__main__':
    main()
