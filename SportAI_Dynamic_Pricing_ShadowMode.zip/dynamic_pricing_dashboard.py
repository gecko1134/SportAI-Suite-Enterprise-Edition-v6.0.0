
import json
import io
from datetime import datetime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import streamlit as st

from dynamic_pricing_engine import DynamicPricingEngine

st.set_page_config(page_title="SportAI Dynamic Pricing (Shadow Mode)", layout="wide")

st.title("SportAI Dynamic Pricing — Shadow Mode")
st.caption("Scores each booking request with AI multipliers, applies guardrails, and compares vs. current quotes.")

# Sidebar controls
with st.sidebar:
    st.header("Configuration")
    guardrail_file = st.file_uploader("Guardrails JSON", type=["json"])
    if guardrail_file:
        guardrails = json.loads(guardrail_file.read().decode("utf-8"))
    else:
        with open("pricing_guardrails.json","r") as f:
            guardrails = json.load(f)
    st.success("Guardrails loaded.")

    st.markdown("---")
    st.subheader("Model Options")
    weight = st.slider("Adopt model weight (shadow only)", 0.0, 1.0, 0.25, 0.05)

st.markdown("### Upload SportsKey history or use sample data")
upl = st.file_uploader("Upload CSV", type=["csv"])
if upl:
    df = pd.read_csv(upl)
else:
    df = pd.read_csv("sample_requests.csv")

# Ensure required columns exist
required_cols = ["request_id","asset","start_dt","duration_hours","lead_time_hours","org_type","quoted_price","final_price","accepted","event_count_nearby","weather_flag"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    st.error(f"Missing columns: {missing}")
    st.stop()

# Fit model
engine = DynamicPricingEngine(guardrails)
engine.fit(df)

# Score rows
records = []
for _, row in df.iterrows():
    rec = engine.recommend(row)
    # Shadow mode blend
    blended = (1 - weight) * float(row.get("quoted_price", rec.recommended_price)) + weight * rec.recommended_price
    records.append({
        "request_id": row["request_id"],
        "asset": row["asset"],
        "start_dt": row["start_dt"],
        "org_type": row["org_type"],
        "quoted_price": float(row["quoted_price"]),
        "ai_recommended": rec.recommended_price,
        "shadow_price": round(blended, 2),
        "ai_multiplier": rec.multiplier,
        "ai_confidence": rec.confidence,
        "rationale": rec.rationale,
        "accepted": int(row.get("accepted", 0)),
    })

out = pd.DataFrame(records)

# Summary KPIs
col1, col2, col3, col4 = st.columns(4)
col1.metric("Rows Scored", len(out))
col2.metric("Avg Quoted", f"${out['quoted_price'].mean():.2f}")
col3.metric("Avg AI Price", f"${out['ai_recommended'].mean():.2f}")
col4.metric("Avg Shadow", f"${out['shadow_price'].mean():.2f}")

# Table
st.markdown("### Scored Recommendations")
st.dataframe(out, use_container_width=True)

# Charts (matplotlib, single plot per fig, no explicit colors)
st.markdown("### Variance: Quoted vs AI by Asset")
agg = out.groupby("asset")[["quoted_price","ai_recommended"]].mean().reset_index()
plt.figure()
x = np.arange(len(agg))
plt.plot(x, agg["quoted_price"], marker="o", label="Quoted")
plt.plot(x, agg["ai_recommended"], marker="o", label="AI")
plt.xticks(x, agg["asset"], rotation=0)
plt.title("Average Prices by Asset")
plt.legend()
st.pyplot(plt.gcf())

st.markdown("### Multiplier Distribution")
plt.figure()
plt.hist(out["ai_multiplier"], bins=20)
plt.title("AI Multiplier Histogram")
st.pyplot(plt.gcf())

# Export
st.markdown("### Export")
csv_bytes = out.to_csv(index=False).encode("utf-8")
st.download_button("Download Recommendations CSV", data=csv_bytes, file_name="ai_pricing_recommendations.csv", mime="text/csv")

st.success("Shadow-mode scoring complete. You can safely compare prices before enabling live writes.")
