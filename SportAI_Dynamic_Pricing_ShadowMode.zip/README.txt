
SportAI Dynamic Pricing — Shadow Mode
=====================================

Files
-----
- dynamic_pricing_dashboard.py  (Streamlit UI)
- dynamic_pricing_engine.py     (Core engine: features, model, guardrails)
- pricing_guardrails.json       (Editable floors/ceilings, discounts, policies)
- sample_requests.csv           (Synthetic data to demo without SportsKey export)

How to run
----------
1) Ensure Python 3.9+ and `pip install streamlit pandas numpy scikit-learn matplotlib`.
2) From this folder, run:
      streamlit run dynamic_pricing_dashboard.py
3) In the app, either upload your SportsKey CSV or use the included sample.
4) Adjust the shadow-mode weight slider to compare your quoted prices vs AI.
5) Download the recommendations CSV for your internal review.

Inputs expected (CSV)
---------------------
request_id, asset (turf_full|turf_half|court_full), start_dt (YYYY-mm-dd HH:MM:SS),
duration_hours, lead_time_hours, org_type (school|youth_nonprofit|club|individual),
quoted_price, final_price, accepted (0/1), event_count_nearby (int), weather_flag (0/1)

Guardrails
----------
- Prime/off-peak floors & ceilings per asset
- Weather surge cap
- School/Youth Nonprofit discounts
- Community hours optional off-peak discount

Notes
-----
- If scikit-learn is unavailable, the engine falls back to a robust mean-by-prime model.
- This bundle runs fully offline using the sample CSV.
