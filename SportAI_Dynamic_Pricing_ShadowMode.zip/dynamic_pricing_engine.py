
import json
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Any, Tuple
import numpy as np
import pandas as pd

try:
    # Light dependency footprint; fall back to linear if sklearn missing
    from sklearn.linear_model import HuberRegressor
    SKLEARN_AVAILABLE = True
except Exception:
    SKLEARN_AVAILABLE = False


@dataclass
class PricingOutput:
    recommended_price: float
    multiplier: float
    confidence: float
    rationale: str
    floor_applied: float
    ceiling_applied: float


class DynamicPricingEngine:
    def __init__(self, guardrails: Dict[str, Any]):
        self.guardrails = guardrails
        self.model = None
        self.feature_cols = [
            "hour_of_week",
            "is_prime",
            "lead_time_hours",
            "duration_hours",
            "season_index",
            "event_cluster_index",
            "weather_flag",
            "org_type_school",
            "org_type_youth_nonprofit",
            "org_type_club",
            "org_type_individual",
        ]

    @staticmethod
    def _is_prime(dt: datetime, guardrails: Dict[str, Any]) -> int:
        start = guardrails.get("prime_hours", {}).get("start_hour", 17)
        end = guardrails.get("prime_hours", {}).get("end_hour", 21)
        weekend_prime = guardrails.get("prime_hours", {}).get("weekend_prime", [8, 20])
        if dt.weekday() >= 5:  # Sat/Sun
            return int(weekend_prime[0] <= dt.hour <= weekend_prime[1])
        return int(start <= dt.hour <= end)

    @staticmethod
    def _season_index(dt: datetime) -> float:
        # Simple sine wave seasonality (peaks mid-winter)
        day_of_year = dt.timetuple().tm_yday
        return 0.5 + 0.5 * np.sin(2 * np.pi * (day_of_year - 15) / 365.0)

    @staticmethod
    def _hour_of_week(dt: datetime) -> int:
        return dt.weekday() * 24 + dt.hour

    @staticmethod
    def _one_hot_org(org_type: str) -> Dict[str, int]:
        org_type = (str(org_type) or "").strip().lower()
        keys = ["school", "youth_nonprofit", "club", "individual"]
        out = {f"org_type_{k}": 0 for k in keys}
        if org_type in keys:
            out[f"org_type_{org_type}"] = 1
        return out

    @staticmethod
    def _asset_key(asset: str) -> str:
        # Normalize common asset labels
        if not isinstance(asset, str):
            return "court_full"
        a = asset.strip().lower()
        if "half" in a and "turf" in a:
            return "turf_half"
        if "turf" in a:
            return "turf_full"
        return "court_full"

    def build_features(self, df: pd.DataFrame) -> pd.DataFrame:
        # Expect columns: start_dt, duration_hours, lead_time_hours, org_type, event_count_nearby, weather_flag, asset
        out = df.copy()

        # parse start_dt
        out["start_dt"] = pd.to_datetime(out["start_dt"])

        out["is_prime"] = out["start_dt"].apply(lambda x: self._is_prime(x, self.guardrails))
        out["season_index"] = out["start_dt"].apply(self._season_index)
        out["hour_of_week"] = out["start_dt"].apply(self._hour_of_week)
        out["event_cluster_index"] = out.get("event_count_nearby", 0)
        out["weather_flag"] = out.get("weather_flag", 0).astype(int)

        # durations / lead time
        out["duration_hours"] = pd.to_numeric(out.get("duration_hours", 1.0), errors="coerce").fillna(1.0)
        out["lead_time_hours"] = pd.to_numeric(out.get("lead_time_hours", 72.0), errors="coerce").fillna(72.0)

        # org one-hot
        ohe = out["org_type"].apply(self._one_hot_org).apply(pd.Series)
        for col in ["org_type_school", "org_type_youth_nonprofit", "org_type_club", "org_type_individual"]:
            if col not in ohe.columns:
                ohe[col] = 0
        out = pd.concat([out, ohe], axis=1)

        # asset normalized
        out["asset_key"] = out["asset"].apply(self._asset_key)

        return out

    def fit(self, df: pd.DataFrame) -> None:
        # Train on accepted rows only if present; else on all
        train = df.copy()
        if "accepted" in train.columns and train["accepted"].dropna().isin([0,1]).any():
            acc = train[train["accepted"] == 1]
            if len(acc) >= 20:
                train = acc

        feats = self.build_features(train)
        X = feats[self.feature_cols].values
        # Target is multiplier vs. quoted_price if present, else absolute price vs typical floor
        if "quoted_price" in feats.columns and feats["quoted_price"].fillna(0).gt(0).any():
            y = (feats["final_price"].fillna(feats["quoted_price"]) / feats["quoted_price"]).clip(0.5, 1.5)
        else:
            # fallback target around 1.0 with slight adjustments
            y = 0.95 + 0.1 * np.random.randn(len(feats))

        if SKLEARN_AVAILABLE:
            model = HuberRegressor()
            model.fit(X, y)
            self.model = model
        else:
            # simple fallback: store means by (is_prime, org buckets)
            feats["y"] = y
            self.model = feats.groupby(["is_prime"]).agg({"y": "mean"}).to_dict()["y"]

    def predict_multiplier(self, row: pd.Series) -> Tuple[float, float, str]:
        feats = self.build_features(pd.DataFrame([row]))
        X = feats[self.feature_cols].values

        rationale_bits = []
        if feats.loc[0, "is_prime"] == 1:
            rationale_bits.append("prime hour")
        if feats.loc[0, "event_cluster_index"] > 0:
            rationale_bits.append("nearby events")
        if feats.loc[0, "lead_time_hours"] < 24:
            rationale_bits.append("last-minute")
        if feats.loc[0, "org_type_school"] == 1:
            rationale_bits.append("school policy")
        if feats.loc[0, "weather_flag"] == 1:
            rationale_bits.append("weather impact")

        if SKLEARN_AVAILABLE and hasattr(self.model, "predict"):
            pred = float(self.model.predict(X)[0])
            conf = 0.75
        else:
            # mean by prime vs offpeak
            key = int(feats.loc[0, "is_prime"])
            pred = float(self.model.get(key, 1.0))
            conf = 0.55

        pred = max(0.6, min(1.3, pred))
        rationale = " / ".join(rationale_bits) if rationale_bits else "baseline demand"

        return pred, conf, rationale

    def apply_guardrails(self, asset_key: str, is_prime: int, raw_price: float, org_type: str, weather_flag: int) -> Tuple[float, float, float]:
        floors = self.guardrails.get("floors", {})
        ceilings = self.guardrails.get("ceilings", {})
        floor = floors.get(asset_key, {}).get("prime" if is_prime else "offpeak", 0.0)
        ceiling = ceilings.get(asset_key, {}).get("prime" if is_prime else "offpeak", 1e9)

        price = raw_price

        # Weather cap on surge
        if weather_flag == 1 and ceiling < 1e9:
            cap_mult = self.guardrails.get("weather_cap_multiplier", 1.10)
            ceiling = min(ceiling, floor * cap_mult)

        # Tier discounts
        disc_map = self.guardrails.get("discounts", {})
        org = (org_type or "").strip().lower()
        if org in disc_map:
            price = price * float(disc_map[org])

        # Clamp
        price = float(max(floor, min(ceiling, price)))
        return price, floor, ceiling

    def recommend(self, row: pd.Series) -> PricingOutput:
        # Need quoted or baseline to scale
        baseline = row.get("quoted_price", None)
        if pd.isna(baseline) or float(baseline) <= 0:
            # choose mid between floor/ceiling as baseline if missing
            feats = self.build_features(pd.DataFrame([row]))
            asset_key = feats.loc[0, "asset_key"]
            is_prime = int(feats.loc[0, "is_prime"])
            floors = self.guardrails.get("floors", {})
            ceilings = self.guardrails.get("ceilings", {})
            floor = floors.get(asset_key, {}).get("prime" if is_prime else "offpeak", 100.0)
            ceiling = ceilings.get(asset_key, {}).get("prime" if is_prime else "offpeak", floor * 1.4)
            baseline = 0.5 * (floor + ceiling)

        mult, conf, rationale = self.predict_multiplier(row)
        raw = float(baseline) * mult

        feats = self.build_features(pd.DataFrame([row]))
        asset_key = feats.loc[0, "asset_key"]
        is_prime = int(feats.loc[0, "is_prime"])
        weather_flag = int(feats.loc[0, "weather_flag"])
        org_type = str(row.get("org_type", ""))

        price, floor, ceiling = self.apply_guardrails(asset_key, is_prime, raw, org_type, weather_flag)

        return PricingOutput(
            recommended_price=round(price, 2),
            multiplier=round(mult, 3),
            confidence=round(conf, 2),
            rationale=rationale,
            floor_applied=floor,
            ceiling_applied=ceiling,
        )
