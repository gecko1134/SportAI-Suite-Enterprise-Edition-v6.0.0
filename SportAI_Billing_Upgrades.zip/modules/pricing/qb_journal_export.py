
"""
QuickBooks Journal CSV exporter.
Creates a simple journal entry CSV from the payments ledger:
- Debit: Cash/AR when paid
- Credit: Revenue
- For open/unpaid entries, credits AR and no cash movement
"""
import os
import pandas as pd
from datetime import datetime

LEDGER_PATH = "modules/pricing/payments_ledger.csv"

def export_qb_journal_csv(out_path: str = "exports/qb_journal_export.csv") -> str:
    if not os.path.exists(LEDGER_PATH):
        raise FileNotFoundError(LEDGER_PATH)
    df = pd.read_csv(LEDGER_PATH)
    rows = []
    for _, r in df.iterrows():
        ts = int(r.get("ts", 0) or 0)
        date_str = datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d") if ts else datetime.utcnow().strftime("%Y-%m-%d")
        inv = r.get("invoice_no","")
        org = r.get("org_name","")
        amt = float(r.get("amount", 0.0))
        status = str(r.get("status","")).lower()

        if amt <= 0: 
            continue

        if status == "paid":
            # Debit Cash, Credit Revenue
            rows.append([date_str, inv, org, "Cash", amt, 0.0])
            rows.append([date_str, inv, org, "Revenue", 0.0, amt])
        elif status in ["open","unpaid","partial"]:
            # Debit A/R, Credit Revenue (recognize receivable)
            rows.append([date_str, inv, org, "Accounts Receivable", amt, 0.0])
            rows.append([date_str, inv, org, "Revenue", 0.0, amt])
        elif status == "refunded":
            # Debit Revenue, Credit Cash
            rows.append([date_str, inv, org, "Revenue", amt, 0.0])
            rows.append([date_str, inv, org, "Cash", 0.0, amt])

    out_df = pd.DataFrame(rows, columns=["Date","Invoice","Customer","Account","Debit","Credit"])
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    out_df.to_csv(out_path, index=False)
    return out_path
