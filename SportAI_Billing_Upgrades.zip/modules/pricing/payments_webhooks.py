
"""
FastAPI billing webhooks (Stripe + QuickBooks) with:
- Stripe signature verification (basic HMAC-SHA256 of "t.payload" against STRIPE_WEBHOOK_SECRET)
- Status mapping for success, failure, partial refunds, full refunds
- Auto-builds SendGrid receipt payloads (no network calls here) and writes to exports/

Run locally:
  uvicorn modules.pricing.payments_webhooks:app --host 0.0.0.0 --port 8080
"""
import os, json, time, hmac, hashlib
from typing import Dict, Any
from fastapi import FastAPI, Request, Header, HTTPException
import pandas as pd

LEDGER_PATH = "modules/pricing/payments_ledger.csv"
EXPORTS_DIR = "exports"
os.makedirs("modules/pricing", exist_ok=True)
os.makedirs(EXPORTS_DIR, exist_ok=True)

app = FastAPI(title="SportAI Billing Webhooks")

def _append_ledger(row: Dict[str, Any]):
    df = pd.DataFrame([row])
    if os.path.exists(LEDGER_PATH):
        df.to_csv(LEDGER_PATH, mode="a", header=False, index=False)
    else:
        df.to_csv(LEDGER_PATH, mode="w", header=True, index=False)

def _base_row() -> Dict[str, Any]:
    return {
        "ts": int(time.time()),
        "event_source": "",
        "event_type": "",
        "invoice_no": "",
        "org_name": "",
        "email": "",
        "amount": 0.0,
        "currency": "USD",
        "status": "paid",
        "transaction_id": "",
        "meta": "{}"
    }

def _parse_stripe_sig_header(sig_header: str) -> Dict[str,str]:
    # Format: t=timestamp,v1=signature[,...]
    out = {}
    try:
        parts = [p.strip() for p in sig_header.split(",")]
        for p in parts:
            k,v = p.split("=",1)
            out[k] = v
    except Exception:
        pass
    return out

def verify_stripe_signature(sig_header: str, payload: bytes, signing_secret: str, tolerance: int = 300) -> bool:
    if not sig_header or not signing_secret:
        return False
    fields = _parse_stripe_sig_header(sig_header)
    t = fields.get("t")
    v1 = fields.get("v1")
    if not t or not v1:
        return False
    try:
        ts = int(t)
    except Exception:
        return False
    if abs(int(time.time()) - ts) > tolerance:
        return False
    signed_payload = f"{t}.{payload.decode('utf-8')}"
    computed = hmac.new(signing_secret.encode("utf-8"), signed_payload.encode("utf-8"), hashlib.sha256).hexdigest()
    # Constant-time compare
    return hmac.compare_digest(computed, v1)

def _build_receipt_payload(invoice_no: str, amount: float, currency: str, status: str, txn_id: str, to_email: str) -> Dict[str, Any]:
    # Simple SendGrid payload body (no network calls)
    html = f"""<!DOCTYPE html><html><body style='font-family:Arial'>
    <h3>Payment Receipt</h3>
    <p>Invoice: {invoice_no}</p>
    <p>Amount: ${amount:.2f} {currency}</p>
    <p>Status: {status}</p>
    <p>Transaction ID: {txn_id}</p>
    <p>Thank you for your payment to National Sports Dome & Performance Complex.</p>
    </body></html>"""
    return {
        "personalizations": [{"to": [{"email": to_email}], "subject": f"Receipt for {invoice_no}"}],
        "from": {"email": "billing@nxscomplex.org", "name": "National Sports Dome & Performance Complex"},
        "content": [{"type": "text/html", "value": html}]
    }

def _write_export(name: str, data: Dict[str, Any]):
    path = os.path.join(EXPORTS_DIR, name)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    return path

@app.post("/webhook/stripe")
async def stripe_webhook(request: Request, stripe_signature: str = Header(default="")):
    body = await request.body()
    secret = os.getenv("STRIPE_WEBHOOK_SECRET", "")
    if not verify_stripe_signature(stripe_signature, body, secret):
        raise HTTPException(status_code=400, detail="Invalid signature")
    try:
        event = json.loads(body.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    etype = event.get("type", "")
    data = event.get("data", {}).get("object", {})
    row = _base_row()
    row["event_source"] = "stripe"
    row["event_type"] = etype
    row["invoice_no"] = data.get("metadata", {}).get("invoice_no", data.get("id",""))
    row["org_name"] = data.get("metadata", {}).get("org_name","")
    row["email"] = data.get("receipt_email", data.get("customer_email",""))
    row["transaction_id"] = data.get("id","")

    # Amounts (cents → dollars)
    amt = 0.0
    if "amount" in data:
        amt = float(data.get("amount", 0))/100.0
    elif "amount_total" in data:  # checkout.session.completed
        amt = float(data.get("amount_total", 0))/100.0
    elif "amount_paid" in data:
        amt = float(data.get("amount_paid", 0))/100.0
    row["amount"] = amt
    row["currency"] = data.get("currency","USD").upper()

    # Status mapping
    status = "paid"
    if etype.endswith("payment_failed"):
        status = "unpaid"
    elif etype in ["charge.refunded", "payment_intent.canceled"]:
        status = "refunded"
    elif etype in ["charge.refund.updated", "payment_intent.partially_refunded"]:
        status = "partial"
    else:
        # success cases: payment_intent.succeeded, checkout.session.completed
        status = "paid"
    row["status"] = status
    row["meta"] = json.dumps(data)
    _append_ledger(row)

    # Receipt payload on paid
    if status == "paid" and row["email"]:
        payload = _build_receipt_payload(row["invoice_no"], row["amount"], row["currency"], status, row["transaction_id"], row["email"])
        export_path = _write_export(f"receipt_{row['invoice_no']}.json", payload)
        return {"ok": True, "receipt_payload": export_path}

    return {"ok": True}

@app.post("/webhook/quickbooks")
async def quickbooks_webhook(request: Request):
    body = await request.body()
    try:
        event = json.loads(body.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    data = event.get("invoice", event)
    row = _base_row()
    row["event_source"] = "quickbooks"
    row["event_type"] = event.get("eventNotifications", [{}])[0].get("eventId","qb_event")
    row["invoice_no"] = str(data.get("DocNumber", data.get("Id","")))
    row["org_name"] = data.get("CustomerRef", {}).get("name","")
    row["email"] = data.get("BillEmail", {}).get("Address","")
    row["amount"] = float(data.get("TotalAmt", 0))
    row["currency"] = data.get("CurrencyRef", {}).get("value","USD").upper()
    row["status"] = data.get("Balance",0) == 0 and "paid" or "open"
    row["transaction_id"] = str(data.get("Id",""))
    row["meta"] = json.dumps(data)
    _append_ledger(row)
    return {"ok": True}
