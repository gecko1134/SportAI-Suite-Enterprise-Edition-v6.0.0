
import json, os
import pandas as pd
import streamlit as st
from .payments_ledger import load_ledger, save_ledger, mark_invoice_status, ar_aging, totals
from .qb_journal_export import export_qb_journal_csv

def run_payments_dashboard_tab():
    st.header("Payments Dashboard — Paid/Unpaid & A/R Aging")
    df = load_ledger()
    if df.empty:
        st.info("Ledger is empty. Once webhooks hit or you import a CSV, entries will appear.")
        return

    st.subheader("Ledger")
    st.dataframe(df, use_container_width=True)

    st.markdown("### Filters")
    c1, c2, c3 = st.columns(3)
    src_opts = sorted(df["event_source"].dropna().unique().tolist())
    status_opts = sorted(df["status"].dropna().unique().tolist())
    src = c1.multiselect("Source", src_opts, default=src_opts)
    status = c2.multiselect("Status", status_opts, default=status_opts)
    org = c3.text_input("Org contains", "")

    fdf = df.copy()
    if src: fdf = fdf[fdf["event_source"].isin(src)]
    if status: fdf = fdf[fdf["status"].isin(status)]
    if org: fdf = fdf[fdf["org_name"].fillna("").str.contains(org, case=False)]

    st.subheader("Filtered")
    st.dataframe(fdf, use_container_width=True)

    st.markdown("### Metrics")
    t = totals(fdf)
    col1, col2, col3 = st.columns(3)
    col1.metric("Paid", f"${t['paid']:.2f}")
    col2.metric("Open/Unpaid", f"${t['open']:.2f}")
    col3.metric("All Time", f"${t['grand_total']:.2f}")

    st.markdown("### A/R Aging (Open)")
    aging = ar_aging(fdf)
    st.json(aging)

    st.markdown("### Update Status")
    inv = st.text_input("Invoice #", "")
    new_status = st.selectbox("New status", ["paid","open","unpaid","partial","refunded"])
    if st.button("Apply Status"):
        if inv.strip():
            ok = mark_invoice_status(inv.strip(), new_status)
            st.success("Updated." if ok else "Invoice not found.")
        else:
            st.warning("Enter an invoice number.")

    st.markdown("### Export")
    st.download_button("Download Current Ledger CSV", data=fdf.to_csv(index=False).encode("utf-8"),
                       file_name="payments_ledger_filtered.csv", mime="text/csv")

    if st.button("Export QuickBooks Journal CSV"):
        path = export_qb_journal_csv("exports/qb_journal_export.csv")
        with open(path, "rb") as f:
            st.download_button("Download QB Journal CSV", data=f.read(),
                               file_name="qb_journal_export.csv", mime="text/csv")
