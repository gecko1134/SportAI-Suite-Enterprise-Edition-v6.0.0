
# SportAI Billing Upgrades

**What’s new**
- Stripe signature verification (basic HMAC check of `t.payload` vs `STRIPE_WEBHOOK_SECRET`)
- Auto-generate **SendGrid receipt payloads** on paid events (saved in `/exports`)
- Refund / Partial refund status mapping
- **QuickBooks journal export** CSV from the ledger
- Updated Payments Dashboard to export QB journal

**Files**
- `modules/pricing/payments_webhooks.py`
- `modules/pricing/qb_journal_export.py`
- `modules/pricing/pricing_suite_billing.py` (updated)
- `modules/pricing/payments_ledger.csv` (demo seed if none exists)
- `exports/` (receipts & QB CSVs)

**Run webhooks**
```bash
pip install fastapi uvicorn pandas
export STRIPE_WEBHOOK_SECRET=whsec_xxx
uvicorn modules.pricing.payments_webhooks:app --host 0.0.0.0 --port 8080
```

**Wire dashboard tab**
```python
from modules.pricing.pricing_suite_billing import run_payments_dashboard_tab
# ... add "Payments Dashboard" in your Pricing Tools radio as before
```
