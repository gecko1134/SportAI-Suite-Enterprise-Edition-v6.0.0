
import datetime as dt
from typing import Dict, Any, List
import streamlit as st
from .utils import load_json, save_json, ensure_log, package_path

LOG_PATH = "data/approvals_log.json"
QUEUE_PATH = "data/pending_queue.json"

def _now_iso():
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def _load_queue() -> List[Dict[str, Any]]:
    data = load_json(QUEUE_PATH)
    return data or []

def _save_queue(items: List[Dict[str, Any]]):
    save_json(QUEUE_PATH, items)

def _append_log(entry: Dict[str, Any]):
    log = ensure_log(LOG_PATH)
    log.append(entry)
    save_json(LOG_PATH, log)

def queue_recommendation(item: Dict[str, Any]):
    """External hook: push a recommendation into the approvals queue."""
    items = _load_queue()
    items.append(item)
    _save_queue(items)

def run():
    st.title("Command Board – Approvals Queue (Neutral)")
    st.caption("Review, apply, or rollback AI recommendations across pricing, layouts, sponsors, and memberships.")

    # Filters / controls
    colf1, colf2 = st.columns([2,1])
    with colf1:
        category = st.selectbox("Category filter", ["All", "Pricing", "Layout", "Sponsorship", "Membership"])
    with colf2:
        st.button("Refresh")

    items = _load_queue()
    if category != "All":
        items = [i for i in items if i.get("category") == category]

    if not items:
        st.info("No pending recommendations in the queue.")
    else:
        for idx, item in enumerate(items):
            with st.container(border=True):
                header = f"{item.get('title', 'Untitled')}"
                st.subheader(header)
                st.write(item.get("description", ""))
                meta_cols = st.columns(4)
                with meta_cols[0]:
                    st.metric("Projected Impact", item.get("impact", "+$0/wk"))
                with meta_cols[1]:
                    st.metric("Confidence", f"{int(item.get('confidence', 0)*100)}%")
                with meta_cols[2]:
                    st.metric("Risk Flags", str(item.get("risk_flags", 0)))
                with meta_cols[3]:
                    st.metric("Affected", str(item.get("affected_count", 0)))

                with st.expander("Why this? / Details"):
                    st.json(item)

                a1, a2, a3, a4 = st.columns([1,1,1,1])
                with a1:
                    if st.button("Apply", key=f"apply_{idx}"):
                        _append_log({
                            "ts": _now_iso(),
                            "action": "APPLY",
                            "item": item
                        })
                        # Simulated "write-back" done
                        # Remove item from queue
                        q = _load_queue()
                        q.pop(idx)
                        _save_queue(q)
                        st.success("Applied and logged.")
                        st.rerun()
                with a2:
                    if st.button("Snooze", key=f"snooze_{idx}"):
                        _append_log({
                            "ts": _now_iso(),
                            "action": "SNOOZE",
                            "item": item
                        })
                        st.info("Snoozed (kept in queue).")
                with a3:
                    if st.button("Reject", key=f"reject_{idx}"):
                        _append_log({
                            "ts": _now_iso(),
                            "action": "REJECT",
                            "item": item
                        })
                        q = _load_queue()
                        q.pop(idx)
                        _save_queue(q)
                        st.warning("Rejected and removed from queue.")
                        st.rerun()
                with a4:
                    if st.button("Rollback", key=f"rollback_{idx}"):
                        _append_log({
                            "ts": _now_iso(),
                            "action": "ROLLBACK",
                            "item": item
                        })
                        st.success("Rollback recorded (no-op demo).")

    st.divider()
    st.subheader("Audit Log (most recent 50)")
    log = ensure_log(LOG_PATH)
    if not log:
        st.caption("No actions yet.")
    else:
        for entry in log[-50:][::-1]:
            with st.container(border=True):
                st.write(f"**{entry['action']}** • {entry['ts']}")
                st.caption(entry['item'].get("title", "Untitled"))
