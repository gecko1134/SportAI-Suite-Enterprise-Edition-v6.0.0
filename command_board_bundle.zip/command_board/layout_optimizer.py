
import streamlit as st
from typing import Dict, Any, List
from .utils import load_json
from .approvals_queue import queue_recommendation

def _load_resources():
    return load_json("sample_data/resources.json") or {}

def run():
    st.title("Layout Optimizer (Neutral)")
    st.caption("Proposes court/turf splits, swaps, and buffers to maximize utilization while honoring constraints.")

    res = _load_resources()
    assets = res.get("assets", [])

    col1, col2 = st.columns([2,1])
    with col1:
        asset = st.selectbox("Asset", [a["name"] for a in assets])
        split = st.selectbox("Suggested split", ["No split", "Half-court", "Thirds", "Quarters"])
        buffer_min = st.slider("Cleaning/Reset Buffer (min)", 0, 30, 10, 5)
    with col2:
        staff_ok = st.checkbox("Ref/Staff available", True)
        cert_ok = st.checkbox("Meets certification buffer rules", True)

    st.write("**Preview**")
    st.json({"asset": asset, "split": split, "buffer_min": buffer_min, "staff_ok": staff_ok, "cert_ok": cert_ok})

    if st.button("Queue Recommendation"):
        risk = 0
        if not staff_ok: risk += 1
        if not cert_ok: risk += 1
        item = {
            "category": "Layout",
            "title": f"Apply {split} to {asset} with {buffer_min} min buffer",
            "description": "Auto-generated layout optimization respecting buffers and staffing.",
            "impact": "+$240/wk",
            "confidence": 0.7 if (staff_ok and cert_ok) else 0.4,
            "risk_flags": risk,
            "affected_count": 1,
            "payload": {"asset": asset, "split": split, "buffer_min": buffer_min}
        }
        queue_recommendation(item)
        st.success("Queued in Approvals.")
