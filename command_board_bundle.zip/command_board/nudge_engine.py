
import streamlit as st
import pandas as pd
from typing import Dict, Any, List
from .utils import package_path
from .approvals_queue import queue_recommendation

def _load_member_usage():
    import os, csv, json
    path = package_path("sample_data", "member_usage.csv")
    rows = []
    if os.path.exists(path):
        import pandas as pd
        return pd.read_csv(path)
    return None

def run():
    st.title("Nudge Engine (Neutral)")
    st.caption("Identifies members who should upgrade plans or pre-buy credits before sell-out windows.")

    df = _load_member_usage()
    if df is None or df.empty:
        st.info("No member usage data found.")
        return

    # simple heuristic: if used_credits > 80% of plan_credits, suggest upgrade
    df["usage_ratio"] = (df["used_credits"] / df["plan_credits"]).round(2)
    threshold = st.slider("Upgrade threshold (usage ratio)", 0.5, 1.2, 0.8, 0.05)
    candidates = df[df["usage_ratio"] >= threshold].copy()

    st.write(f"Members above threshold: {len(candidates)}")
    st.dataframe(candidates[["member_id", "name", "plan", "plan_credits", "used_credits", "usage_ratio"]])

    selected = st.multiselect("Select members to queue upgrade offer", candidates["member_id"].tolist())
    offer = st.text_input("Offer blurb", "Upgrade to Family Plus this month and get 10 bonus credits.")
    est_conversion = st.slider("Expected conversion", 0.0, 1.0, 0.3, 0.05)

    if st.button("Queue Recommendations"):
        for mid in selected:
            row = df[df["member_id"] == mid].iloc[0]
            item = {
                "category": "Membership",
                "title": f"Upgrade offer for {row['name']} ({row['plan']}→higher tier)",
                "description": offer,
                "impact": "+$120/yr",
                "confidence": est_conversion,
                "risk_flags": 0,
                "affected_count": 1,
                "payload": {"member_id": mid, "current_plan": row["plan"]}
            }
            queue_recommendation(item)
        st.success(f"Queued {len(selected)} offers in Approvals.")
