
import streamlit as st
from typing import Dict, Any, List
from .utils import load_json
from .approvals_queue import queue_recommendation

def _load_inventory():
    return load_json("sample_data/sponsor_inventory.json") or {"assets": []}

def run():
    st.title("Sponsor Lift (Neutral)")
    st.caption("Recommends add-ons and tier tweaks to lift sponsorship revenue and deliver impressions.")

    inv = _load_inventory()
    assets = inv.get("assets", [])

    asset_names = [a["name"] for a in assets] or ["Scoreboard Wrap", "Center Court Logo", "eNewsletter Header"]
    target = st.selectbox("Primary Sponsored Asset", asset_names)
    add_on = st.selectbox("Add-on", ["Social Blast", "LED Ribbon Loop", "Tournament Naming", "VIP Passes Bundle", "Website Hero"])
    uplift_pct = st.slider("Expected uplift (%)", 0, 100, 18, 1)

    st.write("**Preview**")
    st.json({"target": target, "add_on": add_on, "uplift_pct": uplift_pct})

    if st.button("Queue Recommendation"):
        item = {
            "category": "Sponsorship",
            "title": f"Attach {add_on} to {target} (+{uplift_pct}% value)",
            "description": "Based on inventory and upcoming events, this add-on is projected to increase impressions and value.",
            "impact": f"+${int(5000*uplift_pct/100)}",
            "confidence": 0.65,
            "risk_flags": 0,
            "affected_count": 1,
            "payload": {"target": target, "add_on": add_on, "uplift_pct": uplift_pct}
        }
        queue_recommendation(item)
        st.success("Queued in Approvals.")
