
# Command Board (Neutral)

A plug‑and‑play folder for your Streamlit admin dashboard that adds a proactive **Command Board**:
- **Yield Brain**: price suggestions for courts & turf
- **Layout Optimizer**: splits & buffer proposals
- **Sponsor Lift**: add-ons to raise sponsor value
- **Nudge Engine**: upgrade/pre-buy prompts for members
- **Approvals Queue**: one-click **Apply / Snooze / Reject / Rollback** with audit log

## Install
Drop the `/command_board/` folder into your app repo alongside `main_app.py` (or inside `modules/` if you prefer).

```
your_repo/
  main_app.py
  command_board/
    __init__.py
    approvals_queue.py
    layout_optimizer.py
    nudge_engine.py
    sponsor_lift.py
    utils.py
    yield_brain.py
    sample_data/
      resources.json
      sponsor_inventory.json
      member_usage.csv
      pricing_rules.json
```

## How to wire it
In `main_app.py`:

```python
from command_board import approvals_queue, yield_brain, layout_optimizer, sponsor_lift, nudge_engine

PAGES = {
    "Approvals Queue": approvals_queue.run,
    "Yield Brain": yield_brain.run,
    "Layout Optimizer": layout_optimizer.run,
    "Sponsor Lift": sponsor_lift.run,
    "Nudge Engine": nudge_engine.run,
}
# Add to your sidebar router as needed
```

## Notes
- No `st.set_page_config()` here (kept out of modules to avoid conflicts).
- Storage uses package‑relative JSON in `command_board/data/`. In Streamlit Cloud, files persist per deployment. You can swap to a DB or Google Sheet later.
- Everything is **neutral‑branded** (no logos/colors).

## Next hooks
- Connect to SportsKey write‑back for price changes & holds.
- Replace heuristics with your AI models.
- Extend sponsor inventory schema for renewals and exclusivity.
