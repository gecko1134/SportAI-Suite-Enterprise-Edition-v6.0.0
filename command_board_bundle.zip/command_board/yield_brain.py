
import math, json
import streamlit as st
from typing import Dict, Any, List
from .utils import load_json, save_json, package_path
from .approvals_queue import queue_recommendation

def _load_resources():
    return load_json("sample_data/resources.json") or {}

def _load_pricing_rules():
    return load_json("sample_data/pricing_rules.json") or {}

def _suggest_price(base_rate: float, demand: float, sport_mult: float, caps: Dict[str, float]):
    # Simple suggestion: base * demand band * sport multiplier, clipped by caps
    rate = base_rate * (1 + demand) * sport_mult
    rate = max(caps.get("min", rate), min(rate, caps.get("max", rate)))
    return round(rate, 2)

def run():
    st.title("Yield Brain – Dynamic Pricing (Neutral)")
    st.caption("Generates suggested hourly prices by asset, time band, and sport.")

    resources = _load_resources()
    rules = _load_pricing_rules()

    assets = resources.get("assets", [])
    sports = resources.get("sports", ["Basketball", "Volleyball", "Pickleball", "Soccer", "Lacrosse", "Baseball/Softball"])

    col1, col2 = st.columns([2,1])
    with col1:
        selected_asset = st.selectbox("Asset", [a["name"] for a in assets])
        sport = st.selectbox("Sport", sports)
        demand_band = st.slider("Demand band (0=low → 2=very high)", 0.0, 2.0, 1.0, 0.1)
    with col2:
        base_rate = st.number_input("Base rate ($/hr)", value=rules.get("defaults", {}).get("base_rate", 100.0), step=5.0)
        sport_mult = st.number_input("Sport multiplier", value=rules.get("sport_multipliers", {}).get(sport, 1.0), step=0.05)
        min_cap = st.number_input("Min cap ($/hr)", value=rules.get("caps", {}).get("min", 60.0), step=5.0)
        max_cap = st.number_input("Max cap ($/hr)", value=rules.get("caps", {}).get("max", 300.0), step=5.0)

    suggested = _suggest_price(base_rate, demand_band, sport_mult, {"min": min_cap, "max": max_cap})
    st.metric("Suggested Price", f"${suggested:,.2f}/hr")

    if st.button("Queue Recommendation"):
        item = {
            "category": "Pricing",
            "title": f"Set {selected_asset} to ${suggested}/hr for {sport} (band={demand_band})",
            "description": f"Base ${base_rate}/hr × demand {demand_band} × sport mult {sport_mult}. Caps [{min_cap}-{max_cap}].",
            "impact": f"+${round((suggested - base_rate)*8, 2)}/wk",
            "confidence": min(1.0, 0.5 + demand_band/3),
            "risk_flags": 0 if demand_band>=1 else 1,
            "affected_count": 1,
            "payload": {
                "asset": selected_asset,
                "sport": sport,
                "new_rate": suggested
            }
        }
        queue_recommendation(item)
        st.success("Queued in Approvals.")
