
import os, json
from typing import Any, Dict, List

def package_path(*parts: str) -> str:
    """Return an absolute path inside this package, safe for Streamlit Cloud and local runs."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, *parts)

def load_json(rel_path: str):
    """Load JSON from a package-relative path."""
    path = package_path(rel_path)
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(rel_path: str, data: Any):
    """Save JSON to a package-relative path."""
    path = package_path(rel_path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def ensure_log(rel_path: str):
    """Ensure a JSON list log file exists and return its contents."""
    data = load_json(rel_path)
    if data is None:
        data = []
        save_json(rel_path, data)
    return data
