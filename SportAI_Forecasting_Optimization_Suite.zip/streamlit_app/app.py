import streamlit as st
import pandas as pd
import yaml
from pathlib import Path

st.set_page_config(page_title='SportAI Facility Optimizer', layout='wide')

st.title('SportAI Facility Optimizer — Forecasting & Actions')

cfg_path = Path('config/app_config.yaml')
with open(cfg_path, 'r') as f:
    cfg = yaml.safe_load(f)

st.sidebar.header('Config')
st.sidebar.write(cfg['facility_name'])
st.sidebar.code(str(cfg_path), language='yaml')

tab1, tab2, tab3 = st.tabs(['Utilization Heatmap','Pricing & Staffing','Reports'])

@st.cache_data
def load_data():
    feats = Path(cfg['paths']['features_out'])
    fcst  = Path(cfg['paths']['forecasts_out'])
    recs  = Path(cfg['paths']['recs_out'])
    df_feats = pd.read_parquet(feats) if feats.exists() else pd.DataFrame()
    df_fcst  = pd.read_parquet(fcst) if fcst.exists() else pd.DataFrame()
    df_recs  = pd.read_csv(recs) if recs.exists() else pd.DataFrame()
    return df_feats, df_fcst, df_recs

df_feats, df_fcst, df_recs = load_data()

with tab1:
    st.subheader('Forecasted Utilization by Hour (sample)')
    if df_fcst.empty:
        st.info('No forecasts found. Run the pipeline to generate outputs.')
    else:
        pivot = df_fcst.pivot_table(index=df_fcst['date_hour'].dt.date, columns=df_fcst['date_hour'].dt.hour, values='pred_utilization', aggfunc='mean')
        st.dataframe((pivot*100).round(1))

with tab2:
    st.subheader('Recommended Pricing & Staffing')
    if df_recs.empty:
        st.info('No recommendations yet.')
    else:
        st.dataframe(df_recs)

with tab3:
    st.subheader('Weekly Report')
    rp = Path(cfg['paths']['report_out'])
    if rp.exists():
        st.download_button('Download Weekly Report (Markdown)', rp.read_bytes(), file_name='weekly_report.md')
    else:
        st.info('Report not generated yet.')
