import argparse, pandas as pd, numpy as np, yaml, os
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

def train_predict(df):
    # simple classification: predict occupied (0/1)
    feats = ['dow','hour','is_weekend','school_in_session','holiday','tournament_flag','temp_high','precip_prob','snowfall_prob','util_7d']
    df = df.dropna(subset=feats)
    X = df[feats].values
    y = df['actual_occupied'].values

    # simple temporal split: last 20% as test
    n = len(df)
    split = int(n*0.8)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)
    preds = model.predict_proba(X_test)[:,1]
    acc = accuracy_score(y_test, (preds>=0.5).astype(int))

    df_out = df.iloc[split:].copy()
    df_out['pred_utilization'] = preds  # probability of being occupied

    return df_out, acc

def main(config_path):
    with open(config_path, 'r') as f:
        cfg = yaml.safe_load(f)

    features = pd.read_parquet(cfg['paths']['features_out'])
    forecasts, acc = train_predict(features)
    out_path = cfg['paths']['forecasts_out']
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    forecasts.to_parquet(out_path, index=False)
    print(f"Forecasts saved -> {out_path}; rows={len(forecasts)} | baseline ACC={acc:.3f}")

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    args = ap.parse_args()
    main(args.config)
