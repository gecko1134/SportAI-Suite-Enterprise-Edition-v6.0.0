import argparse, pandas as pd, yaml, os

def build_recs(df, cfg):
    low = cfg['pricing_rules']['low_util_threshold']
    high = cfg['pricing_rules']['high_util_threshold']
    offdisc = cfg['pricing_rules']['offpeak_discount_pct']
    prem = cfg['pricing_rules']['peak_premium_pct']
    floor = cfg['pricing_rules']['min_price_floor_pct']
    ceil = cfg['pricing_rules']['max_price_ceiling_pct']

    asset_base = {a['id']: a['base_rate'] for a in cfg['assets']}

    rows = []
    for _, r in df.iterrows():
        rid = r['resource_id']
        util = r['pred_utilization']
        base = asset_base.get(rid, 100)
        action = 'hold'
        price = base
        note = ''

        if util < low:
            price = max(base * (1 - offdisc), base * floor)
            action = 'discount'
            note = 'Promote bundle / community block / training clinic'
        elif util > high:
            price = min(base * (1 + prem), base * ceil)
            action = 'premium'
            note = 'Enforce splits, shorten minimums, upsell add-ons'
        else:
            action = 'standard'

        # staffing band
        staff_cfg = next(b for b in cfg['staffing_rules']['bands'] if (util>=b['min'] and util<b['max']))
        rows.append({
            'date_hour': r['date_hour'],
            'resource_id': rid,
            'pred_utilization': round(util,3),
            'suggested_price': round(price,2),
            'action': action,
            'heads_front': staff_cfg['heads_front'],
            'heads_coach': staff_cfg['heads_coach'],
            'heads_clean': staff_cfg['heads_clean'],
            'note': note
        })
    return pd.DataFrame(rows)

def main(config_path):
    import yaml
    with open(config_path, 'r') as f:
        cfg = yaml.safe_load(f)
    forecasts = pd.read_parquet(cfg['paths']['forecasts_out'])
    recs = build_recs(forecasts, cfg)
    out_path = cfg['paths']['recs_out']
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    recs.to_csv(out_path, index=False)
    print(f"Recommendations saved -> {out_path}; rows={len(recs)}")

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    args = ap.parse_args()
    main(args.config)
