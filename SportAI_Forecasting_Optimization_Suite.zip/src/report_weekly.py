import argparse, pandas as pd, yaml, os

def summarize_kpis(recs):
    # Simple KPIs
    under = (recs['pred_utilization']<0.55).sum()
    over  = (recs['pred_utilization']>0.85).sum()
    avg_u = recs['pred_utilization'].mean()
    return under, over, avg_u

def main(config_path):
    with open(config_path, 'r') as f:
        cfg = yaml.safe_load(f)
    recs = pd.read_csv(cfg['paths']['recs_out'])
    under, over, avg_u = summarize_kpis(recs)

    lines = []
    lines.append('# Weekly Facility Forecast & Actions')
    lines.append('')
    lines.append(f"- Avg forecasted utilization: {avg_u:.1%}")
    lines.append(f"- Low-util hours (<55%): {under}")
    lines.append(f"- High-util hours (>85%): {over}")
    lines.append('')
    lines.append('## Pricing & Staffing Suggestions (sample)')
    lines.append(recs.head(20).to_markdown(index=False))

    out = '\n'.join(lines)
    out_path = cfg['paths']['report_out']
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path,'w') as f:
        f.write(out)
    print(f"Weekly report saved -> {out_path}")

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    args = ap.parse_args()
    main(args.config)
