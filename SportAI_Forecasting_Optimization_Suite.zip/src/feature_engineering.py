import argparse, pandas as pd, numpy as np, yaml, os
from datetime import datetime

def build_features(bookings_df, cal_df, wx_df):
    # Expand to hourly rows per resource over the date range observed
    bookings_df['start_dt'] = pd.to_datetime(bookings_df['start_dt'])
    bookings_df['end_dt']   = pd.to_datetime(bookings_df['end_dt'])
    bookings_df['date'] = bookings_df['start_dt'].dt.date

    start = bookings_df['start_dt'].min().floor('H')
    end   = bookings_df['end_dt'].max().ceil('H')
    resources = bookings_df['resource_id'].unique()

    hours = pd.date_range(start, end, freq='H')
    grid = pd.MultiIndex.from_product([resources, hours], names=['resource_id','date_hour']).to_frame(index=False)

    # occupancy flag
    def is_occupied(row, ts):
        return (row['start_dt'] <= ts) & (row['end_dt'] > ts)

    occ = []
    for _, b in bookings_df.iterrows():
        hrs = pd.date_range(b['start_dt'].floor('H'), b['end_dt'].ceil('H'), freq='H')
        for h in hrs:
            if is_occupied(b, h):
                occ.append((b['resource_id'], h))
    occ_df = pd.DataFrame(occ, columns=['resource_id','date_hour']).drop_duplicates()
    occ_df['actual_occupied'] = 1

    df = grid.merge(occ_df, on=['resource_id','date_hour'], how='left')
    df['actual_occupied'] = df['actual_occupied'].fillna(0).astype(int)

    # time features
    df['dow'] = df['date_hour'].dt.dayofweek
    df['hour'] = df['date_hour'].dt.hour
    df['is_weekend'] = (df['dow']>=5).astype(int)

    # calendar join
    cal_df['date'] = pd.to_datetime(cal_df['date'])
    df = df.merge(cal_df.rename(columns={'date':'date_only'}), left_on=df['date_hour'].dt.floor('D'), right_on='date_only', how='left')
    df.drop(columns=['key_0','date_only'], errors='ignore', inplace=True)
    for c in ['school_in_session','holiday','tournament_flag']:
        if c in df.columns:
            df[c] = df[c].fillna(0)

    # weather join (by date)
    wx_df['date'] = pd.to_datetime(wx_df['date'])
    df = df.merge(wx_df.rename(columns={'date':'wdate'}), left_on=df['date_hour'].dt.floor('D'), right_on='wdate', how='left')
    df.drop(columns=['key_0','wdate'], errors='ignore', inplace=True)
    df[['temp_high','precip_prob','snowfall_prob']] = df[['temp_high','precip_prob','snowfall_prob']].fillna(method='ffill')

    # utilization proxy by resource (rolling)
    df = df.sort_values(['resource_id','date_hour'])
    df['util_7d'] = df.groupby('resource_id')['actual_occupied'].transform(lambda s: s.rolling(24*7, min_periods=1).mean())

    return df

def main(config_path):
    with open(config_path, 'r') as f:
        cfg = yaml.safe_load(f)

    bookings = pd.read_csv(cfg['paths']['bookings_csv'])
    cal = pd.read_csv(cfg['paths']['calendar_csv'])
    wx = pd.read_csv(cfg['paths']['weather_csv'])

    features = build_features(bookings, cal, wx)

    out_path = cfg['paths']['features_out']
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    features.to_parquet(out_path, index=False)
    print(f"Features saved -> {out_path}; rows={len(features)} cols={len(features.columns)}")

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    args = ap.parse_args()
    main(args.config)
