# Schema Reference

## bookings.csv
- booking_id (str/int)
- resource_id (str)
- start_dt (YYYY-MM-DD HH:MM)
- end_dt   (YYYY-MM-DD HH:MM)
- booked_price (float)
- party_type (enum: club/school/league/individual/business/etc.)
- source (enum: online/phone/walkin/partner)

## calendar.csv
- date (YYYY-MM-DD)
- school_in_session (0/1)
- holiday (0/1)
- tournament_flag (0/1)

## weather.csv
- date (YYYY-MM-DD)
- temp_high (F)
- precip_prob (0..1)
- snowfall_prob (0..1)

## Derived
- features.parquet → hourly rows per resource with engineered features
- forecasts.parquet → subset with `pred_utilization` per hour
- recommendations.csv → actionable pricing/staffing rows
