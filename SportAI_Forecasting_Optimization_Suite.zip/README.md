# SportAI Suite — Facility Forecasting & Optimization
**Delivery Date:** 2025-10-10

This bundle is a complete starter pack to forecast hourly demand, auto-suggest pricing/staffing, and render a live dashboard. It’s designed to plug into SportsKey exports now and evolve into API integration later.

## Quick Start
1. Create/activate a virtualenv (Python 3.9+).
2. Install requirements (most are stdlib/minimal; see notes below).
3. Put your SportsKey CSV exports into `data/your_exports/` or map paths in `config/app_config.yaml`.
4. Run feature engineering to generate hourly dataset:
   ```bash
   python -m src.feature_engineering --config config/app_config.yaml
   ```
5. Train + forecast (baseline model):
   ```bash
   python -m src.forecast_baseline --config config/app_config.yaml
   ```
6. Generate recommendations + weekly PDF-ready report (CSV/MD):
   ```bash
   python -m src.price_staff_recommendations --config config/app_config.yaml
   python -m src.report_weekly --config config/app_config.yaml
   ```
7. Launch dashboard:
   ```bash
   streamlit run streamlit_app/app.py
   ```

## What’s Inside
- **config/**: single source of truth for paths, business rules, pricing bands, staff maps.
- **data/sample/**: sample CSVs to test without real data.
- **src/**: modular Python for features, forecasting, pricing/staff recs, reporting.
- **streamlit_app/**: Facility Optimizer dashboard (heatmaps, actions, exports).
- **docs/**: Implementation guide + schema reference.

## Minimal Dependencies
This starter uses only pandas/numpy/scikit-learn/matplotlib where needed. You can swap in Prophet/XGBoost later. If an import is missing, install:
```
pip install pandas numpy scikit-learn matplotlib streamlit pyyaml
```
(Prophet alt: `pip install prophet` ; XGBoost alt: `pip install xgboost`)

## License
Unbranded and reusable. You own your data and outputs.
